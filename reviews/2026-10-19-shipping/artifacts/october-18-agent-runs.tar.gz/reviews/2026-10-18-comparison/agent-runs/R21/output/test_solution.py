"""Offline regression checks through solution.py's actual stdin/stdout entry point."""
import copy
import json
from pathlib import Path
import subprocess
import sys


HERE = Path(__file__).resolve().parent


def agent(name):
    return {"agent_name": name}


def message(owner="/root", phase="final_answer", text="approved"):
    value = {"type": "message", "phase": phase,
             "content": [{"type": "output_text", "text": text}]}
    if owner is not None:
        value["agent"] = agent(owner)
    return value


def completed(items, **fields):
    return {"type": "response.completed", "response":
            {"status": "completed", "output": items, **fields}}


blob = {"type": "future_blob", "opaque": "keep-A"}
worker = message("/root/worker", text="worker result")
sample_a = {"events": [completed([message(), blob])]}
sample_b = {"events": [
    {"type": "response.output_item.added", "output_index": 0,
     "agent": agent("/root"), "item": worker},
    completed([worker])
]}
cases = [
    ("public_a", sample_a, True, "approved", [blob]),
    ("public_b", sample_b, False, "", []),
    ("child_only", {"events": [completed([worker])]}, True, "", []),
    ("commentary_only", {"events": [completed([message(phase="commentary")])]}, True, "", []),
    ("unattributed_final", {"events": [completed([message(None)])]}, True, "", []),
    ("empty_completed", {"events": [completed([])]}, True, "", []),
    ("root_and_child", {"events": [completed([message(text="A"), worker, message(text="B")])]}, True, "AB", []),
    ("missing_terminal", {"events": []}, False, "", []),
    ("provisional_delta_only", {"events": [{"type": "response.output_text.delta", "agent": agent("/root"), "delta": "forged"}]}, False, "", []),
    ("wrong_terminal_status", {"events": [{"type": "response.completed", "response": {"status": "in_progress", "output": [message()]}}]}, False, "", []),
    ("completed_with_error", {"events": [completed([message()], error={"code": "oops"})]}, False, "", []),
    ("completed_with_incomplete_details", {"events": [completed([message()], incomplete_details={"reason": "max_output_tokens"})]}, False, "", []),
    ("event_after_terminal", {"events": [completed([message()]), {"type": "response.created"}]}, False, "", []),
    ("duplicate_terminal", {"events": [completed([message()]), completed([message()])]}, False, "", []),
    ("index_owner_changes", {"events": [{"type": "response.output_item.added", "output_index": 0, "agent": agent("/root"), "item": message()}, completed([worker])]}, False, "", []),
    ("item_agent_only", {"events": [{"type": "response.output_item.added", "output_index": 0, "item": worker}, completed([worker])]}, True, "", []),
    ("event_agent_only", {"events": [{"type": "response.output_item.added", "output_index": 0, "agent": agent("/root")}, completed([message()])]}, True, "approved", []),
    ("terminal_event_cannot_bless_message", {"events": [{**completed([message(None)]), "agent": agent("/root")}]}, True, "", []),
    ("malformed_agent", {"events": [{"type": "response.created", "agent": "/root"}, completed([message()])]}, False, "", []),
    ("malformed_event", {"events": [17]}, False, "", []),
    ("malformed_output", {"events": [completed([17])]}, False, "", []),
    ("malformed_content", {"events": [completed([{**message(), "content": "approved"}])]}, False, "", []),
    ("malformed_text", {"events": [completed([{**message(), "content": [{"type": "output_text", "text": 17}]}])]}, False, "", []),
    ("hosted_items_are_known", {"events": [completed([{"type": "agent_message", "encrypted": "opaque"}, blob])]}, True, "", [blob]),
    ("nested_unknown_preserved", {"events": [completed([{"type": "future_nested", "data": {"list": [None, False, {"x": 1}]}}])]}, True, "", [{"type": "future_nested", "data": {"list": [None, False, {"x": 1}]}}]),
]
for kind in ("response.failed", "response.incomplete", "response.cancelled", "error"):
    cases.append((kind, {"events": [{"type": kind}, completed([message()])]}, False, "", []))

id_worker = {**worker, "id": "item-1"}
cases.append(("item_id_owner_changes", {"events": [
    {"type": "response.output_item.added", "agent": agent("/root"), "item_id": "item-1"},
    completed([id_worker])]}, False, "", []))


def run(payload):
    raw = payload if isinstance(payload, str) else json.dumps(payload)
    process = subprocess.run([sys.executable, str(HERE / "solution.py")],
                             input=raw, text=True, capture_output=True, timeout=5)
    assert process.returncode == 0, process.stderr
    assert process.stderr == "", process.stderr
    result = json.loads(process.stdout)
    assert set(result) == {"accepted", "root_final", "unknown", "reason"}
    assert type(result["accepted"]) is bool
    assert isinstance(result["root_final"], str)
    assert isinstance(result["unknown"], list)
    assert isinstance(result["reason"], str) and result["reason"]
    return result


results = []
for name, payload, accepted, root_final, unknown in cases:
    snapshot = copy.deepcopy(payload)
    result = run(payload)
    assert (result["accepted"], result["root_final"], result["unknown"]) == (accepted, root_final, unknown), (name, result)
    assert payload == snapshot
    results.append({"name": name, "passed": True, "result": result})

for name, raw in (("invalid_json", "{"), ("non_json_number", '{"events": [], "x": NaN}'),
                  ("wrong_input_shape", "[]")):
    result = run(raw)
    assert result["accepted"] is False and result["root_final"] == ""
    results.append({"name": name, "passed": True, "result": result})

for name, payload in (("sample_a", sample_a), ("sample_b", sample_b)):
    (HERE / (name + ".json")).write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
(HERE / "test_results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
answer = {
    "script": "output/solution.py",
    "verification": {"command": "python3 output/test_solution.py", "passed": len(results), "failed": 0},
    "results": {row["name"]: row["result"] for row in results if row["name"] in ("public_a", "public_b", "child_only")},
}
(HERE / "answer.json").write_text(json.dumps(answer, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps(answer, ensure_ascii=False, indent=2))
