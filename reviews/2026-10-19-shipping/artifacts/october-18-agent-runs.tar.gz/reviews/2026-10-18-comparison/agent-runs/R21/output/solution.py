#!/usr/bin/env python3
"""Offline Responses event validator. Uses only the Python standard library.

Only an explicit /root final_answer message in a completed terminal response
contributes text. Stream deltas never contribute to the final projection.
"""

import json
import sys


KNOWN_ITEMS = frozenset((
    "message", "reasoning", "compaction", "function_call", "web_search_call",
    "file_search_call", "computer_call", "code_interpreter_call",
    "image_generation_call", "mcp_call", "mcp_list_tools",
    "mcp_approval_request", "custom_tool_call", "multi_agent_call",
    "multi_agent_call_output", "agent_message",
))


def agent_name(value):
    agent = value.get("agent")
    if agent is None:
        return None
    if not isinstance(agent, dict):
        raise ValueError("agent attribution must be an object")
    name = agent.get("agent_name")
    if name is not None and (not isinstance(name, str) or not name):
        raise ValueError("invalid agent_name")
    return name


def validate(payload):
    unknown = []
    try:
        if not isinstance(payload, dict) or not isinstance(payload.get("events"), list):
            raise ValueError("input must contain an events array")
        owners_by_index = {}
        owners_by_id = {}
        terminal = None

        def observe(index, item_id, owner):
            if index is not None and (type(index) is not int or index < 0):
                raise ValueError("output_index must be a nonnegative integer")
            if item_id is not None and (not isinstance(item_id, str) or not item_id):
                raise ValueError("item ID must be a nonempty string")
            for registry, key in ((owners_by_index, index), (owners_by_id, item_id)):
                if key is None or owner is None:
                    continue
                if key in registry and registry[key] != owner:
                    raise ValueError("output item changed agent attribution")
                registry[key] = owner

        for event in payload["events"]:
            if not isinstance(event, dict):
                raise ValueError("event must be an object")
            kind = event.get("type")
            if not isinstance(kind, str) or not kind:
                raise ValueError("event type must be a nonempty string")
            item = event.get("item")
            if item is None:
                item = {}
            if not isinstance(item, dict):
                raise ValueError("event item must be an object")
            event_owner = agent_name(event)
            item_owner = agent_name(item)
            if (event_owner is not None and item_owner is not None
                    and event_owner != item_owner):
                raise ValueError("event and item agent_name conflict")
            if terminal is not None:
                raise ValueError("event after terminal outcome")
            owner = event_owner if event_owner is not None else item_owner
            item_id = item.get("id")
            event_item_id = event.get("item_id")
            if item_id is not None and event_item_id is not None and item_id != event_item_id:
                raise ValueError("event and item IDs conflict")
            observe(event.get("output_index"), item_id or event_item_id, owner)
            if kind == "response.output_text.delta" and not isinstance(event.get("delta"), str):
                raise ValueError("text delta must be a string")
            if kind in ("response.failed", "response.incomplete", "response.cancelled", "error"):
                raise ValueError("non-completed terminal outcome: " + kind)
            if kind != "response.completed":
                continue
            response = event.get("response")
            if not isinstance(response, dict) or response.get("status") != "completed":
                raise ValueError("terminal event/status mismatch")
            if response.get("error") is not None or response.get("incomplete_details") is not None:
                raise ValueError("completed response contains error or incomplete details")
            output = response.get("output", [])
            if not isinstance(output, list):
                raise ValueError("terminal output must be an array")
            for index, output_item in enumerate(output):
                if not isinstance(output_item, dict):
                    raise ValueError("output item must be an object")
                output_owner = agent_name(output_item)
                observe(index, output_item.get("id"), output_owner)
                item_type = output_item.get("type")
                if not isinstance(item_type, str) or item_type not in KNOWN_ITEMS:
                    unknown.append(output_item)
                if item_type == "message":
                    content = output_item.get("content", [])
                    if not isinstance(content, list):
                        raise ValueError("message content must be an array")
                    for part in content:
                        if not isinstance(part, dict):
                            raise ValueError("message content item must be an object")
                        if part.get("type") == "output_text" and not isinstance(part.get("text", ""), str):
                            raise ValueError("output text must be a string")
            terminal = response

        if terminal is None:
            raise ValueError("missing response.completed terminal")
        # Project only after the entire sequence has passed validation.
        final_parts = []
        for item in terminal.get("output", []):
            if (item.get("type") == "message" and agent_name(item) == "/root"
                    and item.get("phase") == "final_answer"):
                final_parts.extend(part.get("text", "") for part in item.get("content", [])
                                   if part.get("type") == "output_text")
        return {"accepted": True, "root_final": "".join(final_parts),
                "unknown": unknown, "reason": "completed terminal and attribution validated"}
    except ValueError as exc:
        return {"accepted": False, "root_final": "", "unknown": unknown, "reason": str(exc)}


def reject_non_json_number(value):
    raise ValueError("non-JSON numeric constant: " + value)


def main():
    try:
        payload = json.load(sys.stdin, parse_constant=reject_non_json_number)
        result = validate(payload)
    except (ValueError, UnicodeError, RecursionError) as exc:
        result = {"accepted": False, "root_final": "", "unknown": [],
                  "reason": "invalid JSON input: " + str(exc)}
    json.dump(result, sys.stdout, ensure_ascii=False, allow_nan=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
