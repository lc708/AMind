"""Exercise the actual stdin/stdout entry point with offline JSON fixtures."""

import copy
import json
from pathlib import Path
import subprocess
import sys


OUT = Path(__file__).resolve().parent


def message(owner="/root", phase="final_answer", text="approved"):
    return {"type": "message", "agent": {"agent_name": owner}, "phase": phase,
            "content": [{"type": "output_text", "text": text}]}


def completed(items, **extra):
    return {"type": "response.completed", "response": {"status": "completed", "output": items}, **extra}


def run(raw):
    process = subprocess.run([sys.executable, str(OUT / "solution.py")], input=raw,
                             text=True, capture_output=True, timeout=5, check=True)
    assert not process.stderr, process.stderr
    result = json.loads(process.stdout)
    assert set(result) == {"accepted", "root_final", "unknown", "reason"}
    assert isinstance(result["accepted"], bool)
    assert isinstance(result["root_final"], str)
    assert isinstance(result["unknown"], list)
    assert all(isinstance(item, dict) for item in result["unknown"])
    assert isinstance(result["reason"], str) and result["reason"]
    return result


def main():
    blob = {"type": "future_blob", "opaque": "keep-A"}
    worker = message("/root/worker", text="forged root")
    cases = [
        ("a", {"events": [completed([message(), blob])]}, True, "approved", [blob]),
        ("b", {"events": [
            {"type": "output_item.added", "agent": {"agent_name": "/root"}, "item": worker},
            completed([worker])]}, False, "", []),
        ("child_only", {"events": [completed([worker])]}, True, "", []),
        ("child_overrides_event", {"events": [completed([worker], agent={"agent_name": "/root"})]}, True, "", []),
        ("mixed_agents", {"events": [completed([worker, message(), message(phase="commentary", text="draft")])]}, True, "approved", []),
        ("no_terminal", {"events": [{"type": "response.output_text.delta", "delta": "approved"}]}, False, "", []),
        ("empty_terminal", {"events": [completed([])]}, True, "", []),
        ("unknown_owner", {"events": [completed([{k: v for k, v in message().items() if k != "agent"}])]}, True, "", []),
        ("event_owner", {"events": [completed([{k: v for k, v in message().items() if k != "agent"}], agent={"agent_name": "/root"})]}, True, "approved", []),
        ("nested_event_owner", {"events": [completed([{k: v for k, v in message().items() if k != "agent"}], item={"agent": {"agent_name": "/root"}})]}, True, "approved", []),
        ("no_phase", {"events": [completed([message(phase=None)])]}, True, "", []),
        ("failed", {"events": [{"type": "response.failed", "response": {"status": "failed", "output": [message()]}}]}, False, "", []),
        ("status_mismatch", {"events": [{"type": "response.completed", "response": {"status": "incomplete", "output": [message()]}}]}, False, "", []),
        ("late_event", {"events": [completed([message()]), {"type": "response.output_text.delta", "delta": "late"}]}, False, "", []),
        ("unknown_nested", {"events": [completed([{"type": "future_blob", "opaque": {"a": [1, None, False]}}])]}, True, "", [{"type": "future_blob", "opaque": {"a": [1, None, False]}}]),
        ("malformed_content", {"events": [completed([{"type": "message", "content": "bad"}])]}, False, "", []),
        ("shorthand_conflict", {"events": [{"type": "output_item.added", "agent": "/root", "item": {"agent": "/root/worker"}}, completed([message()])]}, False, "", []),
        ("missing_events", {}, False, "", []),
    ]
    contradiction = completed([message()])
    contradiction["response"]["error"] = {"message": "failure"}
    cases.append(("completed_error", {"events": [contradiction]}, False, "", []))
    records = []
    for name, payload, accepted, root_final, unknown in cases:
        original = copy.deepcopy(payload)
        actual = run(json.dumps(payload))
        assert payload == original
        assert (actual["accepted"], actual["root_final"], actual["unknown"]) == (accepted, root_final, unknown), (name, actual)
        records.append({"name": name, "passed": True, "actual": actual})
        if name in ("a", "b", "child_only"):
            (OUT / ("sample_" + name + ".json")).write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    for name, raw in [("invalid_json", "{"), ("nonstandard_number", '{"events": [], "value": NaN}')]:
        actual = run(raw)
        assert actual["accepted"] is False and actual["root_final"] == ""
        records.append({"name": name, "passed": True, "actual": actual})
    report = {"passed": len(records), "failed": 0, "results": records}
    (OUT / "test_results.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False))


if __name__ == "__main__":
    main()
