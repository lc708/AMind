#!/usr/bin/env python3
"""Offline terminal-response validator. Uses only the Python standard library.

Agent metadata accepts {"agent_name": "/root"} and the shorthand "/root".
An output message's own agent takes precedence over the terminal event's agent.
Missing ownership never implies /root. Only explicit final_answer text counts.
Unknown output types are retained without projecting their text.
"""

import copy
import json
import sys


class ContractError(ValueError):
    pass


def agent_name(owner, where):
    if owner is None:
        return None
    if isinstance(owner, str):
        if not owner:
            raise ContractError(where + ": agent name must be nonempty")
        return owner
    if not isinstance(owner, dict):
        raise ContractError(where + ": agent must be an object or string")
    name = owner.get("agent_name")
    if name is not None and (not isinstance(name, str) or not name):
        raise ContractError(where + ": agent_name must be a nonempty string")
    return name


def validate(payload):
    unknown = []
    try:
        if not isinstance(payload, dict) or not isinstance(payload.get("events"), list):
            raise ContractError("input must be an object containing an events array")
        terminal_seen = False
        text = []
        # These native types are recognized but contribute no root answer text.
        known_nonmessages = {"reasoning", "function_call", "function_call_output", "compaction"}
        for index, event in enumerate(payload["events"]):
            where = "events[{}]".format(index)
            if not isinstance(event, dict):
                raise ContractError(where + ": event must be an object")
            kind = event.get("type")
            if not isinstance(kind, str) or not kind:
                raise ContractError(where + ": event type must be a nonempty string")

            event_owner = agent_name(event.get("agent"), where)
            item_owner = None
            if "item" in event:
                item = event["item"]
                if not isinstance(item, dict):
                    raise ContractError(where + ": item must be an object")
                item_owner = agent_name(item.get("agent"), where + ".item")
                if event_owner is not None and item_owner is not None and event_owner != item_owner:
                    raise ContractError(where + ": event/item agent_name conflict")
            enclosing_owner = event_owner if event_owner is not None else item_owner

            if terminal_seen:
                raise ContractError(where + ": event after terminal outcome")
            if kind in ("response.failed", "response.incomplete", "response.cancelled", "error"):
                raise ContractError(where + ": terminal is not response.completed")
            if kind != "response.completed":
                continue

            response = event.get("response")
            if not isinstance(response, dict) or response.get("status") != "completed":
                raise ContractError(where + ": terminal event/status mismatch")
            if response.get("error") is not None or response.get("incomplete_details") is not None:
                raise ContractError(where + ": completed response contains error or incomplete details")
            output = response.get("output", [])
            if not isinstance(output, list):
                raise ContractError(where + ": response output must be an array")
            terminal_seen = True
            for output_index, item in enumerate(output):
                item_where = where + ".response.output[{}]".format(output_index)
                if not isinstance(item, dict):
                    raise ContractError(item_where + ": output item must be an object")
                item_type = item.get("type")
                if not isinstance(item_type, str) or not item_type:
                    raise ContractError(item_where + ": output type must be a nonempty string")
                if item_type != "message":
                    if item_type not in known_nonmessages:
                        unknown.append(copy.deepcopy(item))
                    continue

                own_agent = agent_name(item.get("agent"), item_where)
                owner = own_agent if own_agent is not None else enclosing_owner
                content = item.get("content", [])
                if not isinstance(content, list):
                    raise ContractError(item_where + ": message content must be an array")
                for part in content:
                    if not isinstance(part, dict):
                        raise ContractError(item_where + ": content item must be an object")
                    if part.get("type") == "output_text":
                        value = part.get("text")
                        if not isinstance(value, str):
                            raise ContractError(item_where + ": output_text text must be a string")
                        if owner == "/root" and item.get("phase") == "final_answer":
                            text.append(value)

        if not terminal_seen:
            raise ContractError("no response.completed terminal received")
        return {"accepted": True, "root_final": "".join(text), "unknown": unknown,
                "reason": "valid event structure and ownership; completed terminal received"}
    except ContractError as exc:
        return {"accepted": False, "root_final": "", "unknown": unknown, "reason": str(exc)}


def reject_constant(value):
    raise ValueError("non-JSON numeric constant: " + value)


def main():
    try:
        payload = json.load(sys.stdin, parse_constant=reject_constant)
        result = validate(payload)
    except (ValueError, UnicodeError, OSError, RecursionError) as exc:
        result = {"accepted": False, "root_final": "", "unknown": [],
                  "reason": "invalid input: " + str(exc)}
    sys.stdout.write(json.dumps(result, ensure_ascii=False, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
