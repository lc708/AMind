"""Local synthetic protocol checks; runs the actual stdin/stdout entry point."""
import copy
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
EXPECTED = {'target': 'pinned'}
FIELDS = ('attempt_count', 'known_cost_usd', 'total_cost_usd',
          'unknown_cost_attempts', 'identity_valid', 'valid')


def started(name='a', **extra):
    return dict(type='started', attempt_id=name, **extra)


def finished(name='a', **extra):
    return dict(type='finished', attempt_id=name, **extra)


def payload(events, identity=None):
    return {'attempt_events': events,
            'results': [{'id': 'r', 'result_identity': EXPECTED if identity is None else identity}],
            'expected_identity': EXPECTED}


cases = []


def add(name, data, values):
    cases.append((name, data, dict(zip(FIELDS, values))))


public = payload([started(), finished(cost_usd=1.2), started('b')], {'target': 'other'})
add('public', public, (2, 1.2, None, 1, False, False))
healthy = payload([started(), finished(cost_usd=0)])
add('healthy_zero', healthy, (1, 0, 0, 0, True, True))
add('pending', payload([started()]), (1, 0, None, 1, True, True))
add('missing_cost', payload([started(), finished()]), (1, 0, None, 1, True, True))
add('null_cost', payload([started(), finished(cost_usd=None)]), (1, 0, None, 1, True, True))
add('duplicate_finish', payload([started(), finished(cost_usd=1.2), finished(cost_usd=1.2)]),
    (1, 1.2, 1.2, 0, True, True))
add('duplicate_start', payload([started(), started(), finished(cost_usd=0)]),
    (1, 0, 0, 0, True, True))
add('conflicting_finish', payload([started(), finished(cost_usd=1.2), finished(cost_usd=2)]),
    (1, 0, None, 1, True, False))
add('conflicting_metadata', payload([started(), finished(cost_usd=1.2, note='a'),
                                    finished(cost_usd=1.2, note='b')]),
    (1, 0, None, 1, True, False))
add('conflicting_start', payload([started(note='a'), started(note='b'), finished(cost_usd=0)]),
    (1, 0, None, 1, True, False))
add('orphan_finish', payload([finished(cost_usd=1.2)]), (1, 0, None, 1, True, False))
add('finish_before_start', payload([finished(cost_usd=1.2), started()]),
    (1, 0, None, 1, True, False))
for cost in [-1, '1.2', True, [], {}, float('nan'), float('inf'), float('-inf')]:
    add('invalid_cost_' + repr(cost), payload([started(), finished(cost_usd=cost)]),
        (1, 0, None, 1, True, False))
add('mixed_known_unknown', payload([started(), finished(cost_usd=1.2), started('b'),
                                  finished('b'), started('c'), finished('c', cost_usd=0.3)]),
    (3, 1.5, None, 1, True, True))
add('two_known', payload([started(), finished(cost_usd=0.1), started('b'),
                         finished('b', cost_usd=0.2)]), (2, 0.3, 0.3, 0, True, True))
add('started_cost_not_spend', payload([started(cost_usd=3)]), (1, 0, None, 1, True, True))
add('invalid_started_cost', payload([started(cost_usd=-1), finished(cost_usd=1)]),
    (1, 0, None, 1, True, False))
add('identity_extra_field', payload([started(), finished(cost_usd=0)],
                                   {'target': 'pinned', 'extra': 1}),
    (1, 0, 0, 0, False, False))
missing_identity = copy.deepcopy(healthy)
del missing_identity['results'][0]['result_identity']
add('identity_missing', missing_identity, (1, 0, 0, 0, False, False))
nested = copy.deepcopy(healthy)
nested['expected_identity'] = {'nested': {'list': [1, True, None]}}
nested['results'][0]['result_identity'] = {'nested': {'list': [1, 1, None]}}
add('nested_bool_number_mismatch', nested, (1, 0, 0, 0, False, False))
all_results = copy.deepcopy(healthy)
all_results['results'].append({'id': 'other', 'result_identity': {'target': 'wrong'}})
add('each_identity_checked', all_results, (1, 0, 0, 0, False, False))
add('no_attempts', payload([]), (0, 0, 0, 0, True, True))
add('integer_id', payload([started(1), finished(1, cost_usd=0)]), (1, 0, 0, 0, True, True))

records = []
for name, data, expected in cases:
    run = subprocess.run([sys.executable, '-B', str(ROOT / 'audit.py')],
                         input=json.dumps(data), capture_output=True, text=True, check=True)
    actual = json.loads(run.stdout)
    assert {key: actual[key] for key in FIELDS} == expected, (name, actual, expected)
    assert not run.stderr, (name, run.stderr)
    records.append({'name': name, 'passed': True, 'actual': actual})

# Strictly malformed input must also produce one parseable invalid JSON result.
for text in ['{', 'null', '[]', '{"attempt_events":{},"results":[],"expected_identity":{}}']:
    run = subprocess.run([sys.executable, '-B', str(ROOT / 'audit.py')], input=text,
                         capture_output=True, text=True, check=True)
    actual = json.loads(run.stdout)
    assert actual['valid'] is False, (text, actual)
    records.append({'name': 'malformed_input', 'passed': True, 'actual': actual})

(ROOT / 'public_sample.json').write_text(json.dumps(public, ensure_ascii=False, indent=2) + '\n')
(ROOT / 'healthy_sample.json').write_text(json.dumps(healthy, ensure_ascii=False, indent=2) + '\n')
(ROOT / 'verification.json').write_text(json.dumps({'passed': len(records), 'cases': records},
                                                  ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'passed': len(records), 'failed': 0}))
