#!/usr/bin/env python3
"""Offline attempt-ledger audit; standard library only, no filesystem writes.

Missing/null completion costs are unknown. Conflicting attempts and orphan
finishes are not trusted as known spend. Identity equality is recursive and
strictly typed (including booleans versus numbers); object key order is ignored.
"""
import json
import math
import sys
from decimal import Decimal, localcontext


MISSING = object()


def same(left, right):
    """Compare JSON values without Python's True == 1 coercion."""
    if type(left) is not type(right):
        return False
    if isinstance(left, dict):
        return left.keys() == right.keys() and all(
            same(left[key], right[key]) for key in left
        )
    if isinstance(left, list):
        return len(left) == len(right) and all(
            same(a, b) for a, b in zip(left, right)
        )
    return left == right


def valid_json(value):
    if isinstance(value, dict):
        return all(valid_json(item) for item in value.values())
    if isinstance(value, list):
        return all(valid_json(item) for item in value)
    return not isinstance(value, float) or math.isfinite(value)


def cost_valid(value):
    return type(value) in (int, float) and value >= 0 and (
        type(value) is int or math.isfinite(value)
    )


def audit(document):
    errors = []
    attempts = {}
    if not isinstance(document, dict):
        document = {}
        errors.append('input must be an object')
    events = document.get('attempt_events')
    if not isinstance(events, list):
        errors.append('attempt_events must be an array')
        events = []

    for index, event in enumerate(events):
        label = 'attempt_events[%d]' % index
        if not isinstance(event, dict):
            errors.append(label + ' must be an object')
            continue
        event_type = event.get('type')
        attempt_id = event.get('attempt_id')
        if type(attempt_id) not in (str, int) or attempt_id == '':
            errors.append(label + ' requires a string or integer attempt_id')
            continue
        if event_type not in ('started', 'finished'):
            errors.append(label + ' has an unknown event type')
            continue
        key = (type(attempt_id), attempt_id)
        attempt = attempts.setdefault(key, {'bad': False})
        cost = event.get('cost_usd', MISSING)
        if cost is not MISSING and cost is not None and not cost_valid(cost):
            errors.append(label + ' has an invalid cost_usd')
            attempt['bad'] = True
        if event_type == 'finished' and 'started' not in attempt:
            errors.append(label + ' finished without a preceding started event')
            attempt['bad'] = True
        if event_type in attempt:
            if not same(attempt[event_type], event):
                errors.append(label + ' contradicts an earlier ' + event_type)
                attempt['bad'] = True
        else:
            attempt[event_type] = event

    costs = []
    unknown = 0
    for attempt in attempts.values():
        finish = attempt.get('finished')
        cost = finish.get('cost_usd') if finish is not None else None
        if attempt['bad'] or 'started' not in attempt or not cost_valid(cost):
            unknown += 1
        else:
            costs.append(cost)
    # Decimal arithmetic preserves small known charges next to large ones and
    # allows a finite JSON number even when the sum exceeds float's range.
    decimal_costs = [Decimal(str(cost)) for cost in costs]
    known = Decimal(0)
    if decimal_costs:
        precision = (max(cost.adjusted() for cost in decimal_costs)
                     - min(cost.as_tuple().exponent for cost in decimal_costs)
                     + len(str(len(decimal_costs))) + 2)
        with localcontext() as context:
            context.prec = max(28, precision)
            known = sum(decimal_costs, Decimal(0))

    identity_valid = identities_match(document)
    result = {
        'attempt_count': len(attempts),
        'known_cost_usd': known,
        'total_cost_usd': None if unknown else known,
        'unknown_cost_attempts': unknown,
        'identity_valid': identity_valid,
        'valid': not errors and identity_valid,
    }
    if errors:
        result['reason'] = '; '.join(errors)
    return result



def identities_match(document):
    expected = document.get('expected_identity')
    results = document.get('results')
    return (
        isinstance(expected, dict) and valid_json(expected)
        and isinstance(results, list)
        and all(
            isinstance(row, dict)
            and isinstance(row.get('result_identity'), dict)
            and valid_json(row['result_identity'])
            and same(row['result_identity'], expected)
            for row in results
        )
    )


def main():
    try:
        document = json.load(sys.stdin)
        result = audit(document)
    except (ValueError, TypeError, RecursionError) as exc:
        result = {
            'attempt_count': 0, 'known_cost_usd': 0, 'total_cost_usd': None,
            'unknown_cost_attempts': 0, 'identity_valid': False, 'valid': False,
            'reason': 'invalid JSON input: ' + str(exc),
        }
    # Output is flat; Decimal values are emitted as JSON numbers, never strings.
    fields = []
    for key, value in result.items():
        encoded = str(value) if isinstance(value, Decimal) else json.dumps(
            value, ensure_ascii=False, allow_nan=False
        )
        fields.append(json.dumps(key) + ': ' + encoded)
    sys.stdout.write('{' + ', '.join(fields) + '}\n')


if __name__ == '__main__':
    main()
