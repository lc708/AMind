#!/usr/bin/env python3
"""Offline attempt-ledger and result-identity audit; Python standard library only."""

import json
import sys
from decimal import Decimal, localcontext


def identical(left, right):
    """Compare JSON recursively without Python's True == 1 coercion."""
    if type(left) is not type(right):
        return False
    if isinstance(left, dict):
        return left.keys() == right.keys() and all(
            identical(left[key], right[key]) for key in left
        )
    if isinstance(left, list):
        return len(left) == len(right) and all(
            identical(a, b) for a, b in zip(left, right)
        )
    return left == right


def valid_cost(value):
    return (
        type(value) in (int, Decimal)
        and (not isinstance(value, Decimal) or value.is_finite())
        and value >= 0
    )


def exact_sum(costs):
    if not costs:
        return Decimal(0)
    # Enough precision for all integer/fractional places and any carry.
    highest = max(value.adjusted() for value in costs)
    lowest = min(value.as_tuple().exponent for value in costs)
    with localcontext() as context:
        context.prec = max(28, highest - lowest + len(str(len(costs))) + 2)
        return sum(costs, Decimal(0))


def audit(document):
    errors = []
    if not isinstance(document, dict):
        raise ValueError("input must be an object")
    events = document.get("attempt_events")
    results = document.get("results")
    expected = document.get("expected_identity")
    if not isinstance(events, list):
        errors.append("attempt_events must be an array")
        events = []
    if not isinstance(results, list):
        errors.append("results must be an array")
        results = []
    identity_valid = isinstance(expected, dict)
    if not identity_valid:
        errors.append("expected_identity must be an object")

    attempts = {}
    for index, event in enumerate(events):
        if not isinstance(event, dict):
            errors.append("event %d must be an object" % index)
            continue
        kind = event.get("type")
        attempt_id = event.get("attempt_id")
        if kind not in ("started", "finished"):
            errors.append("event %d has an unknown type" % index)
            continue
        if not (type(attempt_id) is int or
                (type(attempt_id) is str and attempt_id)):
            errors.append("event %d has an invalid attempt_id" % index)
            continue
        # Keep integer IDs distinct from textual IDs.
        key = (type(attempt_id), attempt_id)
        state = attempts.setdefault(key, {
            "started": None, "finished": None, "conflict": False
        })
        previous = state[kind]
        if previous is not None:
            if not identical(previous, event):
                state["conflict"] = True
                errors.append("contradictory %s for attempt %r" % (kind, attempt_id))
            # Identical replayed records never add a second charge.
            continue
        if kind == "finished" and state["started"] is None:
            errors.append("finished without a preceding start: %r" % attempt_id)
        state[kind] = event

    costs = []
    unknown = 0
    for (_, attempt_id), state in attempts.items():
        finish = state["finished"]
        if finish is None or state["conflict"]:
            # Conflicting evidence cannot establish a reliable charge.
            unknown += 1
            continue
        value = finish.get("cost_usd")
        if value is None:
            unknown += 1
        elif not valid_cost(value):
            errors.append("invalid cost_usd for attempt %r" % attempt_id)
            unknown += 1
        else:
            costs.append(Decimal(value))

    for index, row in enumerate(results):
        if (not isinstance(row, dict)
                or not isinstance(row.get("result_identity"), dict)
                or not identical(row["result_identity"], expected)):
            identity_valid = False
            errors.append("result %d identity does not match expected_identity" % index)

    known = exact_sum(costs)
    answer = {
        "attempt_count": len(attempts),
        "known_cost_usd": known,
        "total_cost_usd": None if unknown else known,
        "unknown_cost_attempts": unknown,
        "identity_valid": identity_valid,
        "valid": not errors and identity_valid,
    }
    if errors:
        answer["reason"] = "; ".join(errors)
    return answer


def encode_json(value):
    """Emit Decimals as JSON numbers, preserving exact monetary sums."""
    if isinstance(value, Decimal):
        if not value.is_finite():
            raise ValueError("non-finite output number")
        return str(value)
    if isinstance(value, dict):
        return "{" + ",".join(
            json.dumps(key) + ":" + encode_json(item)
            for key, item in value.items()
        ) + "}"
    return json.dumps(value, ensure_ascii=False, allow_nan=False)


def reject_constant(value):
    raise ValueError("non-finite JSON number: " + value)


def main():
    try:
        document = json.load(sys.stdin, parse_float=Decimal,
                             parse_constant=reject_constant)
        answer = audit(document)
    except (ValueError, ArithmeticError, RecursionError) as error:
        answer = {
            "attempt_count": 0,
            "known_cost_usd": 0,
            "total_cost_usd": None,
            "unknown_cost_attempts": 0,
            "identity_valid": False,
            "valid": False,
            "reason": "invalid input: " + str(error),
        }
    sys.stdout.write(encode_json(answer) + "\n")


if __name__ == "__main__":
    main()
