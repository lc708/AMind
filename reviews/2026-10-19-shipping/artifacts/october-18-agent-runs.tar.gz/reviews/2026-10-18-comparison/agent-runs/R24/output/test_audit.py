#!/usr/bin/env python3
"""Synthetic offline controls; invokes the real stdin/stdout script."""

import copy
import json
import os
from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parent
ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
EXPECTED = {"target": "pinned"}


def start(attempt_id="a"):
    return {"type": "started", "attempt_id": attempt_id}


def finish(cost=0, attempt_id="a", **extra):
    return {"type": "finished", "attempt_id": attempt_id,
            "cost_usd": cost, **extra}


def document(events, identity=None):
    return {"attempt_events": events,
            "results": [{"id": "r", "result_identity":
                         EXPECTED if identity is None else identity}],
            "expected_identity": EXPECTED}


def run(value):
    result = subprocess.run(
        [sys.executable, "-B", str(ROOT / "audit.py")],
        input=value if isinstance(value, str) else json.dumps(value),
        text=True, capture_output=True, check=True, env=ENV,
    )
    assert not result.stderr, result.stderr
    return json.loads(result.stdout)


def main():
    public = document([start(), finish(1.2), start("b")], {"target": "other"})
    healthy = document([start(), finish(0)])
    cases = [
        ("public", public, {"attempt_count": 2, "known_cost_usd": 1.2,
         "total_cost_usd": None, "unknown_cost_attempts": 1,
         "identity_valid": False, "valid": False}),
        ("healthy_zero", healthy, {"attempt_count": 1, "known_cost_usd": 0,
         "total_cost_usd": 0, "unknown_cost_attempts": 0,
         "identity_valid": True, "valid": True}),
        ("identical_finish_replay", document([start(), finish(1.2), finish(1.2)]),
         {"attempt_count": 1, "known_cost_usd": 1.2, "total_cost_usd": 1.2,
          "unknown_cost_attempts": 0, "valid": True}),
        ("identical_start_replay", document([start(), start(), finish(0)]),
         {"attempt_count": 1, "valid": True}),
        ("conflicting_finish", document([start(), finish(1), finish(2)]),
         {"attempt_count": 1, "known_cost_usd": 0,
          "total_cost_usd": None, "unknown_cost_attempts": 1, "valid": False}),
        ("conflicting_finish_metadata",
         document([start(), finish(1, status="ok"), finish(1, status="failed")]),
         {"valid": False}),
        ("conflicting_start", document([start(), {**start(), "tag": 1}, finish(0)]),
         {"valid": False}),
        ("orphan_finish", document([finish(1)]), {"valid": False}),
        ("finish_before_start", document([finish(1), start()]), {"valid": False}),
        ("interrupted", document([start()]),
         {"attempt_count": 1, "known_cost_usd": 0, "total_cost_usd": None,
          "unknown_cost_attempts": 1, "valid": True}),
        ("no_cost", document([start(), {"type": "finished", "attempt_id": "a"}]),
         {"known_cost_usd": 0, "total_cost_usd": None,
          "unknown_cost_attempts": 1, "valid": True}),
        ("null_cost", document([start(), finish(None)]),
         {"total_cost_usd": None, "unknown_cost_attempts": 1, "valid": True}),
        ("start_cost_is_not_finished_cost", document([{**start(), "cost_usd": 9}]),
         {"known_cost_usd": 0, "unknown_cost_attempts": 1}),
        ("failed_call_is_billed", document([start(), finish(2, status="failed")]),
         {"known_cost_usd": 2, "total_cost_usd": 2, "valid": True}),
        ("empty_population", document([]),
         {"attempt_count": 0, "known_cost_usd": 0, "total_cost_usd": 0,
          "unknown_cost_attempts": 0, "valid": True}),
        ("identity_extra_key", document([start(), finish()],
         {"target": "pinned", "extra": True}),
         {"identity_valid": False, "valid": False}),
        ("missing_identity", {**healthy, "results": [{"id": "r"}]},
         {"identity_valid": False, "valid": False}),
        ("one_bad_result", {**healthy, "results": healthy["results"] +
         [{"id": "r2", "result_identity": {"target": "other"}}]},
         {"identity_valid": False, "valid": False}),
        ("boolean_is_not_integer_identity", {**healthy,
         "expected_identity": {"x": 1},
         "results": [{"id": "r", "result_identity": {"x": True}}]},
         {"identity_valid": False, "valid": False}),
        ("decimal_money_sum", document([start(), finish(0.1), start("b"),
         finish(0.2, "b")]), {"known_cost_usd": 0.3, "total_cost_usd": 0.3,
                             "attempt_count": 2, "valid": True}),
        ("distinct_text_integer_ids", document([start(1), finish(1, 1),
         start("1"), finish(2, "1")]),
         {"attempt_count": 2, "known_cost_usd": 3, "valid": True}),
    ]
    for value in [-1, "1.2", True, False, [], {}, "NaN", "Infinity"]:
        cases.append(("invalid_cost_%r" % (value,),
                      document([start(), finish(value)]),
                      {"valid": False, "known_cost_usd": 0,
                       "total_cost_usd": None, "unknown_cost_attempts": 1}))
    for token in ["NaN", "Infinity", "-Infinity"]:
        cases.append(("nonfinite_" + token,
                      json.dumps(healthy).replace('"cost_usd": 0',
                                                  '"cost_usd": ' + token),
                      {"valid": False}))
    nested = copy.deepcopy(healthy)
    nested["expected_identity"] = {"x": [1, {"b": 2, "a": "v"}]}
    nested["results"][0]["result_identity"] = {"x": [1, {"a": "v", "b": 2}]}
    cases.append(("nested_object_key_order", nested,
                  {"identity_valid": True, "valid": True}))
    nested_bad = copy.deepcopy(nested)
    nested_bad["results"][0]["result_identity"]["x"][1]["b"] = 3
    cases.append(("nested_identity_mismatch", nested_bad,
                  {"identity_valid": False, "valid": False}))

    evidence = []
    for name, value, expected in cases:
        actual = run(value)
        for key, wanted in expected.items():
            assert actual[key] == wanted, (name, key, wanted, actual)
        assert type(actual["attempt_count"]) is int
        assert type(actual["unknown_cost_attempts"]) is int
        assert type(actual["identity_valid"]) is bool
        assert type(actual["valid"]) is bool
        evidence.append({"name": name, "passed": True, "output": actual})

    (ROOT / "public_input.json").write_text(json.dumps(public, indent=2) + "\n")
    (ROOT / "healthy_input.json").write_text(json.dumps(healthy, indent=2) + "\n")
    (ROOT / "answer.json").write_text(json.dumps(run(public), indent=2) + "\n")
    (ROOT / "healthy_output.json").write_text(json.dumps(run(healthy), indent=2) + "\n")
    (ROOT / "validation.json").write_text(json.dumps({
        "kind": "synthetic_offline_controls", "passed": len(evidence),
        "failed": 0, "cases": evidence,
    }, indent=2) + "\n")
    print(json.dumps({"passed": len(evidence), "failed": 0}))


if __name__ == "__main__":
    main()
