"""Reconcile the append-only attempt ledger and retain unknown spend."""
import math

SCOPE = {'provider', 'interface', 'model', 'service_tier', 'region'}


def number(value):
    try:
        return type(value) in (int, float) and math.isfinite(value) and value >= 0
    except OverflowError:
        return False


def exact_scope(value):
    return (isinstance(value, dict) and set(value) == SCOPE
            and all(isinstance(v, str) and v for v in value.values()))


def price(event, rates):
    """Return complete reported/estimated cost, or None (never free by default)."""
    if 'cost_usd' in event:
        value = event['cost_usd']
        return value if number(value) else None
    scope = event.get('billing_identity')
    if not exact_scope(scope) or event.get('all_billable_usage_included') is not True:
        return None
    matches = [r for r in rates['rates']
               if exact_scope(r.get('identity')) and r['identity'] == scope]
    # Ambiguous rate cards cannot establish a unique cost.
    if len(matches) != 1:
        return None
    rate, usage = matches[0], event.get('usage')
    if not isinstance(usage, dict):
        return None
    if rate.get('mode') == 'input_only':
        if (set(usage) != {'input_tokens'} or type(usage['input_tokens']) is not int
                or usage['input_tokens'] < 0 or not number(rate.get('input_per_million'))):
            return None
        try:
            cost = usage['input_tokens'] * rate['input_per_million'] / 1e6
        except OverflowError:
            return None
        return cost if number(cost) else None
    if rate.get('mode') != 'text':
        return None
    required = {'input_tokens', 'cached_input_tokens', 'output_tokens'}
    if (not required <= set(usage) or set(usage) - required - {'reasoning_tokens'}
            or any(type(usage[k]) is not int or usage[k] < 0 for k in required)):
        return None
    incoming, cached, outgoing = (usage[k] for k in ('input_tokens', 'cached_input_tokens', 'output_tokens'))
    reasoning = usage.get('reasoning_tokens', 0)
    if type(reasoning) is not int or not 0 <= reasoning <= outgoing or cached > incoming:
        return None
    if not all(number(rate.get(k)) for k in ('input_per_million', 'cached_per_million', 'output_per_million')):
        return None
    try:
        cost = ((incoming - cached) * rate['input_per_million']
                + cached * rate['cached_per_million']
                + outgoing * rate['output_per_million']) / 1e6
    except OverflowError:
        return None
    return cost if number(cost) else None


def account(events, rates):
    starts, finishes, issues = {}, {}, []
    for e in events:
        if not isinstance(e, dict):
            raise ValueError('attempt events must be objects')
        kind, key = e.get('event'), e.get('attempt_id')
        if (kind not in ('started', 'finished') or not isinstance(key, str) or not key
                or not isinstance(e.get('case_id'), str) or not e['case_id']
                or type(e.get('rep')) is not int or e['rep'] < 0
                or (kind == 'finished' and (not isinstance(e.get('status'), str) or not e['status']))):
            issues.append('invalid_attempt_event')
            continue
        bucket = starts if kind == 'started' else finishes
        if key in bucket:
            issues.append('duplicate_start' if kind == 'started' else 'duplicate_finish')
            continue  # First event wins; replayed writes never inflate spend or counts.
        if kind == 'finished':
            prior = starts.get(key)
            if prior is None or any(prior[k] != e[k] for k in ('case_id', 'rep')):
                issues.append('unmatched_finished')
        bucket[key] = e
    interrupted = len(set(starts) - set(finishes))
    known, unknown = 0.0, interrupted
    for e in finishes.values():
        cost = price(e, rates)
        if cost is None:
            unknown += 1
        else:
            known += cost
    if not number(known):
        raise ValueError('cost subtotal exceeds finite numeric range')
    attempts = {'started': len(starts), 'finished': len(finishes),
                'interrupted': interrupted,
                'failed': sum(e['status'] != 'ok' for e in finishes.values())}
    costs = {'known_usd': known, 'total_usd': None if unknown else known, 'unknown_attempts': unknown}
    return attempts, costs, issues
