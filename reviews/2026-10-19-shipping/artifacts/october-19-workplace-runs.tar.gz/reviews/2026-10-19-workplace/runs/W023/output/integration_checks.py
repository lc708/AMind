"""Offline regression checks through the documented subprocess CLI.

Fixtures, subprocess temporary files, and captured results stay in output/.
No helper imports or external services are used by the application.
"""
import copy
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT / 'repo'
OUT = ROOT / 'output'
FIXTURES = OUT / 'fixtures'
FIXTURES.mkdir(exist_ok=True)
BASE_MANIFEST = json.loads((REPO / 'examples/saved-run/manifest.json').read_text())
BASE_RESULTS = [json.loads(s) for s in (REPO / 'examples/saved-run/results.jsonl').read_text().splitlines()]
BASE_EVENTS = [json.loads(s) for s in (REPO / 'examples/saved-run/attempts.jsonl').read_text().splitlines()]
BASE_RATES = json.loads((REPO / 'examples/rates.json').read_text())
CAPTURED = []


def ready_fixture():
    manifest, results, events, rates = copy.deepcopy((BASE_MANIFEST, BASE_RESULTS, BASE_EVENTS, BASE_RATES))
    row = copy.deepcopy(results[0])
    row['case_id'] = row['result_identity']['case_id'] = 'account-recovery'
    results.append(row)
    events.extend([
        {'event': 'started', 'attempt_id': 'recovered', 'case_id': 'account-recovery', 'rep': 0},
        {'event': 'finished', 'attempt_id': 'recovered', 'case_id': 'account-recovery', 'rep': 0,
         'status': 'ok', 'cost_usd': 0.1}])
    return manifest, results, events, rates


class CLIIntegration(unittest.TestCase):
    def run_cli(self, data=None, variant='candidate', raw=None):
        data = data or ready_fixture()
        manifest, results, events, rates = data
        folder = FIXTURES / f'{len(CAPTURED):03d}'
        folder.mkdir(exist_ok=True)
        files = {'manifest.json': json.dumps(manifest), 'rates.json': json.dumps(rates),
                 'results.jsonl': ''.join(json.dumps(r) + '\n' for r in results),
                 'attempts.jsonl': ''.join(json.dumps(e) + '\n' for e in events)}
        if raw:
            files.update(raw)
        for name, content in files.items():
            (folder / name).write_text(content, encoding='utf-8')
        cmd = [sys.executable, '-m', 'releaseboard', '--bundle', str(folder),
               '--rates', str(folder / 'rates.json'), '--variant', variant]
        env = dict(os.environ, TMPDIR=str(OUT / 'tmp'), PYTHONDONTWRITEBYTECODE='1')
        proc = subprocess.run(cmd, cwd=REPO, env=env, capture_output=True, text=True)
        self.assertFalse(proc.stderr, proc.stderr)
        packet = json.loads(proc.stdout)
        CAPTURED.append({'test': self.id(), 'fixture': str(folder.relative_to(ROOT)),
                         'exit_code': proc.returncode, 'packet': packet})
        return proc.returncode, packet

    def report(self, data=None, **kwargs):
        code, packet = self.run_cli(data, **kwargs)
        self.assertEqual(code, 0, packet)
        self.assertEqual(set(packet), {'release_id', 'variant', 'split', 'planned_observations',
                         'scored_observations', 'missing', 'metrics', 'attempts', 'cost',
                         'coverage', 'integrity', 'decision'})
        return packet

    def test_clean_release_and_noop(self):
        first, second = self.report(), self.report()
        self.assertEqual(first, second)
        self.assertEqual(first['decision'], 'ready')
        self.assertEqual(first['integrity']['status'], 'verified')
        self.assertEqual(first['scored_observations'], 3)
        self.assertAlmostEqual(first['cost']['total_usd'], .5)

    def test_planned_repetitions_and_order(self):
        data = ready_fixture()
        data[0]['repetitions'] = 2
        packet = self.report(data)
        self.assertEqual(packet['planned_observations'], 6)
        self.assertEqual(packet['missing'], [{'case_id': c, 'rep': 1} for c in data[0]['case_ids']])
        self.assertEqual(packet['coverage']['status'], 'incomplete')
        self.assertEqual(packet['decision'], 'hold')
        for row in copy.deepcopy(data[1]):
            row['rep'] = row['result_identity']['rep'] = 1
            data[1].append(row)
        packet = self.report(data)
        self.assertEqual(packet['decision'], 'ready')
        data[1].reverse()
        data[2][:] = data[2][4:] + data[2][:4]  # reorder complete attempts
        self.assertEqual(packet, self.report(data))

    def test_identity_mismatches(self):
        for field in ['comparison_hash', 'treatment_hash', 'case_id', 'rep', 'extra']:
            with self.subTest(field=field):
                data = ready_fixture()
                data[1][0]['result_identity'][field] = 'foreign'
                packet = self.report(data)
                self.assertIn('result_identity_mismatch', packet['integrity']['issues'])
                self.assertEqual(packet['scored_observations'], 2)
                self.assertEqual(packet['decision'], 'hold')
        data = ready_fixture()
        data[1][0]['result_identity']['rep'] = False
        self.assertEqual(self.report(data)['decision'], 'hold')
        packet = self.report(variant='other')
        self.assertIn('variant_mismatch', packet['integrity']['issues'])
        self.assertEqual(packet['decision'], 'hold')
        for field in ['provider', 'interface', 'model', 'service_tier', 'region']:
            data = ready_fixture()
            data[1][0]['billing_identity'][field] = 'other'
            packet = self.report(data)
            self.assertIn('serving_identity_mismatch', packet['integrity']['issues'])
            self.assertEqual(packet['decision'], 'hold')
        data = ready_fixture()
        del data[1][0]['billing_identity']
        self.assertEqual(self.report(data)['scored_observations'], 2)

    def test_duplicate_and_unexpected_results(self):
        data = ready_fixture()
        data[1].append(copy.deepcopy(data[1][0]))
        packet = self.report(data)
        self.assertIn('duplicate_result', packet['integrity']['issues'])
        self.assertEqual(packet['scored_observations'], 2)
        self.assertEqual(packet['decision'], 'hold')
        for case, rep in [('foreign', 0), ('order-return', -1), ('order-return', False), ({}, 0)]:
            data = ready_fixture()
            data[1].append({'case_id': case, 'rep': rep})
            packet = self.report(data)
            self.assertIn('unexpected_result', packet['integrity']['issues'])
            self.assertEqual(packet['decision'], 'hold')

    def test_all_grade_failures_and_gate(self):
        for grade in [None, [], {}, {'quality': True}, {'quality': float('nan')},
                      {'quality': float('inf')}, {'quality': 1.1}, {'quality': -.1},
                      {'quality': '1'}, {'quality': 1, 'extra': 1}]:
            data = ready_fixture()
            data[1][0]['grade'] = grade
            packet = self.report(data)
            self.assertIn('invalid_grade', packet['integrity']['issues'])
            self.assertEqual(packet['scored_observations'], 2)
            self.assertEqual(packet['decision'], 'hold')
        data = ready_fixture()
        for row in data[1]:
            row['grade']['quality'] = .7
        self.assertEqual(self.report(data)['decision'], 'hold')
        data = ready_fixture()
        data[1].clear()
        packet = self.report(data)
        self.assertIsNone(packet['metrics']['quality']['mean'])
        self.assertEqual(len(packet['missing']), 3)
        data = ready_fixture()
        data[1][0]['status'] = 'failed'
        self.assertEqual(self.report(data)['scored_observations'], 2)

    def test_multiple_metrics(self):
        data = ready_fixture()
        data[0]['metrics'].append({'id': 'safety', 'min': 0, 'max': 1, 'min_mean': .9})
        for row in data[1]:
            row['grade']['safety'] = 1
        self.assertEqual(self.report(data)['decision'], 'ready')
        for row in data[1]:
            row['grade']['safety'] = .8
        self.assertEqual(self.report(data)['decision'], 'hold')

    def test_stage_coverage(self):
        changes = [lambda stages: stages.pop(), lambda stages: stages.append(copy.deepcopy(stages[0])),
                   lambda stages: stages[0].update(total=2),
                   lambda stages: stages[0].update(coverage=.9),
                   lambda stages: stages[0].update(coverage=True),
                   lambda stages: stages[0].update(uncovered=['pending']),
                   lambda stages: stages[0].update(counts={'succeeded': 2, 'failed': 1}),
                   lambda stages: stages[0].update(counts={'succeeded': 3, 'failed': -1}),
                   lambda stages: stages[0].update(counts={'succeeded': 3, 'failed': True}),
                   lambda stages: stages[0].update(id={})]
        for change in changes:
            data = ready_fixture()
            change(data[1][0]['coverage']['stages'])
            packet = self.report(data)
            self.assertEqual(packet['coverage']['status'], 'incomplete')
            self.assertEqual(packet['decision'], 'hold')
        for coverage in [None, {}, {'stages': None}, {'stages': {}}, {'stages': [1]}]:
            data = ready_fixture()
            data[1][0]['coverage'] = coverage
            self.assertEqual(self.report(data)['coverage']['status'], 'incomplete')
        data = ready_fixture()
        del data[0]['required_stages']
        packet = self.report(data)
        self.assertEqual(packet['coverage']['status'], 'unmeasured')
        self.assertEqual(packet['decision'], 'hold')

    def test_failed_calls_interrupted_and_duplicate_ledger(self):
        data = ready_fixture()
        data[2][1]['status'] = 'failed'
        packet = self.report(data)
        self.assertAlmostEqual(packet['cost']['known_usd'], .5)
        self.assertEqual(packet['attempts']['failed'], 1)
        data[2].append({'event': 'started', 'attempt_id': 'judge', 'case_id': 'order-return', 'rep': 0})
        packet = self.report(data)
        self.assertEqual(packet['attempts']['interrupted'], 1)
        self.assertEqual(packet['cost']['unknown_attempts'], 1)
        self.assertAlmostEqual(packet['cost']['known_usd'], .5)
        self.assertIsNone(packet['cost']['total_usd'])
        self.assertEqual(packet['decision'], 'hold')
        for index, issue in [(0, 'duplicate_start'), (1, 'duplicate_finish')]:
            data = ready_fixture()
            data[2].append(copy.deepcopy(data[2][index]))
            packet = self.report(data)
            self.assertIn(issue, packet['integrity']['issues'])
            self.assertEqual(packet['attempts']['finished'], 3)
            self.assertEqual(packet['attempts']['started'], 3)
            self.assertAlmostEqual(packet['cost']['known_usd'], .5)
            self.assertEqual(packet['decision'], 'hold')
        for mutation in ['orphan', 'case', 'rep', 'order']:
            data = ready_fixture()
            if mutation == 'orphan':
                del data[2][0]
            elif mutation == 'case':
                data[2][1]['case_id'] = 'invoice-correction'
            elif mutation == 'rep':
                data[2][1]['rep'] = 1
            else:
                data[2][0], data[2][1] = data[2][1], data[2][0]
            packet = self.report(data)
            self.assertIn('unmatched_finished', packet['integrity']['issues'])
            self.assertEqual(packet['decision'], 'hold')

    def test_explicit_costs(self):
        for cost in [None, True, False, -1, '0.2', float('nan'), float('inf'), [], {}]:
            data = ready_fixture()
            data[2][1]['cost_usd'] = cost
            packet = self.report(data)
            self.assertEqual(packet['cost']['unknown_attempts'], 1)
            self.assertAlmostEqual(packet['cost']['known_usd'], .3)
            self.assertIsNone(packet['cost']['total_usd'])
            self.assertEqual(packet['decision'], 'hold')
        data = ready_fixture()
        data[2][1]['cost_usd'] = 0
        packet = self.report(data)
        self.assertAlmostEqual(packet['cost']['total_usd'], .3)
        self.assertEqual(packet['decision'], 'ready')

    def estimated(self, mode='text'):
        data = ready_fixture()
        event = data[2][1]
        del event['cost_usd']
        event['billing_identity'] = copy.deepcopy(data[0]['expected_billing_identity'])
        event['all_billable_usage_included'] = True
        if mode == 'text':
            event['usage'] = {'input_tokens': 1000, 'cached_input_tokens': 200,
                              'output_tokens': 500, 'reasoning_tokens': 100}
        else:
            event['billing_identity']['interface'] = 'decisions'
            event['usage'] = {'input_tokens': 1000}
        return data

    def test_rates_and_usage(self):
        data = self.estimated()
        packet = self.report(data)
        self.assertAlmostEqual(packet['cost']['total_usd'], .3182)
        self.assertEqual(packet['decision'], 'ready')
        self.assertAlmostEqual(self.report(self.estimated('input_only'))['cost']['total_usd'], .302)
        for field in ['provider', 'interface', 'model', 'service_tier', 'region']:
            data = self.estimated()
            data[2][1]['billing_identity'][field] = 'foreign'
            self.assertIsNone(self.report(data)['cost']['total_usd'])
        mutations = [lambda e: e.pop('all_billable_usage_included'),
                     lambda e: e.update(all_billable_usage_included=False),
                     lambda e: e['usage'].update(cached_input_tokens=1001),
                     lambda e: e['usage'].update(reasoning_tokens=501),
                     lambda e: e['usage'].update(input_tokens=1.5),
                     lambda e: e['usage'].update(output_tokens=True),
                     lambda e: e['usage'].update(native_usage=100),
                     lambda e: e.update(usage={'native': 4}),
                     lambda e: e.update(billing_identity={'model': 'support-model'})]
        for change in mutations:
            data = self.estimated()
            change(data[2][1])
            packet = self.report(data)
            self.assertIsNone(packet['cost']['total_usd'])
            self.assertEqual(packet['cost']['unknown_attempts'], 1)
            self.assertEqual(packet['decision'], 'hold')
        for tokens in [True, 1.2, -1]:
            data = self.estimated('input_only')
            data[2][1]['usage']['input_tokens'] = tokens
            self.assertIsNone(self.report(data)['cost']['total_usd'])
        data = self.estimated('input_only')
        data[2][1]['usage']['output_tokens'] = 1
        self.assertIsNone(self.report(data)['cost']['total_usd'])
        data = self.estimated()
        data[3]['rates'].append(copy.deepcopy(data[3]['rates'][0]))
        self.assertIsNone(self.report(data)['cost']['total_usd'])
        data = self.estimated()
        data[3]['rates'][0]['mode'] = 'native'
        self.assertIsNone(self.report(data)['cost']['total_usd'])

    def test_malformed_input_is_json_exit_two(self):
        for name, raw in [('manifest.json', '{'), ('manifest.json', '[]'),
                          ('results.jsonl', '{broken\n'), ('results.jsonl', '[]\n'),
                          ('attempts.jsonl', 'null\n'), ('rates.json', '[]'),
                          ('rates.json', '{"rates":null}')]:
            code, packet = self.run_cli(raw={name: raw})
            self.assertEqual(code, 2, packet)
            self.assertEqual(set(packet), {'error'})
        for field, value in [('case_ids', ['a', 'a']), ('case_ids', [{}]), ('repetitions', True),
                             ('repetitions', 0), ('required_stages', []), ('metrics', []),
                             ('expected_billing_identity', {'model': 'support-model'})]:
            data = ready_fixture()
            data[0][field] = value
            code, packet = self.run_cli(data)
            self.assertEqual(code, 2, packet)
            self.assertIn('error', packet)
        for field, value in [('attempt_id', ''), ('rep', False), ('case_id', None), ('event', 'replayed')]:
            data = ready_fixture()
            data[2][0][field] = value
            packet = self.report(data)
            self.assertIn('invalid_attempt_event', packet['integrity']['issues'])
            self.assertEqual(packet['decision'], 'hold')


if __name__ == '__main__':
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(CLIIntegration)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    (OUT / 'integration-results.json').write_text(json.dumps({
        'tests_run': result.testsRun, 'cli_invocations': len(CAPTURED),
        'successful': result.wasSuccessful(), 'runs': CAPTURED}, indent=2, allow_nan=False) + '\n')
    raise SystemExit(0 if result.wasSuccessful() else 1)
