Releaseboard incident repair

The original CLI marked the saved export ready with only 2 of 3 planned observations.
The repaired CLI preserves the missing account-recovery result, holds the release,
and retains the known $0.40 subtotal. Baseline source is retained in output/baseline;
verification.json contains both actual subprocess outputs and source hashes.

Changes:
- report.py: validate manifest/configuration, join against all planned case/repetition
  pairs, reject duplicate/unplanned or incompatible results, check every metric,
  require complete declared stage evidence, and gate readiness on all evidence.
- accounting.py: deduplicate attempt events without overwriting earlier evidence,
  flag unmatched/replayed events, include failed calls and interrupted unknowns,
  preserve known subtotals, and price only exact supported normalized usage scopes.
  Cached input and reasoning output remain subsets, never extra charges.
- __main__.py: retain the documented flags, single JSON packet and exit codes;
  read UTF-8 explicitly and identify malformed JSONL lines in JSON errors.

Verification:
- Public tests: 3 passed (unmodified repo/tests/test_public.py).
- Local integration: 11 groups, 112 subprocess calls through python3 -m releaseboard.
  Cases include a ready control, deterministic repeat, reordered independent
  attempts, missing repetitions, failed results, invalid grades, all-metric gates,
  result/serving identity substitutions, duplicate results/ledger events,
  interrupted judges, invalid/zero costs, scoped text/input-only estimates,
  unsupported/native usage, incomplete coverage, and malformed input exit 2.
- An isolated interpreter ran a separate copy of the product successfully using
  only its own source and examples, without the skills directory on its path.

Reproduce from the workspace root:
  TMPDIR="$PWD/output/tmp" PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s repo/tests -v
  python3 output/integration_checks.py
  python3 output/verify_delivery.py

The application itself runs from repo with the command documented in README.md.
All integrations use local fixtures under output/fixtures. This is deterministic
local application verification; no external service or model quality was measured.
