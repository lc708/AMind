"""Capture public tests, saved-export regression, and independent checkout run."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT / 'repo'
OUT = ROOT / 'output'
ENV = dict(os.environ, TMPDIR=str(OUT / 'tmp'), PYTHONDONTWRITEBYTECODE='1')


def capture(command, cwd):
    proc = subprocess.run(command, cwd=cwd, env=ENV, text=True, capture_output=True)
    return {'command': command, 'exit_code': proc.returncode,
            'stdout': proc.stdout, 'stderr': proc.stderr}


args = ['--bundle', str(REPO / 'examples/saved-run'), '--rates',
        str(REPO / 'examples/rates.json'), '--variant', 'candidate']
baseline = capture([sys.executable, '-m', 'baseline'] + args, OUT)
fixed = capture([sys.executable, '-m', 'releaseboard'] + args, REPO)
public = capture([sys.executable, '-m', 'unittest', 'discover', '-s', 'tests', '-v'], REPO)
(OUT / 'public-tests.txt').write_text(public['stdout'] + public['stderr'])
# Copy only the actual product; skills/output are unavailable to this process.
standalone_path = OUT / 'standalone-product'
if standalone_path.exists():
    shutil.rmtree(standalone_path)
shutil.copytree(REPO, standalone_path, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
standalone = capture([sys.executable, '-I', '-c',
    'import runpy,sys; sys.path.insert(0,"."); runpy.run_module("releaseboard",run_name="__main__")',
    '--bundle', 'examples/saved-run', '--rates', 'examples/rates.json', '--variant', 'candidate'],
    standalone_path)
checks = json.loads((OUT / 'integration-results.json').read_text())
artifacts = {
    'baseline_saved_export': baseline, 'fixed_saved_export': fixed,
    'public_tests': public, 'standalone_product': standalone,
    'integration': {'tests_run': checks['tests_run'], 'cli_invocations': checks['cli_invocations'],
                    'successful': checks['successful']},
    'source_sha256': {str(p.relative_to(REPO)): hashlib.sha256(p.read_bytes()).hexdigest()
                      for p in sorted((REPO / 'releaseboard').glob('*.py'))},
}
(OUT / 'verification.json').write_text(json.dumps(artifacts, indent=2) + '\n')
assert baseline['exit_code'] == fixed['exit_code'] == public['exit_code'] == standalone['exit_code'] == 0
before, after = json.loads(baseline['stdout']), json.loads(fixed['stdout'])
assert before['decision'] == 'ready' and after['decision'] == 'hold'
assert after['planned_observations'] == 3 and after['scored_observations'] == 2
assert after['cost']['known_usd'] == .4
assert json.loads(standalone['stdout']) == after
assert checks['successful']
print(json.dumps({'public_tests': '3 passed', 'integration_groups': checks['tests_run'],
                  'cli_invocations': checks['cli_invocations'], 'standalone': 'passed',
                  'saved_export': {'before': before['decision'], 'after': after['decision']}}))
