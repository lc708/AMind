"""Build one release dashboard JSON from saved local evidence."""
import argparse
import json
from pathlib import Path
from .report import build


def jsonl(path):
    rows = []
    for number, line in enumerate(path.read_text(encoding='utf-8').splitlines(), 1):
        if line.strip():
            try:
                rows.append(json.loads(line))
            except ValueError as exc:
                raise ValueError(f'{path.name}:{number}: {exc}') from exc
    return rows


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--bundle', required=True, type=Path)
    p.add_argument('--rates', required=True, type=Path)
    p.add_argument('--variant', required=True)
    a = p.parse_args()
    try:
        manifest = json.loads((a.bundle / 'manifest.json').read_text(encoding='utf-8'))
        report = build(manifest, jsonl(a.bundle / 'results.jsonl'), jsonl(a.bundle / 'attempts.jsonl'),
                       json.loads(a.rates.read_text(encoding='utf-8')), a.variant)
        print(json.dumps(report, allow_nan=False))
        return 0
    except (OSError, ValueError, KeyError, TypeError) as exc:
        print(json.dumps({'error': str(exc)}))
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
