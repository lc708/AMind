# Incident 73 repair

The intake CLI now preserves uncertain deliveries across process exits, cumulative
attempt budgets and cancellation. Reports and summary receipts retain the entire
submitted population, including inspection and review failures. Tenant/job lookup,
operation keys and reconciliation records use the full tenant identity.

## Cause and changes

- `work` called the receiver before committing its running record and attempt.
  The simulated receiver could append a receipt and exit 17 while SQLite still
  said pending. Intent and one attempt now commit atomically **before** receiver
  invocation. Exceptions, invalid outcomes and crashes leave running/unknown
  work; restarts never replay it automatically. Only new dispatches cost attempts.
- Each work invocation reset attempts and cleared cancellation. Those resets are
  removed. Report, identical submit and reconcile preserve both facts. Explicit
  resume only clears cancellation; it cannot increase the original budget.
- Review ignored inspection dependencies and summary read unresolved rows.
  Review now waits for pending/unknown inspection, or becomes `not_covered` after
  known inspection failure. Summary waits until every item dependency is settled.
  Known failures can be summarized without pretending the items succeeded.
- Coverage counted inspection alone. It now requires inspection **and** review
  success for each original item. Reports include per-stage totals, counts and
  uncovered IDs. Completion additionally requires successful summary delivery.
  The existing rows/result representation and CLI options are retained.
- Job lookup and operation-key hashing omitted tenant identity. All lookups and
  new operation keys now include it. Immutable submission comparison and creation
  share a transaction; existing populations, payloads and budgets cannot change.
- Reconciliation could overwrite pending or settled work and ignored evidence.
  It now requires an existing running row, succeeded/failed state, explicit result
  and nonblank textual evidence. Outcome and evidence audit record commit together,
  scoped to tenant/job/stage/item and the persisted operation key. It neither
  dispatches a receipt nor consumes an attempt. A local POSIX advisory lock
  serializes workers and reconciliation, while cancel/report remain available.
- Receiver/filesystem and SQLite failures produce the CLI's JSON error and exit 2.
  Process exit 17 remains the crash-replay signal.

## Reproduction and verification

From `repo/`, use Python 3 (this environment has `python3`, without a `python`
command). No dependency installation, skill directory or provider SDK is needed:

```sh
mkdir -p ../output/tmp
TMPDIR="$PWD/../output/tmp" PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests
PYTHONDONTWRITEBYTECODE=1 python3 ../output/test_incident73.py
PYTHONDONTWRITEBYTECODE=1 python3 ../output/replay_incident73.py
```

All 3 existing public tests and 14 added regressions pass. The additional tests
invoke `python3 -m intake` in fresh processes, with all fixtures under `output/`.
They cover both saved requests, inspect/review crashes, receipt-based recovery,
no automatic replay, independent-item progress, cumulative exhaustion, durable cancellation, immutable
specifications, failed review coverage, tenant isolation, invalid reconciliation,
receiver I/O failure and the local coordinator lock. A restored summary-unknown
fixture separately verifies that failed/unknown summary cannot claim completion;
that fixture is explicitly seeded and is not evidence of a delivered receipt.

`output/public-tests.log` and `output/incident73-tests.log` retain test results.
`output/verification.json` points to retained SQLite, requests, JSON reports and
actual JSONL receipts produced by the replay script. In particular:

1. Submit `traces/new-job.json`, then work: four receipts, coverage 0.5, failed
   invoice-B inspection, `not_covered` invoice-B review and incomplete job status.
2. Submit `traces/crash-job.json`, then work: exit 17 after one inspect receipt.
   Report says unknown and attempts 1. Another work invocation adds zero receipts.
3. Reconcile that inspection using its actual receipt outcome and operation key
   as external evidence. Work finishes review and summary at attempts 3, without
   delivering inspection twice. A second tenant using that job number completes
   independently with distinct operation keys.

The public invocation remains:

```sh
python3 -m intake --db jobs.sqlite --request request.json --receipts receipts.jsonl
```

## Limits and recovery boundaries

This is standard-library, local simulated-receiver verification. No network,
model calls, quality comparison, production deployment or distributed lock was
used. The local coordinator lock uses POSIX `fcntl` and a shared local database
path; distributed workers need a separate lease/coordination design. Cancellation
prevents subsequent dispatch and cannot undo an effect already dispatched.

The service checks evidence shape and records it, but cannot authenticate an
operator's external evidence. Reconciliation must use a real receiver outcome;
absence of a local result is not proof of failure. There is no automatic retry of
failed or unknown effects, and no claim of global exactly-once delivery.

Existing databases open without dropping rows; the evidence table is additive.
Already persisted operation keys are retained for receipt correlation. Keys
created before this patch may lack tenant separation; this patch cannot safely
rewrite an already dispatched external identity. Likewise a pre-patch pending row
may conceal a delivery made before its running record was committed. Before
resuming such a legacy journal, operators must compare external receipts and
restore actual unknown/settled states through a controlled migration. The patch
cannot infer those historical effects from SQLite alone. New jobs and dispatches
under this version have the tested durable-intent and tenant-key guarantees.

Implementation follows the durable intent, unknown-outcome reconciliation and
required-item coverage contracts described in AMind Engineering's packaged
`workflow-recipes.md` and `scripts/workflow_contract.py` (Apache-2.0). No skill code
is imported or required at runtime; this repository implements its own intake
schema and CLI adapter using Python's standard library.
