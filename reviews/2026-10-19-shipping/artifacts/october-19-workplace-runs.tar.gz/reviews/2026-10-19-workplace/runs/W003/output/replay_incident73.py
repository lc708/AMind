"""Retain real CLI replay artifacts, without network or external writes."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'repo'
FIXTURE = Path(tempfile.mkdtemp(prefix='incident73-', dir=ROOT / 'output'))
DB = FIXTURE / 'jobs.sqlite'
RECEIPTS = FIXTURE / 'receipts.jsonl'
steps = []


def call(request, expected=0):
    index = len(steps)
    req = FIXTURE / ('%02d-request.json' % index)
    req.write_text(json.dumps(request, indent=2) + '\n')
    p = subprocess.run([sys.executable, '-m', 'intake', '--db', str(DB),
                        '--request', str(req), '--receipts', str(RECEIPTS)],
                       cwd=REPO, capture_output=True, text=True)
    answer = json.loads(p.stdout) if p.stdout else None
    assert p.returncode == expected, (p.returncode, p.stdout, p.stderr)
    step = dict(request=request, exit_code=p.returncode, report=answer)
    steps.append(step)
    (FIXTURE / ('%02d-result.json' % index)).write_text(json.dumps(step, indent=2) + '\n')
    return answer


def command(op, job, tenant='acme', **extra):
    return call(dict(op=op, job=job, tenant=tenant, **extra))


new = json.loads((REPO / 'traces/new-job.json').read_text())
call(new)
gap = command('work', new['job'])
assert gap['coverage'] == .5 and gap['status'] == 'incomplete'
crash = json.loads((REPO / 'traces/crash-job.json').read_text())
call(crash)
call(dict(op='work', tenant='acme', job=crash['job']), expected=17)
unknown = command('report', crash['job'])
assert unknown['status'] == 'unknown' and unknown['attempts'] == 1
before = RECEIPTS.read_text().splitlines()
command('work', crash['job'])
assert RECEIPTS.read_text().splitlines() == before
receipt = json.loads(before[-1])
call(dict(op='submit', tenant='beta', job=crash['job'], spec={'items': [{'id': receipt['item']}], 'max_attempts': 3}))
beta = command('work', crash['job'], tenant='beta')
assert beta['status'] == 'completed'
keys = {r['operation_key'] for r in beta['rows']}
assert receipt['operation_key'] not in keys
command('reconcile', crash['job'], stage=receipt['stage'], item=receipt['item'],
        state=receipt['outcome']['status'], result=receipt['outcome']['output'],
        evidence='receipts.jsonl line %d; operation_key=%s' % (len(before), receipt['operation_key']))
complete = command('work', crash['job'])
assert complete['status'] == 'completed' and complete['attempts'] == 3
verification = dict(fixture=str(FIXTURE.relative_to(ROOT)), steps=steps,
                    checks={'failed_item_retained': True, 'crash_exit': 17,
                            'restart_added_receipts': 0, 'attempt_after_crash': 1,
                            'tenants_have_distinct_keys': True,
                            'reconciled_from_actual_receipt': True,
                            'completed_attempts': complete['attempts']})
(ROOT / 'output/verification.json').write_text(json.dumps(verification, indent=2) + '\n')
print(json.dumps(verification['checks'], indent=2))
