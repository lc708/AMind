import hashlib
import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path


def packed(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def operation_key(tenant, job, stage, item):
    return hashlib.sha256(packed([tenant, job, stage, item]).encode()).hexdigest()


class Store:
    def __init__(self, path):
        self.path = Path(path)
        self.db = sqlite3.connect(str(path), isolation_level=None)
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('PRAGMA synchronous=FULL')
        self.db.execute('CREATE TABLE IF NOT EXISTS jobs(tenant TEXT,job TEXT,spec TEXT,cancelled INTEGER,attempts INTEGER,PRIMARY KEY(tenant,job))')
        self.db.execute('CREATE TABLE IF NOT EXISTS work(tenant TEXT,job TEXT,stage TEXT,item TEXT,state TEXT,result TEXT,operation_key TEXT,PRIMARY KEY(tenant,job,stage,item))')
        self.db.execute('''CREATE TABLE IF NOT EXISTS reconciliations(
            tenant TEXT, job TEXT, stage TEXT, item TEXT, operation_key TEXT,
            state TEXT, result TEXT, evidence TEXT,
            PRIMARY KEY(tenant,job,stage,item))''')

    def close(self):
        self.db.close()

    @contextmanager
    def transaction(self):
        self.db.execute('BEGIN IMMEDIATE')
        try:
            yield
            self.db.execute('COMMIT')
        except BaseException:
            self.db.execute('ROLLBACK')
            raise

    @contextmanager
    def coordinator(self):
        # Local POSIX advisory lock, released by the OS even on process exit.
        # A free lock does not establish whether a remote effect succeeded.
        import fcntl
        with self.path.with_name(self.path.name + '.coordinator').open('a') as guard:
            try:
                fcntl.flock(guard, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                raise ValueError('another local coordinator is active') from None
            try:
                yield
            finally:
                fcntl.flock(guard, fcntl.LOCK_UN)

    def job(self, tenant, job):
        row = self.db.execute('SELECT spec,cancelled,attempts FROM jobs WHERE tenant=? AND job=?', (tenant, job)).fetchone()
        if row is None:
            raise ValueError('job not found for tenant')
        return {'spec': json.loads(row[0]), 'cancelled': bool(row[1]), 'attempts': row[2]}

    def rows(self, tenant, job):
        return [dict(zip(('stage', 'item', 'state', 'result', 'operation_key'), r))
                for r in self.db.execute('SELECT stage,item,state,result,operation_key FROM work WHERE tenant=? AND job=? ORDER BY rowid', (tenant, job))]

    def update(self, tenant, job, stage, item, state, result=None):
        self.db.execute('UPDATE work SET state=?,result=? WHERE tenant=? AND job=? AND stage=? AND item=?',
                        (state, packed(result), tenant, job, stage, item))
