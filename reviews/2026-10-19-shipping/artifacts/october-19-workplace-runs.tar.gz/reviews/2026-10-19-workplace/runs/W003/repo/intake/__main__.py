import argparse
import json
import sqlite3
import sys
from pathlib import Path
from .store import Store
from .service import handle


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', type=Path, required=True)
    parser.add_argument('--request', type=Path, required=True)
    parser.add_argument('--receipts', type=Path, required=True)
    args = parser.parse_args()
    store = None
    try:
        request = json.loads(args.request.read_text())
        store = Store(args.db)
        answer = handle(store, request, args.receipts)
        print(json.dumps(answer))
        return 0
    except (ValueError, KeyError, TypeError, OSError, sqlite3.Error) as exc:
        print(json.dumps({'error': str(exc)}))
        return 2
    finally:
        if store:
            store.close()


if __name__ == '__main__':
    sys.exit(main())
