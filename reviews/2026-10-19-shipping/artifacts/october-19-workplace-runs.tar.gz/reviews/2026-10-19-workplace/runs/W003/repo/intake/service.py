from .store import operation_key, packed
from .receiver import perform

STAGES = ('inspect', 'review', 'summary')
ITEM_STAGES = ('inspect', 'review')


def validate(spec):
    if not isinstance(spec, dict):
        raise ValueError('job specification must be an object')
    items = spec.get('items')
    limit = spec.get('max_attempts')
    if not isinstance(items, list) or not items:
        raise ValueError('nonempty item population required')
    ids = [i.get('id') for i in items if isinstance(i, dict)]
    if len(ids) != len(items) or any(not isinstance(i, str) or not i or i == '__all__' for i in ids) or len(set(ids)) != len(ids):
        raise ValueError('unique item IDs required')
    if type(limit) is not int or limit < 1:
        raise ValueError('positive max_attempts required')
    if any(i.get('payload') is not None and not isinstance(i['payload'], dict) for i in items):
        raise ValueError('item payload must be an object')
    packed(spec)  # Reject non-JSON/NaN input before storing any part of the job.
    return spec


def report(store, tenant, job):
    entry = store.job(tenant, job)
    rows = store.rows(tenant, job)
    population = [i['id'] for i in entry['spec']['items']]
    states = {(r['stage'], r['item']): r['state'] for r in rows}
    covered = [i for i in population if all(states.get((stage, i)) == 'succeeded' for stage in ITEM_STAGES)]
    unknown = any(r['state'] == 'running' for r in rows)
    pending = any(r['state'] == 'pending' for r in rows)
    complete = len(covered) == len(population) and states.get(('summary', '__all__')) == 'succeeded'
    status = 'unknown' if unknown else ('pending' if pending else ('completed' if complete else 'incomplete'))
    if entry['cancelled']:
        status = 'cancelled'
    stages = []
    for stage in STAGES:
        subset = [r for r in rows if r['stage'] == stage]
        counts = {}
        for row in subset:
            counts[row['state']] = counts.get(row['state'], 0) + 1
        stages.append({'stage': stage, 'total': len(subset), 'counts': counts,
                       'coverage': sum(r['state'] == 'succeeded' for r in subset) / len(subset),
                       'uncovered_ids': [r['item'] for r in subset if r['state'] != 'succeeded']})
    return {'tenant': tenant, 'job': job, 'status': status, 'attempts': entry['attempts'],
            'remaining_attempts': max(0, entry['spec']['max_attempts'] - entry['attempts']),
            'coverage': len(covered) / len(population), 'covered_ids': covered,
            'uncovered_ids': [i for i in population if i not in covered],
            'cancelled': entry['cancelled'], 'rows': rows, 'stages': stages}


def submit(store, tenant, job, spec):
    spec = validate(spec)
    with store.transaction():
        old = store.db.execute('SELECT spec FROM jobs WHERE tenant=? AND job=?', (tenant, job)).fetchone()
        if old:
            # Canonical JSON comparison distinguishes booleans from numbers.
            if old[0] != packed(spec):
                raise ValueError('immutable job specification differs')
        else:
            store.db.execute('INSERT INTO jobs VALUES(?,?,?,0,0)', (tenant, job, packed(spec)))
            for stage in STAGES:
                for item in (['__all__'] if stage == 'summary' else [i['id'] for i in spec['items']]):
                    store.db.execute('INSERT INTO work VALUES(?,?,?,?,?,?,?)',
                                     (tenant, job, stage, item, 'pending', None, operation_key(tenant, job, stage, item)))
    return report(store, tenant, job)


def work(store, tenant, job, receipts):
    with store.coordinator():
        for stage in STAGES:
            for row in [r for r in store.rows(tenant, job) if r['stage'] == stage]:
                if row['state'] != 'pending':
                    continue  # Settled failures and unknown effects never auto-replay.
                entry = store.job(tenant, job)
                if entry['cancelled']:
                    return report(store, tenant, job)
                previous = [r for r in store.rows(tenant, job) if r['stage'] in ITEM_STAGES]
                if stage == 'review':
                    dependency = next(r for r in previous if r['stage'] == 'inspect' and r['item'] == row['item'])
                    if dependency['state'] in ('running', 'pending'):
                        continue
                    if dependency['state'] != 'succeeded':
                        store.update(tenant, job, stage, row['item'], 'not_covered')
                        continue
                if stage == 'summary' and any(r['state'] in ('running', 'pending') for r in previous):
                    continue
                # Commit intent AND the cumulative attempt before calling the receiver.
                # A crash/exception thereafter is unknown, regardless of local output.
                with store.transaction():
                    entry = store.job(tenant, job)
                    if entry['cancelled'] or entry['attempts'] >= entry['spec']['max_attempts']:
                        return report(store, tenant, job)
                    store.update(tenant, job, stage, row['item'], 'running')
                    store.db.execute('UPDATE jobs SET attempts=attempts+1 WHERE tenant=? AND job=?', (tenant, job))
                context = {'tenant': tenant, 'job': job, 'stage': stage, 'item': row['item'],
                           'operation_key': row['operation_key'],
                           'payload': next((i.get('payload', {}) for i in entry['spec']['items'] if i['id'] == row['item']), {}),
                           'coverage': report(store, tenant, job)}
                outcome = perform(context, receipts)
                if not isinstance(outcome, dict) or outcome.get('status') not in ('succeeded', 'failed') or 'output' not in outcome:
                    raise ValueError('receiver outcome invalid; operation remains unknown')
                store.update(tenant, job, stage, row['item'], outcome['status'], outcome['output'])
    return report(store, tenant, job)


def reconcile(store, tenant, job, request):
    evidence = request.get('evidence')
    state = request.get('state')
    if state not in ('succeeded', 'failed') or not isinstance(evidence, str) or not evidence.strip() or 'result' not in request:
        raise ValueError('external outcome, result and nonempty evidence required')
    result = packed(request['result'])
    with store.coordinator(), store.transaction():
        target = next((r for r in store.rows(tenant, job) if r['stage'] == request.get('stage') and r['item'] == request.get('item')), None)
        if target is None or target['state'] != 'running':
            raise ValueError('exactly one unknown operation required')
        store.update(tenant, job, target['stage'], target['item'], state, request['result'])
        store.db.execute('INSERT INTO reconciliations VALUES(?,?,?,?,?,?,?,?)',
                         (tenant, job, target['stage'], target['item'], target['operation_key'], state, result, evidence))
    return report(store, tenant, job)


def handle(store, request, receipts):
    if not isinstance(request, dict):
        raise ValueError('request must be an object')
    tenant = request.get('tenant')
    job = request.get('job')
    op = request.get('op')
    if any(not isinstance(v, str) or not v for v in (tenant, job)):
        raise ValueError('trusted tenant and job identity required')
    if op == 'submit':
        return submit(store, tenant, job, request['spec'])
    store.job(tenant, job)
    if op == 'report':
        return report(store, tenant, job)
    if op == 'work':
        return work(store, tenant, job, receipts)
    if op in ('cancel', 'resume'):
        store.db.execute('UPDATE jobs SET cancelled=? WHERE tenant=? AND job=?', (int(op == 'cancel'), tenant, job))
        return report(store, tenant, job)
    if op == 'reconcile':
        return reconcile(store, tenant, job, request)
    raise ValueError('unknown operation')
