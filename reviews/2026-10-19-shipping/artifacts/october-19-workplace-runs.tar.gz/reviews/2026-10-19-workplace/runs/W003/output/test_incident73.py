"""Offline regressions through the public CLI; fixtures stay under output/."""
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'repo'
FIXTURES = ROOT / 'output' / 'tmp'
FIXTURES.mkdir(exist_ok=True)


class Incident73(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(dir=FIXTURES)
        self.path = Path(self.tmp.name)
        self.db = self.path / 'jobs.sqlite'
        self.receipts = self.path / 'receipts.jsonl'

    def tearDown(self):
        self.tmp.cleanup()

    def call(self, op, tenant='acme', job='J1', expected=0, **extra):
        request = self.path / 'request.json'
        request.write_text(json.dumps(dict(op=op, tenant=tenant, job=job, **extra)))
        child = subprocess.run([sys.executable, '-m', 'intake', '--db', str(self.db),
                                '--request', str(request), '--receipts', str(self.receipts)],
                               cwd=REPO, capture_output=True, text=True)
        self.assertEqual(child.returncode, expected, child.stdout + child.stderr)
        return json.loads(child.stdout) if child.stdout else None

    def submit(self, items=None, limit=8, **kwargs):
        spec = dict(items=items or [{'id': 'a'}], max_attempts=limit)
        return self.call('submit', spec=spec, **kwargs)

    def delivered(self):
        return [json.loads(line) for line in self.receipts.read_text().splitlines()] if self.receipts.exists() else []

    @staticmethod
    def row(report, stage, item='a'):
        return next(r for r in report['rows'] if r['stage'] == stage and r['item'] == item)

    def test_healthy_idempotent_and_summary_context(self):
        self.submit([{'id': 'a'}, {'id': 'b'}])
        r = self.call('work')
        self.assertEqual((r['status'], r['attempts'], r['coverage']), ('completed', 5, 1))
        self.assertEqual(self.delivered()[-1]['coverage']['covered_ids'], ['a', 'b'])
        self.assertEqual(self.call('work')['attempts'], 5)
        self.submit([{'id': 'a'}, {'id': 'b'}])
        self.assertEqual(len(self.delivered()), 5)

    def test_saved_request_inspection_failure_retains_population(self):
        req = json.loads((REPO / 'traces' / 'new-job.json').read_text())
        self.call(**req)
        r = self.call('work', job=req['job'])
        self.assertEqual((r['status'], r['coverage'], r['attempts']), ('incomplete', .5, 4))
        self.assertEqual(r['covered_ids'], ['invoice-A'])
        self.assertEqual(r['uncovered_ids'], ['invoice-B'])
        self.assertEqual(self.row(r, 'review', 'invoice-B')['state'], 'not_covered')
        self.assertEqual(self.delivered()[-1]['coverage']['coverage'], .5)
        self.call('work', job=req['job'])
        self.assertEqual(len(self.delivered()), 4)

    def test_unknown_item_blocks_summary_but_independent_items_can_progress(self):
        self.submit([{'id': 'a', 'payload': {'crash_after_effect': 'inspect'}}, {'id': 'b'}])
        self.call('work', expected=17)
        r = self.call('work')
        self.assertEqual((r['status'], r['coverage'], r['attempts']), ('unknown', .5, 3))
        self.assertEqual(r['covered_ids'], ['b'])
        self.assertEqual(self.row(r, 'review')['state'], 'pending')
        self.assertEqual(self.row(r, 'summary', '__all__')['state'], 'pending')
        self.assertEqual([r['stage'] for r in self.delivered()], ['inspect', 'inspect', 'review'])
        receipt = self.delivered()[0]
        self.call('reconcile', stage='inspect', item='a', state=receipt['outcome']['status'],
                  result=receipt['outcome']['output'], evidence='receipt line 1: ' + receipt['operation_key'])
        final = self.call('work')
        self.assertEqual((final['status'], final['coverage'], final['attempts']), ('completed', 1, 5))
        self.assertEqual(self.delivered()[-1]['coverage']['covered_ids'], ['a', 'b'])

    def test_failed_review_is_a_coverage_gap(self):
        self.submit([{'id': 'a', 'payload': {'review': 'fail'}}])
        r = self.call('work')
        self.assertEqual((r['status'], r['coverage'], r['uncovered_ids']), ('incomplete', 0, ['a']))
        self.assertEqual(self.delivered()[-1]['coverage']['coverage'], 0)

    def test_saved_crash_no_replay_then_reconcile_actual_receipt(self):
        req = json.loads((REPO / 'traces' / 'crash-job.json').read_text())
        self.call(**req)
        job, item = req['job'], req['spec']['items'][0]['id']
        self.call('work', job=job, expected=17)
        receipt = self.delivered()[0]
        r = self.call('report', job=job)
        self.assertEqual((r['status'], r['attempts']), ('unknown', 1))
        self.assertEqual(self.row(r, 'inspect', item)['operation_key'], receipt['operation_key'])
        self.call('work', job=job)
        self.assertEqual(len(self.delivered()), 1)
        self.assertEqual(self.call('report', job=job)['attempts'], 1)
        for evidence in (None, '', '  ', 42):
            self.call('reconcile', job=job, stage='inspect', item=item, state='succeeded',
                      result=receipt['outcome']['output'], evidence=evidence, expected=2)
        self.call('reconcile', job=job, stage='review', item=item, state='succeeded',
                  result={}, evidence='not an unknown row', expected=2)
        self.call('reconcile', job=job, stage='inspect', item=item, state=receipt['outcome']['status'],
                  result=receipt['outcome']['output'], evidence='local receipt line 1: ' + receipt['operation_key'])
        r = self.call('work', job=job)
        self.assertEqual((r['status'], r['attempts'], len(self.delivered())), ('completed', 3, 3))
        self.call('reconcile', job=job, stage='inspect', item=item, state='failed', result={}, evidence='overwrite', expected=2)
        with sqlite3.connect(self.db) as db:
            audit = db.execute('SELECT tenant,job,operation_key,evidence FROM reconciliations').fetchall()
        self.assertEqual(audit[0][:3], ('acme', job, receipt['operation_key']))
        self.assertTrue(audit[0][3])

    def test_review_crash_blocks_summary_and_coverage(self):
        self.submit([{'id': 'a', 'payload': {'crash_after_effect': 'review'}}])
        self.call('work', expected=17)
        r = self.call('work')
        self.assertEqual((r['status'], r['attempts'], r['coverage']), ('unknown', 2, 0))
        self.assertEqual(len(self.delivered()), 2)
        receipt = self.delivered()[-1]
        self.call('reconcile', stage='review', item='a', state='succeeded', result=receipt['outcome']['output'], evidence=receipt['operation_key'])
        self.assertEqual(self.call('work')['status'], 'completed')
        self.assertEqual(len(self.delivered()), 3)

    def test_cancel_resubmit_resume_preserve_budget(self):
        self.submit(limit=2)
        self.call('cancel')
        self.submit(limit=2)
        r = self.call('work')
        self.assertEqual((r['status'], r['attempts']), ('cancelled', 0))
        self.assertEqual(self.delivered(), [])
        self.call('resume')
        r = self.call('work')
        self.assertEqual((r['status'], r['attempts'], r['remaining_attempts']), ('pending', 2, 0))
        for op in ('report', 'work', 'cancel', 'resume', 'work'):
            self.assertEqual(self.call(op)['attempts'], 2)
        self.submit(limit=2)
        self.assertEqual(len(self.delivered()), 2)
        self.submit(limit=3, expected=2)
        self.assertEqual(self.call('work')['attempts'], 2)

    def test_crash_uses_last_attempt_and_cancel_survives_reconcile(self):
        items = [{'id': 'a', 'payload': {'inspect': 'fail', 'crash_after_effect': 'inspect'}}]
        self.submit(items, limit=1)
        self.call('work', expected=17)
        self.call('cancel')
        self.submit(items, limit=1)
        receipt = self.delivered()[0]
        r = self.call('reconcile', stage='inspect', item='a', state=receipt['outcome']['status'], result=receipt['outcome']['output'], evidence='local failed receipt: ' + receipt['operation_key'])
        self.assertTrue(r['cancelled'])
        self.assertEqual(self.call('work')['attempts'], 1)
        self.call('resume')
        r = self.call('work')
        self.assertEqual(self.row(r, 'review')['state'], 'not_covered')
        self.assertEqual((r['attempts'], r['remaining_attempts'], len(self.delivered())), (1, 0, 1))

    def test_tenant_identity_keys_and_recovery_isolation(self):
        self.submit([{'id': 'a', 'payload': {'crash_after_effect': 'inspect'}}])
        self.call('work', expected=17)
        first = self.delivered()[0]
        r = self.submit(tenant='beta', limit=3)
        self.assertNotEqual(first['operation_key'], self.row(r, 'inspect')['operation_key'])
        self.call('reconcile', tenant='beta', stage='inspect', item='a', state='succeeded', result={}, evidence='acme receipt', expected=2)
        self.call('cancel', tenant='beta')
        self.assertFalse(self.call('report')['cancelled'])
        self.call('resume', tenant='beta')
        self.assertEqual(self.call('work', tenant='beta')['status'], 'completed')
        self.assertEqual(self.call('report')['status'], 'unknown')
        self.call('report', tenant='absent', expected=2)
        self.call('cancel', tenant='absent', expected=2)

    def test_changed_population_payload_and_budget_rejected(self):
        self.submit()
        for spec in ({'items': [{'id': 'b'}], 'max_attempts': 8},
                     {'items': [{'id': 'a', 'payload': {'inspect': 'fail'}}], 'max_attempts': 8},
                     {'items': [{'id': 'a'}], 'max_attempts': 9}):
            self.call('submit', spec=spec, expected=2)
        r = self.call('work')
        self.assertEqual(r['status'], 'completed')

    def test_receiver_io_failure_leaves_unknown_and_json_error(self):
        self.submit()
        # The receiver cannot append to a directory. Intent must nevertheless
        # remain unknown; a transport exception cannot establish non-delivery.
        self.receipts.mkdir()
        self.call('work', expected=2)
        r = self.call('report')
        self.assertEqual((r['status'], r['attempts']), ('unknown', 1))
        self.assertEqual(self.row(r, 'inspect')['state'], 'running')
        self.receipts.rmdir()
        self.call('work')
        self.assertEqual(self.delivered(), [])

    def test_active_coordinator_blocks_dispatch_and_reconciliation(self):
        import fcntl
        self.submit()
        with Path(str(self.db) + '.coordinator').open('a') as guard:
            fcntl.flock(guard, fcntl.LOCK_EX | fcntl.LOCK_NB)
            self.call('work', expected=2)
            self.call('reconcile', stage='inspect', item='a', state='succeeded',
                      result={}, evidence='active operation', expected=2)
            self.assertEqual(self.call('report')['attempts'], 0)
            self.call('cancel')  # Control remains available during a live worker.
        self.assertTrue(self.call('work')['cancelled'])
        self.call('resume')
        self.assertEqual(self.call('work')['status'], 'completed')

    def test_invalid_inputs_are_json_errors_without_receipts(self):
        for spec in (None, [], {}, {'items': [], 'max_attempts': 1},
                     {'items': [{'id': 'a'}, {'id': 'a'}], 'max_attempts': 2},
                     {'items': [{'id': '__all__'}], 'max_attempts': 2},
                     {'items': [{'id': 'a'}], 'max_attempts': True},
                     {'items': [{'id': 'a', 'payload': 'invalid'}], 'max_attempts': 2}):
            self.call('submit', spec=spec, expected=2)
        self.assertEqual(self.delivered(), [])
        self.submit([{'id': 'a', 'payload': None}])
        self.assertEqual(self.call('work')['status'], 'completed')

    def test_summary_unknown_and_failed_do_not_claim_completion(self):
        # A restored journal fixture: item work completed, summary dispatched,
        # but no local terminal outcome. No fabricated delivery is made here.
        self.submit(limit=2)
        self.call('work')
        with sqlite3.connect(self.db) as db:
            db.execute("UPDATE work SET state='running' WHERE stage='summary'")
            db.execute('UPDATE jobs SET attempts=3')
        r = self.call('work')
        self.assertEqual((r['status'], r['coverage'], len(self.delivered())), ('unknown', 1, 2))
        self.call('reconcile', stage='summary', item='__all__', state='failed', result={'failure': 'confirmed by fixture'}, evidence='restored receiver failure record')
        self.assertEqual(self.call('report')['status'], 'incomplete')


if __name__ == '__main__':
    unittest.main(verbosity=2)
