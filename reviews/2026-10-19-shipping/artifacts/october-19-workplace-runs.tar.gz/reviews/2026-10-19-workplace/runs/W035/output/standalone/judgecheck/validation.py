"""Validate input structure; semantic evidence failures belong in review packets."""
from .calibration import finite_number


def validate_job(job):
    if not isinstance(job, dict):
        raise ValueError('input must be a JSON object')
    if not isinstance(job.get('positive_event'), str) or not job['positive_event'].strip():
        raise ValueError('positive_event must be a nonempty string')
    for name in ('current', 'baseline', 'drift_reference'):
        cohort = job.get(name)
        if name != 'current' and cohort is None:
            continue
        if not isinstance(cohort, dict) or not isinstance(cohort.get('records'), list):
            raise ValueError(name + ' must be an object with a records array')
        for row in cohort['records']:
            if not isinstance(row, dict) or not {'id', 'family', 'split', 'human', 'decision'} <= row.keys():
                raise ValueError(name + ' records require id, family, split, human and decision')
    if not isinstance(job.get('required_workers'), list):
        raise ValueError('required_workers must be an array')
    reports = job.get('worker_reports', [])
    if not isinstance(reports, list) or any(not isinstance(row, dict) for row in reports):
        raise ValueError('worker_reports must be an array of objects')
    limits = job.get('limits')
    if not isinstance(limits, dict):
        raise ValueError('limits must be an object')
    margin, families = limits.get('max_fpr_increase'), limits.get('min_labeled_families')
    if not finite_number(margin) or margin < 0:
        raise ValueError('max_fpr_increase must be a finite nonnegative number')
    if type(families) is not int or families < 0:
        raise ValueError('min_labeled_families must be a nonnegative integer')
