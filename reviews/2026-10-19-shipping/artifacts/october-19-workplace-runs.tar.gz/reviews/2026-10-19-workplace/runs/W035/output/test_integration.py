"""Offline CLI regression scenarios; all fixtures and artifacts stay in output/."""
import copy
import json
from pathlib import Path
import subprocess
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT / 'repo'
OUT = ROOT / 'output'


def job():
    return {'positive_event': 'genuine_support_policy_issue',
            'current': {'identity': {'dataset_version': 'd1', 'judge': 'current',
                                     'grader_version': 'g1', 'rubric': 'r1'},
                        'records': [{'id': 'p', 'family': 'positive', 'split': 'holdout',
                                     'human': 1, 'decision': 1},
                                    {'id': 'n', 'family': 'negative', 'split': 'holdout',
                                     'human': 0, 'decision': 0}]},
            'required_workers': ['security'],
            'worker_reports': [{'id': 'security', 'status': 'succeeded'}],
            'limits': {'max_fpr_increase': 0.25, 'min_labeled_families': 2},
            'deployment_prevalence': 0.001}


class CLIIntegration(unittest.TestCase):
    def run_job(self, data, code=0):
        name = self.id().split('.')[-1]
        path = OUT / (name + '.input.json')
        path.write_text(json.dumps(data))
        p = subprocess.run([sys.executable, '-m', 'judgecheck', '--input', str(path)],
                           cwd=REPO, capture_output=True, text=True)
        (OUT / (name + '.result.json')).write_text(p.stdout)
        self.assertEqual(p.returncode, code, p.stderr + p.stdout)
        self.assertEqual(p.stderr, '')
        result = json.loads(p.stdout)
        if code == 0:
            self.assertEqual(set(result), {'status', 'calibration', 'family_count', 'workers',
                                          'paired', 'drift', 'deployment_precision', 'integrity', 'limits'})
        return result

    def test_ready_complete_pairs_and_drift(self):
        data = job()
        data['baseline'] = copy.deepcopy(data['current'])
        data['baseline']['identity']['judge'] = 'old'
        data['baseline']['identity']['grader_version'] = 'old-g'
        data['baseline']['records'][0]['decision'] = 0
        data['drift_reference'] = copy.deepcopy(data['current'])
        data['drift_reference']['identity']['dataset_version'] = 'older-data'
        result = self.run_job(data)
        self.assertEqual(result['status'], 'ready_for_review')
        self.assertEqual(result['paired'], {'status': 'complete', 'pairs': 2,
                         'evaluated_pairs': 2, 'improved': 1, 'regressed': 0,
                         'agreement_delta': 0.5})
        self.assertEqual(result['drift']['status'], 'within_margin')

    def test_unknown_and_abstention(self):
        data = job()
        data['current']['records'] += [
            {'id': 'u', 'family': 'unresolved', 'split': 'holdout', 'human': None, 'decision': 1},
            {'id': 'a', 'family': 'abstain', 'split': 'holdout', 'human': 0, 'decision': None},
            {'id': 'both', 'family': 'neither', 'split': 'holdout', 'human': None, 'decision': None}]
        result = self.run_job(data)
        c = result['calibration']
        self.assertEqual(c['confusion'], {'tp': 1, 'tn': 1, 'fp': 0, 'fn': 0})
        self.assertEqual(c['denominators'], {'adjudicated': 3, 'human_positive': 1,
                         'human_negative': 2, 'evaluated': 2, 'evaluated_positive': 1,
                         'evaluated_negative': 1, 'abstained': 2, 'unknown_human': 2})
        self.assertEqual(c['judgment_coverage'], 0.4)
        self.assertEqual(result['family_count'], 3)
        self.assertEqual(result['status'], 'hold')

    def test_repeats_do_not_multiply_families(self):
        data = job()
        for rep in range(1, 4):
            for row in copy.deepcopy(data['current']['records'][:2]):
                row['rep'] = rep
                data['current']['records'].append(row)
        data['limits']['min_labeled_families'] = 3
        result = self.run_job(data)
        self.assertEqual(result['family_count'], 2)
        self.assertEqual(result['status'], 'hold')

    def test_duplicate_case(self):
        data = job()
        data['current']['records'].append(copy.deepcopy(data['current']['records'][0]))
        result = self.run_job(data)
        self.assertEqual(result['integrity']['status'], 'invalid')
        self.assertIn('duplicate_or_invalid_example', result['integrity']['issues'])
        self.assertEqual(result['status'], 'hold')

    def test_family_leakage(self):
        data = job()
        row = copy.deepcopy(data['current']['records'][0])
        row.update(id='other', split='train')
        data['current']['records'].append(row)
        result = self.run_job(data)
        self.assertIn('family_crosses_split', result['integrity']['issues'])
        self.assertEqual(result['status'], 'hold')

    def test_missing_negative_controls(self):
        data = job()
        data['current']['records'] = data['current']['records'][:1]
        data['drift_reference'] = copy.deepcopy(data['current'])
        result = self.run_job(data)
        self.assertIsNone(result['calibration']['fpr'])
        self.assertIn('fpr', result['calibration']['unmeasured'])
        self.assertEqual(result['drift']['status'], 'unmeasured')
        self.assertEqual(result['deployment_precision']['status'], 'unmeasured')
        self.assertEqual(result['status'], 'hold')

    def test_missing_positive_controls(self):
        data = job()
        data['current']['records'] = data['current']['records'][1:]
        result = self.run_job(data)
        for name in ('fnr', 'recall', 'precision'):
            self.assertIsNone(result['calibration'][name])
            self.assertIn(name, result['calibration']['unmeasured'])
        self.assertEqual(result['status'], 'hold')

    def test_empty_population(self):
        data = job()
        data['current']['records'] = []
        result = self.run_job(data)
        self.assertIsNone(result['calibration']['judgment_coverage'])
        self.assertEqual(result['family_count'], 0)
        self.assertEqual(result['status'], 'hold')

    def test_scenario_precision(self):
        data = job()
        data['current']['records'][1]['decision'] = 1
        result = self.run_job(data)
        self.assertEqual(result['calibration']['precision'], 0.5)
        self.assertAlmostEqual(result['deployment_precision']['value'], 0.001)
        self.assertEqual(result['deployment_precision']['status'], 'scenario')
        for value in (None, True, -0.1, 1.1, '0.5'):
            data['deployment_prevalence'] = value
            self.assertEqual(self.run_job(data)['deployment_precision'],
                             {'status': 'unmeasured', 'value': None})

    def test_pair_population_mismatch(self):
        for change in ('missing', 'extra', 'human', 'family', 'split', 'rep', 'dataset_version', 'rubric'):
            with self.subTest(change=change):
                data = job()
                data['baseline'] = copy.deepcopy(data['current'])
                old = data['baseline']
                if change == 'missing':
                    old['records'].pop()
                elif change == 'extra':
                    row = copy.deepcopy(old['records'][0]); row['id'] = 'extra'
                    old['records'].append(row)
                elif change in ('dataset_version', 'rubric'):
                    old['identity'][change] = 'different'
                else:
                    old['records'][0][change] = {'human': None, 'family': 'other',
                                                'split': 'train', 'rep': 1}[change]
                result = self.run_job(data)
                self.assertEqual(result['paired']['status'], 'invalid')
                self.assertEqual(result['status'], 'hold')

    def test_pair_partial(self):
        data = job()
        data['baseline'] = copy.deepcopy(data['current'])
        data['baseline']['records'][0]['decision'] = None
        result = self.run_job(data)
        self.assertEqual(result['paired']['status'], 'partial')
        self.assertEqual(result['paired']['pairs'], 2)
        self.assertEqual(result['paired']['evaluated_pairs'], 1)
        self.assertEqual(result['status'], 'hold')

    def test_drift_identity(self):
        for field in ('judge', 'grader_version', 'rubric'):
            data = job()
            data['drift_reference'] = copy.deepcopy(data['current'])
            data['drift_reference']['identity'][field] = 'different'
            result = self.run_job(data)
            self.assertEqual(result['drift']['status'], 'invalid')
            self.assertIsNone(result['drift']['fpr_delta'])
            self.assertEqual(result['status'], 'hold')

    def test_drift_margin(self):
        data = job()
        data['drift_reference'] = copy.deepcopy(data['current'])
        data['current']['records'][1]['decision'] = 1
        for margin, status in ((1, 'within_margin'), (0.99, 'alert')):
            data['limits']['max_fpr_increase'] = margin
            result = self.run_job(data)
            self.assertEqual(result['drift']['status'], status)
            self.assertEqual(result['drift']['fpr_delta'], 1)

    def test_worker_coverage(self):
        for reports in ([], [{'id': 'security', 'status': 'unknown'}],
                        [{'id': 'security', 'status': 'failed'}],
                        [{'id': 'security', 'status': 'succeeded'}] * 2,
                        [{'id': 'other', 'status': 'succeeded'}]):
            data = job(); data['worker_reports'] = reports
            result = self.run_job(data)
            self.assertEqual(result['workers']['completed'], 0)
            self.assertEqual(result['workers']['uncovered'], ['security'])
            self.assertEqual(result['status'], 'hold')
        data = job(); data['required_workers'] = []; data['worker_reports'] = []
        result = self.run_job(data)
        self.assertEqual(result['workers']['status'], 'unmeasured')
        self.assertEqual(result['status'], 'hold')

    def test_invalid_labels_and_identity(self):
        for field, value in (('human', True), ('decision', 1.0), ('id', []), ('rep', False)):
            data = job(); data['current']['records'][0][field] = value
            result = self.run_job(data)
            self.assertEqual(result['integrity']['status'], 'invalid')
            self.assertEqual(result['status'], 'hold')
        for identity in (None, [], 'bad', {}, {'judge': 'only'}):
            data = job(); data['current']['identity'] = identity
            data['drift_reference'] = copy.deepcopy(data['current'])
            result = self.run_job(data)
            self.assertEqual(result['drift']['status'], 'invalid')
            self.assertEqual(result['status'], 'hold')

    def test_strict_drift_decimal_boundary(self):
        data = job()
        rows = [{'id': str(i), 'family': str(i), 'split': 'holdout',
                 'human': 0, 'decision': int(i < 4)} for i in range(10)]
        rows.append({'id': 'p', 'family': 'p', 'split': 'holdout', 'human': 1, 'decision': 1})
        data['current']['records'] = rows
        data['drift_reference'] = copy.deepcopy(data['current'])
        for row in data['drift_reference']['records']:
            if row['human'] == 0:
                row['decision'] = int(row['id'] == '0')
        data['limits']['max_fpr_increase'] = 0.3
        result = self.run_job(data)
        self.assertEqual(result['drift']['status'], 'within_margin')
        self.assertEqual(result['drift']['fpr_delta'], 0.3)

    def test_all_binary_null_combinations(self):
        data = job()
        data['current']['records'] = [
            {'id': str(i), 'family': str(i), 'split': 'holdout', 'human': h, 'decision': d}
            for i, (h, d) in enumerate((h, d) for h in (0, 1, None) for d in (0, 1, None))]
        result = self.run_job(data)
        c = result['calibration']
        self.assertEqual(c['confusion'], dict(tp=1, tn=1, fp=1, fn=1))
        self.assertEqual(c['denominators'], {'adjudicated': 6, 'human_positive': 3,
                         'human_negative': 3, 'evaluated': 4, 'evaluated_positive': 2,
                         'evaluated_negative': 2, 'abstained': 3, 'unknown_human': 3})
        self.assertEqual(c['judgment_coverage'], 4 / 9)
        for name in ('fpr', 'fnr', 'recall', 'precision'):
            self.assertEqual(c[name], 0.5)

    def test_review_readiness_with_zero_positive_predictions(self):
        data = job()
        data['current']['records'][0]['decision'] = 0
        result = self.run_job(data)
        self.assertIsNone(result['calibration']['precision'])
        self.assertEqual(result['calibration']['fpr'], 0)
        self.assertEqual(result['calibration']['fnr'], 1)
        self.assertEqual(result['status'], 'ready_for_review')

    def test_malformed_shapes(self):
        for data in (None, [], {}, {'current': []}):
            self.assertIn('error', self.run_job(data, 2))
        for field, value in (('current', {'records': [None]}), ('worker_reports', [None]),
                             ('required_workers', None), ('limits', {})):
            data = job(); data[field] = value
            self.assertIn('error', self.run_job(data, 2))


if __name__ == '__main__':
    unittest.main(verbosity=2)
