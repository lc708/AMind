# Support judge review repair

The saved incident now returns `hold`: 5 evaluated records, 1 abstention, security uncovered, FPR 0.5, and scenario precision 0.0013328890369876708. The original implementation incorrectly returned `ready_for_review`, evaluated all 6 records, and counted every worker as completed.

Changes are in `repo/judgecheck/`: calibration keeps unresolved adjudications and abstentions outside confusion cells, preserves class denominators, reports unavailable rates, and counts distinct labeled families. Worker coverage requires explicit success from each unique required worker. Paired review validates full case/rep and human/family/split populations plus evaluation identities, and reports abstentions as partial. Drift fixes judge/grader/rubric identity and compares exact count ratios against the strict margin. Scenario precision uses sensitivity times prevalence over sensitivity times prevalence plus FPR times one minus prevalence. Input structure validation produces JSON errors with exit 2; semantic evidence failures produce hold packets with exit 0. CLI and output keys are preserved.

Verification commands, run from `repo/`:

- `python3 -m unittest discover -s tests -v`: 3/3 public tests pass (originally 2 failures).
- `python3 ../output/test_integration.py`: 19/19 integration tests pass, each invokes the public CLI; multiple cases also exercise invalid labels, incomplete pairs, changed identity fields, missing classes and worker states.
- `python3 -m judgecheck --input examples/review.json`: valid JSON hold packet.

Malformed JSON and invalid UTF-8 both return JSON errors and exit 2. A product-only copy in `output/standalone/` runs in Python isolated mode with no skill or installed helper dependency. Logs, fixtures, output packets and source hashes are in `output/verification.json` and its referenced files. These are deterministic offline software checks, not evidence of deployment quality, significance or model improvement. No external service or model was used; existing tests, skills and task configuration were not edited.
