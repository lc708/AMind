"""Reconcile the append-only call ledger without losing failed or unknown spend."""
import math

SCOPE = {'provider', 'interface', 'model', 'service_tier', 'region'}


def number(value):
    try:
        return type(value) in (int, float) and math.isfinite(value) and value >= 0
    except OverflowError:
        return False


def exact_scope(value):
    return (isinstance(value, dict) and set(value) == SCOPE
            and all(isinstance(v, str) and v for v in value.values()))


def price(event, rates):
    """Return reported cost or the priced subtotal; None means unpriceable.

    Completeness of an estimate is checked separately by account(), so a
    partial estimate retains its subtotal without becoming a known total.
    """
    if 'cost_usd' in event:
        value = event['cost_usd']
        return value if number(value) else None
    scope = event.get('billing_identity')
    if not exact_scope(scope):
        return None
    matches = [r for r in rates.get('rates', [])
               if exact_scope(r.get('identity')) and r['identity'] == scope]
    if len(matches) != 1:
        return None
    rate, usage = matches[0], event.get('usage')
    if not isinstance(usage, dict):
        return None
    mode = rate.get('mode')
    if mode == 'input_only':
        if (set(usage) != {'input_tokens'}
                or type(usage['input_tokens']) is not int or usage['input_tokens'] < 0
                or not number(rate.get('input_per_million'))):
            return None
        parts = [(usage['input_tokens'], rate['input_per_million'])]
    elif mode == 'text':
        required = {'input_tokens', 'cached_input_tokens', 'output_tokens'}
        if not required <= set(usage) or set(usage) - required - {'reasoning_tokens'}:
            return None
        if any(type(usage[k]) is not int or usage[k] < 0 for k in required):
            return None
        incoming, cached, outgoing = (usage[k] for k in
                                     ('input_tokens', 'cached_input_tokens', 'output_tokens'))
        reasoning = usage.get('reasoning_tokens', 0)
        if type(reasoning) is not int or not 0 <= reasoning <= outgoing or cached > incoming:
            return None
        if not all(number(rate.get(k)) for k in
                   ('input_per_million', 'cached_per_million', 'output_per_million')):
            return None
        parts = [(incoming - cached, rate['input_per_million']),
                 (cached, rate['cached_per_million']), (outgoing, rate['output_per_million'])]
    else:
        return None
    try:
        value = sum(tokens * rate / 1e6 for tokens, rate in parts)
        return value if number(value) else None
    except OverflowError:
        return None


def account(events, rates, expected_billing_identity=None):
    if (not isinstance(rates, dict) or not isinstance(rates.get('rates', []), list)
            or any(not isinstance(r, dict) for r in rates.get('rates', []))):
        raise ValueError('invalid rate card')
    starts, finishes, matched, issues = {}, {}, set(), []
    for event in events:
        if not isinstance(event, dict):
            raise ValueError('attempt events must be objects')
        kind, key = event.get('event'), event.get('attempt_id')
        if (kind not in ('started', 'finished') or not isinstance(key, str) or not key
                or not isinstance(event.get('case_id'), str) or not event['case_id']
                or type(event.get('rep')) is not int or event['rep'] < 0):
            issues.append('invalid_attempt_event')
            continue
        bucket = starts if kind == 'started' else finishes
        if key in bucket:
            issues.append('duplicate_start' if kind == 'started' else 'duplicate_finish')
            continue  # first event owns the attempt; duplicates never add spend
        if kind == 'finished':
            prior = starts.get(key)
            if prior is None or any(prior[k] != event[k] for k in ('case_id', 'rep')):
                issues.append('unmatched_finished')
            else:
                matched.add(key)
            if not isinstance(event.get('status'), str) or not event['status']:
                issues.append('invalid_attempt_event')
            if (expected_billing_identity is not None and 'billing_identity' in event
                    and event['billing_identity'] != expected_billing_identity):
                issues.append('serving_identity_mismatch')
        bucket[key] = event
    interrupted = len(set(starts) - matched)
    known, unknown = 0.0, interrupted
    for event in finishes.values():
        value = price(event, rates)
        if value is None:
            unknown += 1
            continue
        if not number(known + value):
            issues.append('cost_overflow')
            unknown += 1
            continue
        known += value
        if 'cost_usd' not in event and event.get('all_billable_usage_included') is not True:
            unknown += 1
    attempts = {'started': len(starts), 'finished': len(finishes),
                'interrupted': interrupted,
                'failed': sum(e.get('status') != 'ok' for e in finishes.values())}
    costs = {'known_usd': known, 'total_usd': None if unknown else known,
             'unknown_attempts': unknown}
    return attempts, costs, issues
