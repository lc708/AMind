"""Verify the deliverable with site packages and PYTHONPATH disabled."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

workspace = Path(__file__).resolve().parents[1]
repo = workspace / 'repo'
standalone = workspace / 'output/standalone'
standalone.mkdir(exist_ok=True)
for name in ('releaseboard', 'examples'):
    shutil.copytree(repo / name, standalone / name, dirs_exist_ok=True,
                    ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', TMPDIR=str(workspace / 'output/tmp'))
env.pop('PYTHONPATH', None)
process = subprocess.run([sys.executable, '-S', '-m', 'releaseboard', '--bundle',
                          'examples/saved-run', '--rates', 'examples/rates.json',
                          '--variant', 'candidate'], cwd=standalone,
                         env=env, text=True, capture_output=True, timeout=5)
assert process.returncode == 0 and not process.stderr, (process.stdout, process.stderr)
report = json.loads(process.stdout)
assert report['decision'] == 'hold' and report['planned_observations'] == 3
assert report['missing'] == [{'case_id': 'account-recovery', 'rep': 0}]
(standalone / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
print('Standalone source copy passed with python -S and no PYTHONPATH.')
