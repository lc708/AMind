"""Join the full planned population to trustworthy scores and call evidence."""
import math
from collections import Counter
from .accounting import account, exact_scope


def finite(value):
    try:
        return type(value) in (int, float) and math.isfinite(value)
    except OverflowError:
        return False


def validate_manifest(manifest):
    if not isinstance(manifest, dict):
        raise ValueError('manifest must be an object')
    for key in ('release_id', 'variant', 'split', 'comparison_hash', 'treatment_hash'):
        if not isinstance(manifest.get(key), str) or not manifest[key]:
            raise ValueError('invalid manifest ' + key)
    ids, reps = manifest.get('case_ids'), manifest.get('repetitions')
    if (not isinstance(ids, list) or any(not isinstance(cid, str) or not cid for cid in ids)
            or len(set(ids)) != len(ids) or type(reps) is not int or reps < 1):
        raise ValueError('invalid planned population')
    metrics = manifest.get('metrics')
    if not isinstance(metrics, list) or not metrics:
        raise ValueError('metrics must be a nonempty list')
    seen = set()
    for metric in metrics:
        if (not isinstance(metric, dict) or not isinstance(metric.get('id'), str)
                or not metric['id'] or metric['id'] in seen
                or not all(finite(metric.get(k)) for k in ('min', 'max', 'min_mean'))
                or metric['min'] > metric['max']):
            raise ValueError('invalid metric contract')
        seen.add(metric['id'])
    if 'expected_billing_identity' in manifest and not exact_scope(manifest['expected_billing_identity']):
        raise ValueError('invalid expected billing identity')
    stages = manifest.get('required_stages', {})
    if (not isinstance(stages, dict)
            or any(not isinstance(k, str) or not k or type(v) is not int or v < 0
                   for k, v in stages.items())):
        raise ValueError('invalid stage contract')


def stage_ok(report, contract):
    if not contract:
        return None
    if not isinstance(report, dict) or not isinstance(report.get('stages'), list):
        return False
    stages = report['stages']
    by_id = {}
    for row in stages:
        if (not isinstance(row, dict) or not isinstance(row.get('id'), str)
                or row['id'] in by_id):
            return False
        by_id[row['id']] = row
    if set(by_id) != set(contract):
        return False
    for key, total in contract.items():
        row = by_id[key]
        counts = row.get('counts')
        if (type(row.get('total')) is not int or row['total'] != total
                or not finite(row.get('coverage')) or row['coverage'] != 1
                or row.get('uncovered') != [] or not isinstance(counts, dict)
                or counts.get('succeeded') != total
                or any(type(v) is not int or v < 0 for v in counts.values())
                or any(v != 0 for k, v in counts.items() if k != 'succeeded')):
            return False
    return True


def result_key(row):
    if not isinstance(row, dict):
        raise ValueError('results must be objects')
    cid, rep = row.get('case_id'), row.get('rep')
    if not isinstance(cid, str) or not cid or type(rep) is not int or rep < 0:
        return None
    return cid, rep


def build(manifest, results, events, rates, requested_variant):
    validate_manifest(manifest)
    issues = []
    if requested_variant != manifest['variant']:
        issues.append('variant_mismatch')
    planned = [(cid, rep) for cid in manifest['case_ids']
               for rep in range(manifest['repetitions'])]
    planned_set = set(planned)
    keys = [result_key(row) for row in results]
    counts = Counter(key for key in keys if key is not None)
    accepted = {}
    for row, key in zip(results, keys):
        if key is None or key not in planned_set:
            issues.append('unexpected_result')
            continue
        if counts[key] != 1:
            issues.append('duplicate_result')
            continue
        identity = {'comparison_hash': manifest['comparison_hash'],
                    'treatment_hash': manifest['treatment_hash'], 'case_id': key[0], 'rep': key[1]}
        actual = row.get('result_identity')
        if (not isinstance(actual, dict) or actual != identity
                or type(actual.get('rep')) is not int):
            issues.append('result_identity_mismatch')
            continue
        pin = manifest.get('expected_billing_identity')
        if pin is not None and row.get('billing_identity') != pin:
            issues.append('serving_identity_mismatch')
            continue
        if row.get('status') != 'ok':
            continue
        grade = row.get('grade')
        valid = isinstance(grade, dict) and set(grade) == {m['id'] for m in manifest['metrics']}
        if valid:
            valid = all(finite(grade[m['id']]) and m['min'] <= grade[m['id']] <= m['max']
                        for m in manifest['metrics'])
        if not valid:
            issues.append('invalid_grade')
            continue
        accepted[key] = row
    missing = [{'case_id': cid, 'rep': rep} for cid, rep in planned if (cid, rep) not in accepted]
    metrics = {}
    for metric in manifest['metrics']:
        values = [row['grade'][metric['id']] for row in accepted.values()]
        metrics[metric['id']] = {
            'mean': math.fsum(v / len(values) for v in values) if values else None,
            'scored': len(values)}
    attempts, cost, ledger_issues = account(events, rates, manifest.get('expected_billing_identity'))
    issues.extend(ledger_issues)
    for event in events:
        if result_key(event) not in planned_set:
            issues.append('unexpected_attempt')
    contract = manifest.get('required_stages', {})
    if not contract:
        coverage = 'unmeasured'
    else:
        complete = not missing and all(stage_ok(row.get('coverage'), contract)
                                       for row in accepted.values())
        coverage = 'complete' if complete and accepted else 'incomplete'
    quality = all(metrics[m['id']]['mean'] is not None
                  and metrics[m['id']]['mean'] >= m['min_mean'] for m in manifest['metrics'])
    ready = (not issues and not missing and quality and cost['total_usd'] is not None
             and coverage == 'complete')
    return {'release_id': manifest['release_id'], 'variant': requested_variant, 'split': manifest['split'],
            'planned_observations': len(planned), 'scored_observations': len(accepted), 'missing': missing,
            'metrics': metrics, 'attempts': attempts, 'cost': cost, 'coverage': {'status': coverage},
            'integrity': {'status': 'invalid' if issues else 'verified', 'issues': sorted(set(issues))},
            'decision': 'ready' if ready else 'hold'}
