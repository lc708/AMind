# Releaseboard incident repair

The saved incident originally printed ready, planned=2, scored=2, missing=[],
coverage=complete. The initial public run failed two of three tests: the missing
planned case and interrupted-call accounting.

The repaired CLI prints hold, planned=3, scored=2, with account-recovery/0 missing
and coverage=incomplete. Its known spend remains $0.40.

Changes in repo/releaseboard:

- report.py validates manifest contracts, derives every planned case/repetition,
  rejects duplicate/unexpected or incompatible results, validates finite grades
  and every metric gate, and checks required stages' exact populations and
  successful counts. An absent stage contract remains unmeasured.
- accounting.py reconciles attempts once, detects duplicates and unmatched
  finishes, includes failed retries/judges, and retains interrupted or unpriceable
  calls as unknown. Estimates match all five billing identity fields and validate
  normalized integer usage without double-charging cache or reasoning. Partial
  estimates retain their priced subtotal while the total remains null. Invalid
  explicit costs never fall back to zero or an estimate.
- __main__.py preserves documented arguments and JSON keys, rejects malformed JSON
  including duplicate keys and nonfinite constants, and emits JSON errors with
  exit 2. Semantic holds exit 0.

Evidence (offline, no model/API calls):

- public-tests.txt: all 3 unmodified public tests passed.
- integration_checks.py: 82 checks invoking the public CLI. All case fixtures and
  returned packets are in integration-cases/; integration-results.json summarizes
  them. Cases cover a complete-ready control, saved incident, identity and result
  contamination, repetitions, stage failures, all metric gates, interrupted and
  failed calls, deduplication, exact pricing, partial costs and malformed inputs.
- check_standalone.py: copied only source and examples into output/standalone,
  removed PYTHONPATH and ran python -S. The CLI produced the expected incident
  hold without site packages or skills.
- saved-run-report.json: the public CLI packet for the repository example.

Reproduce from repo/:

    TMPDIR="$PWD/../output/tmp" PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -v
    python3 -m releaseboard --bundle examples/saved-run --rates examples/rates.json --variant candidate

Reproduce extra checks from workspace root:

    python3 output/integration_checks.py
    python3 output/check_standalone.py

No test sources, skills, task configuration, model configuration or saved example
inputs were changed. Product imports use only the Python standard library.
