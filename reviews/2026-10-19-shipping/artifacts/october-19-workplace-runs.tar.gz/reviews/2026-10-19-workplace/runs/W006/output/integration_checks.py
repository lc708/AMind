"""Offline end-to-end contract checks through python -m releaseboard.

Run from workspace: python3 output/integration_checks.py
All fixture and process artifacts stay under output/.
"""
import copy
import json
import os
from pathlib import Path
import subprocess
import sys

WORKSPACE = Path(__file__).resolve().parents[1]
REPO = WORKSPACE / 'repo'
OUT = WORKSPACE / 'output'
CASES = OUT / 'integration-cases'
CASES.mkdir(exist_ok=True)
BASE_MANIFEST = json.loads((REPO / 'examples/saved-run/manifest.json').read_text())
BASE_RESULTS = [json.loads(s) for s in (REPO / 'examples/saved-run/results.jsonl').read_text().splitlines()]
BASE_EVENTS = [json.loads(s) for s in (REPO / 'examples/saved-run/attempts.jsonl').read_text().splitlines()]
BASE_RATES = json.loads((REPO / 'examples/rates.json').read_text())
SCOPE = BASE_MANIFEST['expected_billing_identity']
RUNS = []


def complete():
    manifest = copy.deepcopy(BASE_MANIFEST)
    results = copy.deepcopy(BASE_RESULTS)
    last = copy.deepcopy(results[0])
    last['case_id'] = 'account-recovery'
    last['result_identity']['case_id'] = last['case_id']
    last['grade']['quality'] = .9
    results.append(last)
    events = copy.deepcopy(BASE_EVENTS)
    events += [dict(event='started', attempt_id='third', case_id='account-recovery', rep=0),
               dict(event='finished', attempt_id='third', case_id='account-recovery', rep=0,
                    status='ok', cost_usd=0)]
    return [manifest, results, events, copy.deepcopy(BASE_RATES)]


def run(name, data=None, variant='candidate', raw=None, code=0):
    manifest, results, events, rates = data or complete()
    folder = CASES / name
    folder.mkdir(exist_ok=True)
    files = {'manifest.json': json.dumps(manifest),
             'results.jsonl': ''.join(json.dumps(row) + '\n' for row in results),
             'attempts.jsonl': ''.join(json.dumps(row) + '\n' for row in events),
             'rates.json': json.dumps(rates)}
    files.update(raw or {})
    for path, content in files.items():
        (folder / path).write_text(content)
    env = dict(os.environ, TMPDIR=str(OUT / 'tmp'), PYTHONDONTWRITEBYTECODE='1')
    process = subprocess.run([sys.executable, '-m', 'releaseboard', '--bundle', str(folder),
                              '--rates', str(folder / 'rates.json'), '--variant', variant],
                             cwd=REPO, env=env, text=True, capture_output=True, timeout=5)
    assert process.returncode == code, (name, process.returncode, process.stdout, process.stderr)
    assert not process.stderr, (name, process.stderr)
    report = json.loads(process.stdout)
    (folder / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    RUNS.append({'case': name, 'exit': process.returncode, 'decision': report.get('decision'),
                 'integrity': report.get('integrity'), 'cost': report.get('cost')})
    if code == 2:
        assert set(report) == {'error'}
    else:
        assert set(report) == {'release_id', 'variant', 'split', 'planned_observations',
                               'scored_observations', 'missing', 'metrics', 'attempts',
                               'cost', 'coverage', 'integrity', 'decision'}
    return report


def held(name, data=None, invalid=False, **kwargs):
    report = run(name, data, **kwargs)
    assert report['decision'] == 'hold', (name, report)
    if invalid:
        assert report['integrity']['status'] == 'invalid', (name, report)
    return report


r = run('complete-ready')
assert r['decision'] == 'ready' and r['coverage']['status'] == 'complete'
assert r['planned_observations'] == r['scored_observations'] == 3
assert r['cost']['total_usd'] == .4
r = held('saved-incident', (BASE_MANIFEST, BASE_RESULTS, BASE_EVENTS, BASE_RATES))
assert r['missing'] == [{'case_id': 'account-recovery', 'rep': 0}]
assert r['planned_observations'] == 3 and r['cost']['known_usd'] == .4
held('variant-mismatch', variant='other', invalid=True)
for field in ('comparison_hash', 'treatment_hash', 'case_id', 'rep'):
    data = complete()
    data[1][0]['result_identity'][field] = 99 if field == 'rep' else 'other'
    r = held('identity-' + field, data, invalid=True)
    assert r['scored_observations'] == 2
for field in SCOPE:
    data = complete()
    data[1][0]['billing_identity'][field] = 'other'
    held('served-' + field, data, invalid=True)
for position in (0, -1):
    data = complete()
    data[1].insert(position, copy.deepcopy(data[1][0]))
    r = held('duplicate-result-' + str(position), data, invalid=True)
    assert r['scored_observations'] == 2
for value in (True, '0', -1, 2):
    data = complete()
    data[1][0]['rep'] = value
    held('unexpected-rep-' + str(value), data, invalid=True)
data = complete()
data[1][0]['case_id'] = 'not-planned'
held('unexpected-case', data, invalid=True)
for value in (True, '1', None, -1, 2):
    data = complete()
    data[1][0]['grade']['quality'] = value
    r = held('bad-grade-' + str(value), data, invalid=True)
    assert r['metrics']['quality']['scored'] == 2
data = complete()
data[1][0]['grade'] = {}
held('missing-grade', data, invalid=True)
data = complete()
data[1][0]['status'] = 'failed'
r = held('failed-result', data)
assert len(r['missing']) == 1
data = complete()
data[0]['repetitions'] = 2
r = held('planned-repetitions', data)
assert r['planned_observations'] == 6 and len(r['missing']) == 3
data = complete()
data[1].clear()
r = held('no-results', data)
assert r['metrics']['quality'] == {'mean': None, 'scored': 0}
data = complete()
for row in data[1]:
    row['grade']['quality'] = .7
held('quality-gate', data)
data = complete()
data[0]['metrics'].append({'id': 'safety', 'min': 0, 'max': 1, 'min_mean': .9})
for row in data[1]:
    row['grade']['safety'] = .8
held('second-metric-gate', data)
for required in (None, {}):
    data = complete()
    if required is None:
        del data[0]['required_stages']
    else:
        data[0]['required_stages'] = required
    r = held('unmeasured-' + str(required), data)
    assert r['coverage']['status'] == 'unmeasured'
for mutation in ('missing', 'duplicate', 'extra', 'failed', 'partial', 'uncovered', 'wrong-total', 'bool-total', 'malformed'):
    data = complete()
    stages = data[1][0]['coverage']['stages']
    if mutation == 'missing': stages.pop()
    elif mutation == 'duplicate': stages.append(copy.deepcopy(stages[0]))
    elif mutation == 'extra':
        extra = copy.deepcopy(stages[0]); extra['id'] = 'unexpected'; stages.append(extra)
    elif mutation == 'failed': stages[0]['counts'] = {'succeeded': 2, 'failed': 1}
    elif mutation == 'partial': stages[0]['coverage'] = .5
    elif mutation == 'uncovered': stages[0]['uncovered'] = ['lost-worker']
    elif mutation == 'wrong-total': stages[0]['total'] = 2
    elif mutation == 'bool-total': stages[1]['total'] = True
    elif mutation == 'malformed': data[1][0]['coverage']['stages'] = {'id': 'workers'}
    r = held('stages-' + mutation, data)
    assert r['coverage']['status'] == 'incomplete'
# Failed application/judge/retry calls still contribute spend.
data = complete()
data[2] += [dict(event='started', attempt_id='failed-retry', case_id='order-return', rep=0),
            dict(event='finished', attempt_id='failed-retry', case_id='order-return', rep=0,
                 status='timeout', cost_usd=.3)]
r = run('failed-retry-cost', data)
assert abs(r['cost']['total_usd'] - .7) < 1e-12 and r['attempts']['failed'] == 1
for value in (None, True, -1, '0.2'):
    data = complete()
    data[2][-1]['cost_usd'] = value
    r = held('unknown-cost-' + str(value), data)
    assert r['cost']['total_usd'] is None and r['cost']['unknown_attempts'] == 1
    assert r['cost']['known_usd'] == .4
data = complete()
data[2].append(dict(event='started', attempt_id='judge-pending', case_id='order-return', rep=0))
r = held('interrupted-judge', data)
assert r['attempts']['interrupted'] == r['cost']['unknown_attempts'] == 1
for kind, index in (('start', 0), ('finish', 1)):
    data = complete()
    data[2].append(copy.deepcopy(data[2][index]))
    r = held('duplicate-' + kind, data, invalid=True)
    assert r['attempts']['started'] == r['attempts']['finished'] == 3
    assert r['cost']['total_usd'] == .4
data = complete()
data[2].pop(0)
r = held('unmatched-finish', data, invalid=True)
assert r['cost']['total_usd'] == .4

def estimated(mode='text'):
    data = complete()
    event = data[2][-1]
    del event['cost_usd']
    event['billing_identity'] = copy.deepcopy(SCOPE)
    event['all_billable_usage_included'] = True
    if mode == 'text':
        event['usage'] = {'input_tokens': 100, 'cached_input_tokens': 20,
                          'output_tokens': 30, 'reasoning_tokens': 10}
    else:
        event['billing_identity']['interface'] = 'decisions'
        event['usage'] = {'input_tokens': 100}
        del data[0]['expected_billing_identity']
    return data

r = run('text-pricing', estimated())
assert r['decision'] == 'ready' and abs(r['cost']['total_usd'] - .40142) < 1e-12
r = run('input-only-pricing', estimated('input_only'))
assert r['decision'] == 'ready' and abs(r['cost']['total_usd'] - .4002) < 1e-12
for field in SCOPE:
    data = estimated()
    del data[0]['expected_billing_identity']
    data[2][-1]['billing_identity'][field] = 'unmatched'
    r = held('unpriced-scope-' + field, data)
    assert r['cost']['unknown_attempts'] == 1 and r['cost']['known_usd'] == .4
for usage in ({'input_tokens': 10}, {'input_tokens': True, 'cached_input_tokens': 0, 'output_tokens': 0},
              {'input_tokens': 10, 'cached_input_tokens': 11, 'output_tokens': 1},
              {'input_tokens': 10, 'cached_input_tokens': 0, 'output_tokens': 1, 'reasoning_tokens': 2},
              {'input_tokens': 10, 'cached_input_tokens': 0, 'output_tokens': 1, 'audio_tokens': 20}):
    data = estimated()
    data[2][-1]['usage'] = usage
    held('bad-usage-' + str(len(RUNS)), data)
for usage in ({'input_tokens': 1.5}, {'input_tokens': True}, {'input_tokens': 1, 'output_tokens': 0}):
    data = estimated('input_only')
    data[2][-1]['usage'] = usage
    held('bad-input-only-' + str(len(RUNS)), data)
data = estimated()
data[2][-1]['all_billable_usage_included'] = False
r = held('partial-estimate', data)
assert r['cost']['unknown_attempts'] == 1 and abs(r['cost']['known_usd'] - .40142) < 1e-12
data = estimated()
data[3]['rates'].append(copy.deepcopy(data[3]['rates'][0]))
held('ambiguous-rate', data)
data = estimated()
data[3].clear()
r = held('absent-rate', data)
assert r['cost']['unknown_attempts'] == 1
data = complete()
data[3].clear()
assert run('reported-cost-without-rates', data)['decision'] == 'ready'
data = complete()
data[0]['metrics'][0]['min_mean'] = 1.1
held('unattainable-mean-gate', data)
# JSON and structural errors must have a JSON error and exit 2, never traceback.
for name, filename, contents in (
    ('bad-json', 'manifest.json', '{'), ('nonfinite-json', 'results.jsonl', '{"grade":NaN}\n'),
    ('duplicate-json-key', 'manifest.json', '{"variant":"x","variant":"y"}'),
    ('nonobject-manifest', 'manifest.json', '[]'), ('nonobject-result', 'results.jsonl', '[]\n'),
    ('nonobject-event', 'attempts.jsonl', 'null\n'), ('bad-rates', 'rates.json', '[]')):
    run(name, raw={filename: contents}, code=2)
for field, value in (('case_ids', ['x', 'x']), ('repetitions', True), ('metrics', []),
                     ('required_stages', []), ('expected_billing_identity', {'model': 'x'})):
    data = complete()
    data[0][field] = value
    run('malformed-' + field, data, code=2)
(OUT / 'integration-results.json').write_text(json.dumps({'passed': len(RUNS), 'runs': RUNS}, indent=2) + '\n')
print(f'{len(RUNS)} public-CLI integration checks passed; fixtures and reports: {CASES}')
