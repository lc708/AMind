"""Offline regression tests through the public CLI; all artifacts stay here.

Run from repo/: python3 -B -m unittest discover -s ../output -p 'test_*.py' -v
"""
import copy
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

OUTPUT = Path(__file__).resolve().parent
REPO = OUTPUT.parent / 'repo'


def message(text='Answer', owner='/root', phase='final_answer', **extra):
    item = {'type': 'message', 'content': [{'type': 'output_text', 'text': text}]}
    if owner is not None:
        item['agent'] = {'agent_name': owner}
    if phase is not None:
        item['phase'] = phase
    item.update(extra)
    return item


def terminal(items, status='completed', **extra):
    return {'type': 'response.' + status,
            'response': dict(status=status, output=items, **extra)}


def added(index, item):
    return {'type': 'response.output_item.added', 'output_index': index, 'item': item}


def delta(text, **extra):
    return dict(type='response.output_text.delta', delta=text, **extra)


class GatewayRegressions(unittest.TestCase):
    def call(self, capture, reject=False):
        with tempfile.TemporaryDirectory(dir=OUTPUT, prefix='gateway-case-') as folder:
            folder = Path(folder)
            source, target = folder / 'capture.json', folder / 'view.json'
            source.write_text(json.dumps(capture), encoding='utf-8')
            if reject:
                target.write_text('previous artifact', encoding='utf-8')
            env = dict(os.environ, TMPDIR=str(folder), PYTHONDONTWRITEBYTECODE='1')
            process = subprocess.run(
                [sys.executable, '-B', '-m', 'gateway', '--capture', str(source), '--out', str(target)],
                cwd=REPO, env=env, capture_output=True, text=True, timeout=5)
            self.assertEqual(process.stderr, '')
            report = json.loads(process.stdout)
            if reject:
                self.assertEqual(process.returncode, 2, process.stdout)
                self.assertIsInstance(report['error'], str)
                self.assertEqual(target.read_text(), 'previous artifact')
                self.assertFalse(list(folder.glob('.gateway-*')))
                target.unlink()
                process = subprocess.run(
                    [sys.executable, '-B', '-m', 'gateway', '--capture', str(source), '--out', str(target)],
                    cwd=REPO, env=env, capture_output=True, text=True, timeout=5)
                self.assertEqual(process.returncode, 2, process.stdout + process.stderr)
                self.assertFalse(target.exists())
                return report
            self.assertEqual(process.returncode, 0, process.stdout)
            self.assertFalse(list(folder.glob('.gateway-*')))
            result = json.loads(target.read_text())
            self.assertEqual(set(result), {'client', 'archive'})
            self.assertEqual(set(result['client']),
                             {'status', 'display_text', 'final_text', 'answer_complete', 'html'})
            self.assertEqual(result['archive']['events'], capture['events'])
            return result

    def test_saved_incident(self):
        capture = json.loads((REPO / 'traces/incident.json').read_text())
        result = self.call(capture)
        self.assertEqual(result['client'], {
            'status': 'completed', 'display_text': 'Checking your request.',
            'final_text': '', 'answer_complete': False,
            'html': '<article>Checking your request.</article>'})
        self.assertNotIn('Internal draft', json.dumps(result['client']))
        self.assertEqual(result['archive']['output_items'], capture['events'][-1]['response']['output'])
        self.assertEqual(result['archive']['summary']['item_types']['agent_message'], 1)

    def test_saved_legacy_and_default_mode(self):
        capture = json.loads((REPO / 'traces/legacy.json').read_text())
        for default_mode in (False, True):
            with self.subTest(default_mode=default_mode):
                if default_mode:
                    capture.pop('mode')
                client = self.call(capture)['client']
                self.assertEqual(client['final_text'], 'Order received.')
                self.assertTrue(client['answer_complete'])

    def test_indexed_and_id_owned_deltas(self):
        worker = message('secret', owner='/root/worker', id='w')
        root = message('Root answer', id='r')
        events = [added(0, worker), added(1, root), delta('secret', output_index=0),
                  delta('Root ', output_index=1, item_id='r'), delta('answer', item_id='r'),
                  terminal([worker, root])]
        client = self.call({'mode': 'multi_agent', 'events': events})['client']
        self.assertEqual(client['display_text'], 'Root answer')
        self.assertEqual(client['final_text'], 'Root answer')
        self.assertTrue(client['answer_complete'])

    def test_multi_requires_explicit_root_and_final_phase(self):
        cases = [(None, None), (None, 'final_answer'), ('/root', None),
                 ('/root', 'commentary'), ('/root/child', 'final_answer'),
                 ('/root', 'unknown_phase')]
        for owner, phase in cases:
            with self.subTest(owner=owner, phase=phase):
                client = self.call({'mode': 'multi_agent', 'events': [
                    terminal([message('private', owner=owner, phase=phase)])]})['client']
                self.assertEqual(client['final_text'], '')
                self.assertFalse(client['answer_complete'])

    def test_commentary_is_progress_only(self):
        for mode in ('single', 'multi_agent'):
            with self.subTest(mode=mode):
                item = message('Checking', phase='commentary')
                client = self.call({'mode': mode, 'events': [added(0, item),
                    delta('Checking', output_index=0), terminal([item])]})['client']
                self.assertEqual(client['display_text'], 'Checking')
                self.assertEqual(client['final_text'], '')
                self.assertFalse(client['answer_complete'])

    def test_pending_developer_call_blocks_completion(self):
        call = {'type': 'function_call', 'call_id': 'c1', 'name': 'write_file',
                'arguments': '{"path":"must-not-exist"}', 'status': 'completed'}
        items = [message(), call]
        result = self.call({'mode': 'multi_agent', 'events': [terminal(items)]})
        self.assertEqual(result['client']['final_text'], 'Answer')
        self.assertFalse(result['client']['answer_complete'])
        self.assertEqual(result['archive']['output_items'], items)
        self.assertFalse((REPO / 'must-not-exist').exists())

    def test_terminal_outcomes_and_response_metadata(self):
        for status in ('completed', 'failed', 'incomplete', 'cancelled'):
            with self.subTest(status=status):
                event = terminal([message()], status, usage={'output_tokens': 7}, id='r1')
                result = self.call({'mode': 'multi_agent', 'events': [event]})
                self.assertEqual(result['client']['status'], status)
                self.assertEqual(result['client']['answer_complete'], status == 'completed')
                self.assertEqual(result['archive']['events'][0], event)

    def test_disconnect_and_stream_error_keep_only_root_progress(self):
        worker, root = message('secret', owner='/root/w'), message('Partial')
        for error in (False, True):
            with self.subTest(error=error):
                events = [delta('unattributed'), added(0, worker), added(1, root),
                          delta('secret', output_index=0), delta('Partial', output_index=1)]
                if error:
                    events.append({'type': 'error', 'message': 'lost'})
                result = self.call({'mode': 'multi_agent', 'events': events})
                self.assertEqual(result['client']['status'], 'stream_error' if error else 'disconnected')
                self.assertEqual(result['client']['display_text'], 'Partial')
                self.assertFalse(result['client']['answer_complete'])
                self.assertEqual(result['archive']['output_items'], [worker, root])

    def test_legacy_provisional_text_stays_disconnected(self):
        client = self.call({'events': [delta('Working')]})['client']
        self.assertEqual(client['display_text'], 'Working')
        self.assertEqual(client['status'], 'disconnected')
        self.assertFalse(client['answer_complete'])

    def test_html_escaping_for_final_and_provisional_text(self):
        text = '<script>"x" & \'y\'</script>'
        expected = '<article>&lt;script&gt;&quot;x&quot; &amp; &#x27;y&#x27;&lt;/script&gt;</article>'
        for events in ([terminal([message(text, owner=None, phase=None)])], [delta(text)]):
            with self.subTest(events=events):
                client = self.call({'events': events})['client']
                self.assertEqual(client['html'], expected)
                self.assertIn(text, (client['final_text'], client['display_text']))

    def test_unknown_items_and_fields_survive_exactly(self):
        items = [{'type': 'agent_message', 'opaque': {'receipt': 'h-418', 'nested': [None, 9]}},
                 {'type': 'future_hosted_item', 'payload': {'phase': 'opaque'},
                  'id': {'opaque': 1}, 'agent': 'opaque', 'phase': {'opaque': True}},
                 {'type': 'reasoning', 'encrypted_content': 'opaque'}, message()]
        result = self.call({'mode': 'multi_agent', 'events': [terminal(items)]})
        self.assertEqual(result['archive']['output_items'], items)
        self.assertEqual(result['archive']['summary']['item_count'], 4)
        self.assertTrue(result['client']['answer_complete'])

    def test_empty_transport_is_not_an_answer(self):
        client = self.call({'events': [terminal([])]})['client']
        self.assertEqual(client['status'], 'completed')
        self.assertFalse(client['answer_complete'])

    def test_contradictory_terminal_rejected_atomically(self):
        bad = [terminal([], error={}), terminal([], incomplete_details={}),
               {'type': 'response.completed', 'response': {'status': 'incomplete'}},
               {'type': 'response.failed', 'response': {'status': 'completed'}},
               {'type': 'response.cancelled', 'response': {'status': 'failed'}},
               {'type': 'response.completed'},
               {'type': 'response.completed', 'response': []},
               {'type': 'response.completed', 'response': {'output': []}}]
        for event in bad:
            with self.subTest(event=event):
                self.call({'events': [event]}, reject=True)

    def test_events_after_terminal_or_error_rejected(self):
        for first in (terminal([]), {'type': 'error', 'message': 'lost'}):
            for last in (delta('late'), terminal([]), {'type': 'keepalive'}):
                with self.subTest(first=first, last=last):
                    self.call({'events': [first, last]}, reject=True)

    def test_conflicting_owner_phase_and_identity_rejected(self):
        original = message('x', id='m')
        changes = [message('x', owner='/root/worker', id='m'),
                   message('x', phase='commentary', id='m'), message('x', id='other')]
        for changed in changes:
            with self.subTest(changed=changed):
                self.call({'mode': 'multi_agent', 'events': [added(0, original),
                    terminal([changed])]}, reject=True)
        self.call({'events': [added(0, original),
            delta('x', output_index=0, item_id='wrong')]}, reject=True)
        self.call({'events': [added(0, original), added(1, message('x', id='second')),
            delta('x', output_index=0, item_id='second')]}, reject=True)

    def test_direct_delta_claim_cannot_change_owner_later(self):
        self.call({'mode': 'multi_agent', 'events': [
            delta('x', output_index=0, agent={'agent_name': '/root'}),
            terminal([message('x', owner='/root/w')])]}, reject=True)

    def test_unattributed_multi_deltas_are_not_promoted_retroactively(self):
        client = self.call({'mode': 'multi_agent', 'events': [delta('private', output_index=0),
            terminal([message('public')])]})['client']
        self.assertEqual(client['display_text'], '')
        self.assertEqual(client['final_text'], 'public')

    def test_single_omitted_metadata_does_not_promote_worker_or_commentary(self):
        for original in (message('secret', owner='/root/w'), message('Checking', phase='commentary')):
            with self.subTest(original=original):
                snapshot = message('text', owner=None, phase=None)
                client = self.call({'events': [added(0, original),
                    terminal([snapshot])]})['client']
                self.assertEqual(client['final_text'], '')
                self.assertFalse(client['answer_complete'])

    def test_unknown_phase_is_archive_only(self):
        item = message('opaque', phase='future')
        result = self.call({'mode': 'multi_agent', 'events': [added(0, item),
            delta('opaque', output_index=0), terminal([item])]})
        self.assertEqual(result['client']['display_text'], '')
        self.assertEqual(result['client']['final_text'], '')
        self.assertEqual(result['archive']['output_items'], [item])

    def test_malformed_payloads_are_json_errors(self):
        cases = [{'mode': [], 'events': []}, {'events': [delta(123)]},
                 {'events': [added(-1, message())]},
                 {'events': [terminal([None])]}]
        cases += [{'events': [terminal([dict(message(), content={})])]},
                  {'events': [terminal([dict(message(), agent=[])])]},
                  {'events': [terminal([dict(message(), content=[{'type': 'output_text', 'text': 2}])])]}]
        for capture in cases:
            with self.subTest(capture=capture):
                self.call(capture, reject=True)

    def test_refusal_is_visible_final_outcome(self):
        item = message()
        item['content'] = [{'type': 'refusal', 'refusal': 'Cannot help with that.'}]
        client = self.call({'mode': 'multi_agent', 'events': [terminal([item])]})['client']
        self.assertEqual(client['final_text'], 'Cannot help with that.')
        self.assertTrue(client['answer_complete'])

    def test_archive_is_detached_and_input_unchanged(self):
        sys.path.insert(0, str(REPO))
        from gateway.service import Gateway
        capture = {'events': [terminal([message()])]}
        original = copy.deepcopy(capture)
        gateway = Gateway()
        result = gateway.ingest(capture)
        self.assertEqual(capture, original)
        result['archive']['output_items'][0]['content'][0]['text'] = 'changed'
        result['archive']['events'][0]['response']['output'][0]['content'].clear()
        self.assertEqual(capture, original)
        self.assertEqual(gateway.accepted, 1)

    def test_partial_unknown_items_are_retained(self):
        item = {'type': 'future_hosted_item', 'opaque': [1, {'keep': True}]}
        result = self.call({'events': [added(0, item)]})
        self.assertEqual(result['archive']['output_items'], [item])
        self.assertEqual(result['client']['status'], 'disconnected')
        self.assertEqual(result['client']['html'], '<article></article>')


if __name__ == '__main__':
    unittest.main()
