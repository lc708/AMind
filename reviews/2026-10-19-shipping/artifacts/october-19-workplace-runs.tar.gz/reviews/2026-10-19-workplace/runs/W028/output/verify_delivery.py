"""Repeatable offline verification; writes only within this workspace's output/."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

OUTPUT = Path(__file__).resolve().parent
REPO = OUTPUT.parent / 'repo'
TEMP = OUTPUT / 'tmp'
TEMP.mkdir(exist_ok=True)
env = dict(os.environ, TMPDIR=str(TEMP), PYTHONDONTWRITEBYTECODE='1', PYTHONPATH='')
checks = []


def run(label, arguments, cwd=REPO):
    result = subprocess.run([sys.executable, '-B', *arguments], cwd=cwd, env=env,
                            capture_output=True, text=True, timeout=30)
    checks.append({'check': label, 'exit_code': result.returncode,
                   'stdout': result.stdout, 'stderr': result.stderr})
    if result.returncode:
        raise RuntimeError(label + ': ' + result.stdout + result.stderr)


run('original public tests', ['-m', 'unittest', 'discover', '-s', 'tests', '-v'])
run('focused regression tests', ['-m', 'unittest', 'discover', '-s', str(OUTPUT),
                                 '-p', 'test_*.py', '-v'])
for name in ('incident', 'legacy'):
    run('public CLI ' + name, ['-m', 'gateway', '--capture', 'traces/' + name + '.json',
                              '--out', str(OUTPUT / ('fixed-' + name + '.json'))])

with tempfile.TemporaryDirectory(dir=OUTPUT, prefix='standalone-') as directory:
    isolated = Path(directory) / 'repo'
    shutil.copytree(REPO, isolated, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    assert not (isolated.parent / 'skills').exists()
    for name in ('incident', 'legacy'):
        artifact = Path(directory) / (name + '.json')
        run('standalone CLI ' + name,
            ['-m', 'gateway', '--capture', 'traces/' + name + '.json', '--out', str(artifact)],
            cwd=isolated)
        actual = json.loads(artifact.read_text())
        expected = json.loads((OUTPUT / ('fixed-' + name + '.json')).read_text())
        assert actual == expected

report = {'result': 'passed', 'network_calls': 0, 'model_calls': 0, 'checks': checks}
(OUTPUT / 'verification.json').write_text(json.dumps(report, ensure_ascii=False, indent=2),
                                          encoding='utf-8')
print(json.dumps({'result': 'passed', 'public_tests': 3, 'regression_tests': 23,
                  'standalone_cli_replays': 2, 'report': 'output/verification.json'}))
