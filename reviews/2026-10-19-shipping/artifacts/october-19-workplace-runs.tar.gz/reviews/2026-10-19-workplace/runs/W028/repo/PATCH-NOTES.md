# Incident 418：响应网关修复

## 原因与复现

原 projector 把所有 `response.output_text.delta` 直接拼入客户视图，终态提取仅检查
`phase`，没有检查 `agent.agent_name`。因此 worker 的 `final_answer` 被误认作根
agent 的客户答案，连带把 `answer_complete` 置为 true。归档的旧类型白名单还丢失了
`agent_message` 等 hosted 条目；renderer 直接拼接文本，允许捕获内容进入 HTML。

在项目目录运行公开入口（本机使用 `python3`，CLI 参数未改）：

```sh
python3 -B -m gateway --capture traces/incident.json --out ../output/incident-view.json
```

保存的修复前结果在 `../output/baseline-incident.json`：`display_text` 包含
`Internal draft`，`final_text` 为该内部草稿，`answer_complete=true`，归档只有 2 项。
修复后的 `../output/fixed-incident.json` 只显示 `Checking your request.`，
`final_text=""`、`answer_complete=false`，归档保留完整 3 项和全部事件。
`../output/incident-diagnosis.json` 保存前后对照与本地技能参考工具的诊断。

## 修改行为

- `gateway/projection.py`：按 output index 和 item ID 关联消息、增量及终态；客户只看
  `/root` 消息，多 agent 的最终答案必须在终态显式具有 root 归属及 `final_answer`。
  worker、未知阶段、无法归属的多 agent 文本留在运维归档。根 commentary 可以显示
  进度，但不能成为最终答案。保留无 phase 的旧单 agent 调用。
- 传输完成和答案完成分别记录：`status=completed` 仍表示协议终态；界面的答案完成
  标记必须读取 `answer_complete`。只有有效 completed 终态、非空最终内容且没有待执行
  developer `function_call` 才算答案完成。函数调用条目的 `status=completed` 不代表
  应用已执行该调用。显式最终 refusal 作为可显示的回答结果保留。
- 检查 completed/failed/incomplete/cancelled 的事件与 response.status 一致；completed
  不得同时携带非 null error 或 incomplete_details。终态后继续来事件、所有者/阶段/ID
  冲突及格式错误均返回 exit 2 和 JSON error，既不覆盖旧输出，也不创建新输出。
  无终态维持 disconnected；error 终止流时为 stream_error。
- `gateway/replay.py`：移除输出类型白名单，归档事件和终态输出逐项完整深拷贝；
  断流时也保留已捕获条目快照。未知 hosted 条目的内容保持不透明，不执行任何条目。
  原有归档摘要随完整条目重新统计。
- `gateway/render.py`：用标准库 HTML escaping 生成 article；文本字段保留原文。
  `gateway/validation.py`：明确检查 capture 对象与 mode 类型。

未修改已有 `tests/`、追踪文件、技能或 task.json。实现参考本地
`skills/amind-engineering/scripts/response_contract.py` 的终态约束，并补上 README
定义的产品归属规则；运行时只依赖 Python 标准库，没有 SDK、技能路径或绝对路径依赖。

## 验证

从 repo/ 运行，所有临时文件限定在本工作目录下：

```sh
mkdir -p ../output/tmp
TMPDIR="$PWD/../output/tmp" python3 -B -m unittest discover -s tests -v
TMPDIR="$PWD/../output/tmp" python3 -B -m unittest discover -s ../output -p 'test_*.py' -v
python3 -B ../output/verify_delivery.py
```

原有 3 项公开测试通过；新增 23 项回归测试通过。新增覆盖经真实 CLI 运行，包含
事故与旧追踪、root/worker 混合输出、未知及缺失阶段、index/ID 关联、函数调用、
四类终态、断流/错误、HTML 转义、未知类型与字段无损归档，以及拒绝错误捕获时的
输出原子性。还检查归档与输入不共享可变对象。

`../output/verify_delivery.py` 保存详细日志至 `../output/verification.json`，并将 repo
复制到工作目录内的独立临时目录，在没有相邻 skills 的情况下通过 CLI 回放两份追踪，
验证可独立运行；该检查不修改项目源码或已有测试。

## 边界

这是离线协议与产品行为修复，没有调用模型、网络或 hosted 服务，不证明在线 SDK
兼容性或模型回答质量。归档含内部 worker 内容，只应继续留在运维存储；HTTP 适配方
仍按原约定仅向浏览器发送 `client`。未知或无法归属的多 agent 文本不会被猜成 root。
流在第一个终态或 error 结束，后续事件视为捕获错误；没有新增重连合并、工具执行、
重试或跨响应状态管理。原 CLI 与输出外形均保留。
