import copy
from .projection import project
def replay(capture):
    client,items=project(capture)
    return {'client':client,'archive':{'events':copy.deepcopy(capture['events']),'output_items':items}}
