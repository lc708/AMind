"""Customer projection of captured Responses traffic.

Terminal checks follow the local AMind Engineering response_contract.py reference;
ownership follows this project's README. Standard library only; no call execution.
"""
import copy

from .render import render

TERMINALS = {
    'response.completed': 'completed',
    'response.failed': 'failed',
    'response.incomplete': 'incomplete',
    'response.cancelled': 'cancelled',
}


def _owner(value):
    agent = value.get('agent')
    if agent is None:
        return None
    if not isinstance(agent, dict):
        raise ValueError('agent must be an object')
    name = agent.get('agent_name')
    if name is not None and (not isinstance(name, str) or not name):
        raise ValueError('agent_name must be a nonempty string')
    return name


def _metadata(item):
    if not isinstance(item, dict):
        raise ValueError('output item must be an object')
    if item.get('type') != 'message':
        # Hosted/future items are opaque. Their fields need not use the message
        # schema, and none of them can supply customer-visible text.
        identity = item.get('id')
        return {'type': item.get('type'), 'owner': None, 'phase': None,
                'id': identity if isinstance(identity, str) and identity else None,
                'role': None}
    phase = item.get('phase')
    if phase is not None and not isinstance(phase, str):
        raise ValueError('message phase must be a string')
    identity = item.get('id')
    if identity is not None and (not isinstance(identity, str) or not identity):
        raise ValueError('item id must be a nonempty string')
    if item.get('type') == 'message':
        content = item.get('content', [])
        if not isinstance(content, list):
            raise ValueError('message content must be an array')
        for part in content:
            if not isinstance(part, dict):
                raise ValueError('message content item must be an object')
            field = {'output_text': 'text', 'refusal': 'refusal'}.get(part.get('type'))
            if field and not isinstance(part.get(field, ''), str):
                raise ValueError(field + ' must be a string')
    return {'type': item.get('type'), 'owner': _owner(item),
            'phase': phase, 'id': identity, 'role': item.get('role')}


def _index(event):
    index = event.get('output_index')
    if index is not None and (type(index) is not int or index < 0):
        raise ValueError('output_index must be a nonnegative integer')
    return index


class _Items:
    """Check attribution across added/done snapshots, deltas and final output."""

    def __init__(self):
        self.by_index = {}
        self.by_id = {}
        self.snapshots = {}
        self.unindexed = []

    def observe(self, item, index):
        metadata = _metadata(item)
        identity = metadata['id']
        indexed = self.by_index.get(index) if index is not None else None
        identified = self.by_id.get(identity) if identity is not None else None
        if indexed is not None and identified is not None and indexed is not identified:
            raise ValueError('inconsistent item identity')
        record = indexed if indexed is not None else identified
        if record is None:
            record = dict(metadata, output_index=index)
        else:
            for key, value in dict(metadata, output_index=index).items():
                if value is not None and record.get(key) is not None and record[key] != value:
                    raise ValueError('inconsistent item attribution: ' + key)
                if value is not None:
                    record[key] = value
        if index is not None:
            self.by_index[index] = record
            self.snapshots[index] = copy.deepcopy(item)
        else:
            self.unindexed.append(copy.deepcopy(item))
        if identity is not None:
            self.by_id[identity] = record
        return record

    def delta(self, event):
        index = _index(event)
        identity = event.get('item_id')
        if identity is not None and (not isinstance(identity, str) or not identity):
            raise ValueError('item_id must be a nonempty string')
        indexed = self.by_index.get(index) if index is not None else None
        identified = self.by_id.get(identity) if identity is not None else None
        if indexed is not None and identified is not None and indexed is not identified:
            raise ValueError('inconsistent delta item identity')
        record = indexed if indexed is not None else identified
        view = record if record is not None else {'type': 'message'}
        direct = {'owner': _owner(event), 'phase': event.get('phase'),
                  'id': identity, 'output_index': index}
        if direct['phase'] is not None and not isinstance(direct['phase'], str):
            raise ValueError('message phase must be a string')
        for key, value in direct.items():
            if value is not None and view.get(key) is not None and view[key] != value:
                raise ValueError('inconsistent delta attribution: ' + key)
            if value is not None:
                view[key] = value
        if index is not None:
            self.by_index[index] = view
        if identity is not None:
            self.by_id[identity] = view
        return dict(view), view


def _visible(metadata, multi):
    return (metadata.get('type') == 'message'
            and metadata.get('role') in (None, 'assistant')
            and (metadata.get('owner') == '/root' if multi
                 else metadata.get('owner') in (None, '/root'))
            and metadata.get('phase') in (None, 'commentary', 'final_answer'))


def project(capture):
    multi = capture.get('mode', 'single') == 'multi_agent'
    registry = _Items()
    display = []
    terminal = None
    status = 'disconnected'
    ended = False
    for event in capture['events']:
        if ended:
            raise ValueError('event after terminal outcome')
        kind = event['type']
        if kind in ('response.output_item.added', 'response.output_item.done'):
            registry.observe(event.get('item'), _index(event))
        elif kind == 'response.output_text.delta':
            delta = event.get('delta', '')
            if not isinstance(delta, str):
                raise ValueError('text delta must be a string')
            observed, resolved = registry.delta(event)
            display.append((delta, observed, resolved))
        elif kind in TERMINALS:
            terminal = event.get('response')
            status = TERMINALS[kind]
            if not isinstance(terminal, dict) or terminal.get('status') != status:
                raise ValueError('terminal event/status mismatch')
            if status == 'completed' and (terminal.get('error') is not None
                                         or terminal.get('incomplete_details') is not None):
                raise ValueError('completed response contains error or incomplete details')
            output = terminal.get('output', [])
            if not isinstance(output, list):
                raise ValueError('response output must be an array')
            for index, item in enumerate(output):
                registry.observe(item, index)
            ended = True
        elif kind == 'error':
            status = 'stream_error'
            ended = True

    # Final snapshots are authoritative. Without a terminal, retain captured
    # partial snapshots; raw events always preserve every original version.
    items = (terminal.get('output', []) if terminal is not None else
             [registry.snapshots[index] for index in sorted(registry.snapshots)]
             + registry.unindexed)
    final = []
    pending_calls = any(item.get('type') == 'function_call' for item in items)
    if terminal is not None:
        for index, item in enumerate(items):
            metadata = registry.by_index[index]
            if not _visible(metadata, multi):
                continue
            if multi and (_owner(item) != '/root' or item.get('phase') != 'final_answer'):
                continue
            phase = metadata['phase']
            if phase != 'final_answer' and (multi or phase is not None):
                continue
            for part in item.get('content', []):
                if part.get('type') == 'output_text':
                    final.append(part.get('text', ''))
                elif part.get('type') == 'refusal':
                    final.append(part.get('refusal', ''))
    final_text = ''.join(final)
    # Do not infer multi-agent ownership retroactively. Later snapshots may
    # narrow a legacy item's visibility, but cannot grant an unattributed delta
    # permission to enter the customer view.
    display_text = ''.join(delta for delta, observed, resolved in display
                           if _visible(observed, multi) and _visible(resolved, multi))
    return {'status': status, 'display_text': display_text, 'final_text': final_text,
            'answer_complete': status == 'completed' and bool(final_text) and not pending_calls,
            'html': render(final_text or display_text)}, copy.deepcopy(items)
