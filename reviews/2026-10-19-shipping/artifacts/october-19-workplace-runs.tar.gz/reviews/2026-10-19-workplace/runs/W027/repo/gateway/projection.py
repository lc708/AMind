"""Project recorded traffic without treating worker output as customer replies.

Contract design checked against amind-engineering response_contract.py (0.3.1).
This application implementation also handles cancellation and partial archives.
"""
from .render import render

TERMINALS = {
    'response.completed': 'completed',
    'response.failed': 'failed',
    'response.incomplete': 'incomplete',
    'response.cancelled': 'cancelled',
}


def _owner(value):
    agent = value.get('agent')
    if agent is None:
        return None
    if not isinstance(agent, dict):
        raise ValueError('agent attribution must be an object')
    name = agent.get('agent_name')
    if name is not None and (not isinstance(name, str) or not name):
        raise ValueError('invalid agent name')
    return name


def _message_text(item):
    content = item.get('content', [])
    if not isinstance(content, list):
        raise ValueError('message content must be an array')
    text = []
    for part in content:
        if not isinstance(part, dict):
            raise ValueError('message content item must be an object')
        if part.get('type') == 'output_text':
            value = part.get('text', '')
            if not isinstance(value, str):
                raise ValueError('output text must be a string')
            text.append(value)
    return ''.join(text)


def project(capture):
    multi = capture.get('mode', 'single') == 'multi_agent'
    owners = {}
    identities = {}
    index_ids = {}
    identity_owners = {}
    deltas = []
    observed = {}
    terminal = None
    ended = False
    status = 'disconnected'

    def bind(index, owner, identity=None):
        if owner is not None and not multi:
            raise ValueError('attributed output requires multi_agent mode')
        if identity is not None:
            if not isinstance(identity, str) or not identity:
                raise ValueError('invalid output item identity')
            prior_index = identities.get(identity)
            if index is None:
                index = prior_index
            elif prior_index is not None and prior_index != index:
                raise ValueError('output item changed index')
            if index is not None:
                if index in index_ids and index_ids[index] != identity:
                    raise ValueError('output index changed item identity')
                identities[identity] = index
                index_ids[index] = identity
        elif index is not None:
            identity = index_ids.get(index)
        known = {value for value in (
            owner, owners.get(index), identity_owners.get(identity)
        ) if value is not None}
        if len(known) > 1:
            raise ValueError('output item changed agent attribution')
        if known:
            resolved = known.pop()
            if index is not None:
                owners[index] = resolved
            if identity is not None:
                identity_owners[identity] = resolved

    for event in capture['events']:
        if ended:
            raise ValueError('event after terminal outcome')
        kind = event['type']
        index = event.get('output_index')
        if index is not None and (type(index) is not int or index < 0):
            raise ValueError('output_index must be a nonnegative integer')
        item = event.get('item')
        if item is not None and not isinstance(item, dict):
            raise ValueError('output item must be an object')
        event_owner = _owner(event)
        item_owner = _owner(item) if item is not None else None
        if event_owner is not None and item_owner is not None and event_owner != item_owner:
            raise ValueError('event and item changed agent attribution')
        owner = event_owner or item_owner
        identity = event.get('item_id')
        item_identity = (item or {}).get('id')
        if identity is not None and item_identity is not None and identity != item_identity:
            raise ValueError('event and item changed output identity')
        if identity is None:
            identity = item_identity
        if index is None and identity is not None:
            index = identities.get(identity)
        bind(index, owner, identity)
        if kind in ('response.output_item.added', 'response.output_item.done'):
            if item is None:
                raise ValueError('output item required')
            if item.get('type') == 'message':
                _message_text(item)
            # An unfinished capture still retains every observed opaque item.
            key = ('index', index) if index is not None else ('id', identity) if identity else ('event', len(observed))
            observed[key] = item
        elif kind == 'response.output_text.delta':
            delta = event.get('delta', '')
            if not isinstance(delta, str):
                raise ValueError('text delta must be a string')
            deltas.append((index, owner, identity, delta))
        elif kind in TERMINALS:
            terminal = event.get('response')
            status = TERMINALS[kind]
            if not isinstance(terminal, dict) or terminal.get('status') != status:
                raise ValueError('terminal event/status mismatch')
            if status == 'completed' and (terminal.get('error') is not None or terminal.get('incomplete_details') is not None):
                raise ValueError('completed response contains error or incomplete details')
            ended = True
        elif kind == 'error':
            status = 'stream_error'
            ended = True

    items = terminal.get('output', []) if terminal is not None else list(observed.values())
    if not isinstance(items, list):
        raise ValueError('response output must be an array')
    final = []
    visible = []
    pending = False
    for index, item in enumerate(items):
        if not isinstance(item, dict):
            raise ValueError('output item must be an object')
        owner = _owner(item)
        if terminal is not None:
            bind(index, owner, item.get('id'))
        elif owner is not None and not multi:
            raise ValueError('attributed output requires multi_agent mode')
        if item.get('type') == 'function_call':
            pending = True
        if item.get('type') != 'message':
            continue
        text = _message_text(item)
        # Terminal messages must themselves explicitly identify the root owner.
        if multi and owner != '/root':
            continue
        visible.append(text)
        phase = item.get('phase')
        if terminal is not None and (phase == 'final_answer' or (not multi and phase is None)):
            final.append(text)

    display = []
    for index, owner, identity, delta in deltas:
        if index is None and identity is not None:
            index = identities.get(identity)
        attributed_owner = owner or owners.get(index) or identity_owners.get(identity)
        if not multi or attributed_owner == '/root':
            display.append(delta)
    final_text = ''.join(final)
    display_text = ''.join(display)
    # Keep the legacy delta-only display field; terminal progress can still render.
    progress_text = ''.join(visible) if terminal is not None else ''
    return {
        'status': status,
        'display_text': display_text,
        'final_text': final_text,
        'answer_complete': status == 'completed' and bool(final_text) and not pending,
        'html': render(final_text or display_text or progress_text),
    }, items
