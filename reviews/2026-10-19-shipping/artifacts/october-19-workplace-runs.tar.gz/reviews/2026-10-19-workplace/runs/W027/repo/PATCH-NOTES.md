# Incident 418 response gateway repair

The browser now receives root-owned text only in multi-agent mode. A final answer
requires the terminal message itself to identify `/root` and `final_answer`.
Transport completion remains visible as `status: completed`, but the answer badge
must use `answer_complete`; commentary and pending developer functions do not
complete an answer. The public CLI and phase-less single-agent callers remain
compatible. Implementation uses only Python's standard library.

## Cause and reproduction

`gateway/projection.py` concatenated every text delta and accepted child finals as
customer answers. It also equated completed transport plus any final text with a
finished answer. `gateway/replay.py` discarded item types outside a legacy allow
list, including the incident's opaque `agent_message`. `gateway/render.py` inserted
captured text directly into HTML.

From `repo/`, the saved public incident reproduces all three integration faults:

```sh
python3 -m gateway --capture traces/incident.json --out ../output/after-incident.json
python3 -m gateway --capture traces/legacy.json --out ../output/after-legacy.json
```

The pre-change artifact `../output/before-incident.json` shows
`display_text: "Internal draftChecking your request."`,
`final_text: "Internal draft"`, `answer_complete: true`, and only two archived
output items. The fixed artifact shows `display_text: "Checking your request."`,
empty `final_text`, `answer_complete: false`, and all three original output items.
`../output/before-legacy.json` and `../output/after-legacy.json` demonstrate the
healthy `Order received.` answer is retained.

## Changes

- Associate stream text with explicit event ownership, output indices, and item
  identities; resolve later terminal ownership and reject conflicting metadata.
  Unattributed multi-agent text remains available only in the raw archive.
- Require matching terminal event/status, reject completed responses carrying an
  error or incomplete details, and reject events after an ended stream. Recognize
  failed, incomplete, cancelled, disconnected, and stream-error outcomes.
- Keep commentary separate from finals and block answer completion while any
  developer `function_call` is pending. No item executes tools or code.
- Preserve every terminal output item, including unknown hosted types, with deep
  copies. For interrupted captures, retain observed added/done items as well as
  the exact event list. Metrics count the retained items.
- Escape visible HTML using `html.escape`. Invalid captures fail before atomic
  publication, returning exit 2 and JSON error while leaving existing output intact.

The response contract design was checked against the assigned local
`amind-engineering` 0.3.1 `scripts/response_contract.py` and response recipes.
`../output/contract-diagnostic.json` records that reference's incident projection.
The application implementation is local and has no skill imports, absolute paths,
SDK, credentials, model changes, or network dependencies.

## Verification

Run from `repo/`; `TMPDIR` confines the original public tests' fixtures locally:

```sh
mkdir -p ../output/tmp
TMPDIR="$PWD/../output/tmp" PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -v
TMPDIR="$PWD/../output/tmp" PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s ../output -p 'test_gateway_regressions.py' -v
```

Result: **3 existing tests and 13 focused regression tests passed**. Logs are
`../output/public-tests.log` and `../output/regression-tests.log`. Existing tests
were not modified. The regression suite invokes the actual `python -m gateway`
CLI for incident/legacy captures, owner isolation, ID-only deltas, terminal owner
resolution, HTML escaping, all four terminal statuses, disconnect/error,
commentary, pending child function calls, hosted/unknown item preservation, and
invalid captures preserving an existing publication. A direct Gateway check also
verifies archive mutation isolation and accepted-count behavior on rejection.

## Limits

These are recorded offline protocol and application checks, not live provider or
model-quality evaluation. This gateway does not execute developer or hosted calls,
resume provider sessions, cancel remote workers, or establish that a textual answer
solves the customer's task. Original capture data deliberately remains in the
operations archive; browser integrations must continue sending only `client`.
