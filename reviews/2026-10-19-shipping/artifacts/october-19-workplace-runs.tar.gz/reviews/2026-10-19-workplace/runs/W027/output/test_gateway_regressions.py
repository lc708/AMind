"""Offline CLI regression suite. Run from repo with the command in PATCH-NOTES.md."""
import copy
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

REPO = Path(__file__).resolve().parents[1] / 'repo'
LOCAL_TMP = Path(__file__).resolve().parent / 'tmp'
LOCAL_TMP.mkdir(exist_ok=True)


def message(text, owner='/root', phase='final_answer'):
    result = {'type': 'message', 'content': [{'type': 'output_text', 'text': text}]}
    if owner is not None:
        result['agent'] = {'agent_name': owner}
    if phase is not None:
        result['phase'] = phase
    return result


def terminal(items, status='completed'):
    return {'type': 'response.' + status, 'response': {'status': status, 'output': items}}


def capture(events, mode='multi_agent'):
    return {'mode': mode, 'events': events}


class GatewayRegressionTests(unittest.TestCase):
    def invoke(self, data, invalid=False):
        with tempfile.TemporaryDirectory(dir=LOCAL_TMP) as directory:
            source = Path(directory) / 'capture.json'
            output = Path(directory) / 'view.json'
            source.write_text(json.dumps(data))
            if invalid:
                output.write_text('previous artifact')
            process = subprocess.run(
                [sys.executable, '-m', 'gateway', '--capture', str(source), '--out', str(output)],
                cwd=REPO, capture_output=True, text=True,
                env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
            self.assertEqual(process.returncode, 2 if invalid else 0, process.stdout + process.stderr)
            self.assertEqual(process.stderr, '')
            if invalid:
                self.assertIn('error', json.loads(process.stdout))
                self.assertEqual(output.read_text(), 'previous artifact')
                self.assertEqual(sorted(p.name for p in Path(directory).iterdir()), ['capture.json', 'view.json'])
                return
            return json.loads(output.read_text())

    def test_incident_and_exact_archive(self):
        data = json.loads((REPO / 'traces/incident.json').read_text())
        result = self.invoke(data)
        client = result['client']
        self.assertEqual(client['display_text'], 'Checking your request.')
        self.assertEqual(client['final_text'], '')
        self.assertFalse(client['answer_complete'])
        self.assertNotIn('Internal draft', json.dumps(client))
        self.assertEqual(result['archive']['events'], data['events'])
        self.assertEqual(result['archive']['output_items'], data['events'][-1]['response']['output'])
        self.assertEqual(result['archive']['summary']['item_count'], 3)

    def test_legacy_and_default_mode(self):
        for mode in ('single', None):
            data = capture([terminal([message('Order received.', None, None)])], 'single')
            if mode is None:
                data.pop('mode')
            result = self.invoke(data)['client']
            self.assertEqual(result['final_text'], 'Order received.')
            self.assertTrue(result['answer_complete'])

    def test_root_only_final_and_safe_html(self):
        text = '<script>alert("x")</script> & done'
        items = [message('worker secret', '/root/search'), message('unattributed secret', None),
                 message('Checking', phase='commentary'), message('phase missing', phase=None),
                 message(text), {'type': 'future_hosted_type', 'opaque': {'x': [1, 2]}}]
        result = self.invoke(capture([terminal(items)]))
        self.assertEqual(result['client']['final_text'], text)
        self.assertTrue(result['client']['answer_complete'])
        self.assertEqual(result['client']['html'], '<article>&lt;script&gt;alert(&quot;x&quot;)&lt;/script&gt; &amp; done</article>')
        self.assertNotIn('secret', json.dumps(result['client']))
        self.assertEqual(result['archive']['output_items'], items)

    def test_delta_attribution_and_disconnect(self):
        events = [
            {'type': 'response.output_item.added', 'output_index': 0, 'item': message('secret', '/root/worker')},
            {'type': 'response.output_text.delta', 'output_index': 0, 'delta': 'secret'},
            {'type': 'response.output_text.delta', 'delta': 'unattributed secret'},
            {'type': 'response.output_text.delta', 'agent': {'agent_name': '/root'}, 'delta': '<working>'},
        ]
        result = self.invoke(capture(events))
        self.assertEqual(result['client']['display_text'], '<working>')
        self.assertEqual(result['client']['html'], '<article>&lt;working&gt;</article>')
        self.assertEqual(result['client']['status'], 'disconnected')
        self.assertFalse(result['client']['answer_complete'])
        self.assertEqual(result['archive']['events'], events)
        self.assertEqual(result['archive']['output_items'], [events[0]['item']])

    def test_terminal_can_resolve_index_owner(self):
        result = self.invoke(capture([
            {'type': 'response.output_text.delta', 'output_index': 0, 'delta': 'secret'},
            {'type': 'response.output_text.delta', 'output_index': 1, 'delta': 'public'},
            terminal([message('secret', '/root/worker'), message('public')])]))
        self.assertEqual(result['client']['display_text'], 'public')
        self.assertEqual(result['client']['final_text'], 'public')

    def test_terminal_without_owner_does_not_guess_root_final(self):
        result = self.invoke(capture([
            {'type': 'response.output_item.added', 'output_index': 0, 'item': message('progress')},
            terminal([message('unattributed', None)])]))
        self.assertEqual(result['client']['final_text'], '')
        self.assertFalse(result['client']['answer_complete'])

    def test_all_terminal_statuses(self):
        for status in ('completed', 'failed', 'incomplete', 'cancelled'):
            with self.subTest(status=status):
                client = self.invoke(capture([terminal([message('answer')], status)]))['client']
                self.assertEqual(client['status'], status)
                self.assertEqual(client['answer_complete'], status == 'completed')

    def test_pending_developer_calls_and_hosted_items(self):
        hosted = [ {'type': kind, 'payload': {'command': 'do not execute'}}
                   for kind in ('multi_agent_call', 'multi_agent_call_output', 'agent_message') ]
        for pending in (False, True):
            items = [message('answer')] + hosted
            if pending:
                items.append({'type': 'function_call', 'agent': {'agent_name': '/root/worker'},
                              'name': 'not_registered', 'call_id': 'c', 'arguments': '{broken'})
            result = self.invoke(capture([terminal(items)]))
            self.assertEqual(result['client']['answer_complete'], not pending)
            self.assertEqual(result['archive']['output_items'], items)

    def test_commentary_never_final(self):
        for mode, owner in (('single', None), ('multi_agent', '/root')):
            client = self.invoke(capture([terminal([message('Checking', owner, 'commentary')])], mode))['client']
            self.assertEqual(client['final_text'], '')
            self.assertFalse(client['answer_complete'])
            self.assertEqual(client['html'], '<article>Checking</article>')

    def test_error_and_empty_disconnect(self):
        for events, expected in (([], 'disconnected'), ([{'type': 'error', 'message': 'offline'}], 'stream_error')):
            client = self.invoke(capture(events))['client']
            self.assertEqual(client['status'], expected)
            self.assertFalse(client['answer_complete'])

    def test_invalid_captures_preserve_previous_publication(self):
        root = message('public')
        worker = message('secret', '/root/worker')
        invalid = [
            capture([{'type': 'response.completed', 'response': {'status': 'incomplete', 'output': []}}]),
            capture([{'type': 'response.completed'}]),
            capture([{'type': 'response.completed', 'response': {'status': 'completed', 'error': {}, 'output': []}}]),
            capture([{'type': 'response.completed', 'response': {'status': 'completed', 'incomplete_details': {}, 'output': []}}]),
            capture([terminal([]), terminal([])]),
            capture([terminal([]), {'type': 'response.output_text.delta', 'delta': 'late'}]),
            capture([{'type': 'response.output_item.added', 'output_index': 0, 'item': root}, terminal([worker])]),
            capture([{'type': 'response.output_item.added', 'output_index': 0, 'agent': {'agent_name': '/root'}, 'item': worker}]),
            capture([{'type': 'response.output_text.delta', 'output_index': 0, 'agent': {'agent_name': '/root'}, 'delta': 'x'},
                     {'type': 'response.output_text.delta', 'output_index': 0, 'agent': {'agent_name': '/root/worker'}, 'delta': 'x'}]),
            capture([terminal([root])], 'single'),
            capture([terminal([{'type': 'message', 'content': 'bad'}])]),
            capture([{'type': 'response.output_text.delta', 'delta': 42}]),
            capture([{'type': 'response.output_text.delta', 'agent': 'bad', 'delta': 'x'}]),
            capture([terminal([])], 'unsupported'),
        ]
        for index, data in enumerate(invalid):
            with self.subTest(case=index):
                self.invoke(data, invalid=True)

    def test_id_only_attribution_and_conflict(self):
        item = message('answer')
        item['id'] = 'm1'
        result = self.invoke(capture([
            {'type': 'response.output_text.delta', 'item_id': 'm1', 'delta': 'answer'},
            terminal([item])]))
        self.assertEqual(result['client']['display_text'], 'answer')
        self.invoke(capture([
            {'type': 'response.output_text.delta', 'item_id': 'm1',
             'agent': {'agent_name': '/root/worker'}, 'delta': 'secret'},
            terminal([item])]), invalid=True)

    def test_archive_is_detached_from_input(self):
        sys.path.insert(0, str(REPO))
        from gateway.service import Gateway
        data = capture([terminal([message('answer'), {'type': 'opaque', 'nested': [1]}])])
        original = copy.deepcopy(data)
        gateway = Gateway()
        result = gateway.ingest(data)
        self.assertEqual(gateway.accepted, 1)
        result['archive']['output_items'][1]['nested'].append(2)
        result['archive']['events'][0]['response']['output'][0]['content'].clear()
        self.assertEqual(data, original)
        with self.assertRaises(ValueError):
            gateway.ingest(capture([terminal([]), terminal([])]))
        self.assertEqual(gateway.accepted, 1)


if __name__ == '__main__':
    unittest.main()
