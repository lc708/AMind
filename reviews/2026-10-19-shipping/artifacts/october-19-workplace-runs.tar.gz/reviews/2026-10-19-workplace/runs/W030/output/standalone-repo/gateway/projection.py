"""Offline customer projection; captured items are never executed.

Contract adapted from AMind Engineering scripts/response_contract.py v0.3.1
(Apache-2.0). See PATCH-NOTES.md for provenance and application differences.
"""
from .render import render

TERMINALS = {'response.' + status: status for status in
             ('completed', 'failed', 'incomplete', 'cancelled')}
HOSTED_ITEMS = {'multi_agent_call', 'multi_agent_call_output', 'agent_message'}


def agent_name(value):
    agent = value.get('agent')
    if agent is None:
        return None
    if not isinstance(agent, dict):
        raise ValueError('agent attribution must be an object')
    name = agent.get('agent_name')
    if name is not None and (not isinstance(name, str) or not name):
        raise ValueError('invalid agent name')
    return name


def message_text(item):
    if item.get('type') != 'message':
        return ''
    content = item.get('content', [])
    if not isinstance(content, list):
        raise ValueError('message content must be an array')
    text = []
    for part in content:
        if not isinstance(part, dict):
            raise ValueError('message content item must be an object')
        if part.get('type') == 'output_text':
            value = part.get('text', '')
            if not isinstance(value, str):
                raise ValueError('output text must be a string')
            text.append(value)
    return ''.join(text)


def project(capture):
    multi = capture.get('mode', 'single') == 'multi_agent'
    owners, identities, observed = {}, {}, {}
    display = []
    terminal = None
    status = 'disconnected'
    ended = False

    def bind(index, item, owner):
        if index is not None and owner is not None:
            previous = owners.get(index)
            if previous is not None and previous != owner:
                raise ValueError('output index changed agent attribution')
            owners[index] = owner
        item_id = item.get('id')
        # Unknown hosted types may use opaque identity formats. Only correlate
        # string IDs that we understand; never rewrite or interpret their data.
        if isinstance(item_id, str) and item_id:
            if owner is not None:
                previous = identities.get(item_id)
                if previous is not None and previous != owner:
                    raise ValueError('output item changed agent attribution')
                identities[item_id] = owner

    for event in capture['events']:
        if ended:
            raise ValueError('event after terminal outcome')
        kind = event['type']
        index = event.get('output_index')
        if index is not None and (type(index) is not int or index < 0):
            raise ValueError('output_index must be a nonnegative integer')
        item = event.get('item', {})
        if not isinstance(item, dict):
            raise ValueError('output item must be an object')
        event_owner, item_owner = agent_name(event), agent_name(item)
        if event_owner is not None and item_owner is not None and event_owner != item_owner:
            raise ValueError('event and item changed agent attribution')
        owner = event_owner or item_owner
        if not multi and (owner is not None or item.get('type') in HOSTED_ITEMS):
            raise ValueError('attributed stream requires multi_agent mode')
        bind(index, item, owner)
        if kind in ('response.output_item.added', 'response.output_item.done'):
            if index is None or 'item' not in event:
                raise ValueError('item event requires output_index and item')
            message_text(item)
            observed[index] = item
        if kind == 'response.output_text.delta':
            delta = event.get('delta', '')
            if not isinstance(delta, str):
                raise ValueError('text delta must be a string')
            # Resolve at receipt time; later metadata cannot promote unknown text.
            if not multi or (owner or owners.get(index)) == '/root':
                display.append(delta)
        elif kind in TERMINALS:
            terminal = event.get('response')
            status = TERMINALS[kind]
            if not isinstance(terminal, dict) or terminal.get('status') != status:
                raise ValueError('terminal event/status mismatch')
            if status == 'completed' and (terminal.get('error') is not None or
                                          terminal.get('incomplete_details') is not None):
                raise ValueError('completed response contains error or incomplete details')
            ended = True
        elif kind == 'error':
            status = 'stream_error'
            ended = True

    items = terminal.get('output', []) if terminal is not None else [
        observed[index] for index in sorted(observed)]
    if not isinstance(items, list):
        raise ValueError('output must be an item array')
    final, visible = [], []
    pending_calls = False
    for index, item in enumerate(items):
        if not isinstance(item, dict):
            raise ValueError('output item must be an object')
        owner = agent_name(item)
        if not multi and (owner is not None or item.get('type') in HOSTED_ITEMS):
            raise ValueError('attributed output requires multi_agent mode')
        if terminal is not None:
            bind(index, item, owner)
        pending_calls = pending_calls or item.get('type') == 'function_call'
        text = message_text(item)
        if item.get('type') != 'message' or (multi and owner != '/root'):
            continue
        visible.append(text)
        if item.get('phase') == 'final_answer' or (not multi and item.get('phase') is None):
            final.append(text)

    # A disconnected final draft remains provisional.
    final_text = ''.join(final) if terminal is not None else ''
    display_text = ''.join(display)
    if not display_text:
        display_text = ''.join(visible)
    return {'status': status, 'display_text': display_text, 'final_text': final_text,
            'answer_complete': status == 'completed' and bool(final_text) and not pending_calls,
            'html': render(final_text or display_text)}, items
