"""Offline CLI regressions; all temporary artifacts stay under output/."""
import copy
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

OUTPUT = Path(__file__).resolve().parent
REPO = OUTPUT.parent / 'repo'


def message(text='Customer answer', owner='/root', phase='final_answer'):
    item = {'type': 'message', 'content': [{'type': 'output_text', 'text': text}]}
    if owner is not None:
        item['agent'] = {'agent_name': owner}
    if phase is not None:
        item['phase'] = phase
    return item


def terminal(items, status='completed', **extra):
    return {'type': 'response.' + status,
            'response': {'status': status, 'output': items, **extra}}


def added(index, item, **extra):
    return {'type': 'response.output_item.added', 'output_index': index,
            'item': item, **extra}


def delta(text, index=None, owner=None):
    event = {'type': 'response.output_text.delta', 'delta': text}
    if index is not None:
        event['output_index'] = index
    if owner is not None:
        event['agent'] = {'agent_name': owner}
    return event


class GatewayRegressionTests(unittest.TestCase):
    def call(self, events, mode='multi_agent', reject=False):
        with tempfile.TemporaryDirectory(dir=OUTPUT) as directory:
            source = Path(directory) / 'capture.json'
            destination = Path(directory) / 'view.json'
            capture = {'mode': mode, 'events': events}
            source.write_text(json.dumps(capture), encoding='utf-8')
            if reject:
                destination.write_text('previous valid publication', encoding='utf-8')
            process = subprocess.run(
                [sys.executable, '-m', 'gateway', '--capture', str(source),
                 '--out', str(destination)], cwd=REPO, capture_output=True,
                text=True, timeout=5,
                env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
            self.assertEqual(process.returncode, 2 if reject else 0,
                             process.stdout + process.stderr)
            self.assertEqual(process.stderr, '')
            if reject:
                self.assertIsInstance(json.loads(process.stdout)['error'], str)
                self.assertEqual(destination.read_text(), 'previous valid publication')
                self.assertFalse(list(Path(directory).glob('.gateway-*')))
                destination.unlink()
                again = subprocess.run(process.args, cwd=REPO, capture_output=True,
                                       text=True, timeout=5)
                self.assertEqual(again.returncode, 2)
                self.assertFalse(destination.exists())
                return
            bundle = json.loads(destination.read_text())
            self.assertEqual(bundle['archive']['events'], events)
            self.assertEqual(set(bundle['client']),
                             {'status', 'display_text', 'final_text', 'answer_complete', 'html'})
            return bundle

    def test_saved_incident_and_legacy(self):
        for name in ('incident', 'legacy'):
            capture = json.loads((REPO / 'traces' / (name + '.json')).read_text())
            bundle = self.call(capture['events'], capture['mode'])
            client = bundle['client']
            self.assertEqual(bundle['archive']['output_items'],
                             capture['events'][-1]['response']['output'])
            if name == 'incident':
                self.assertNotIn('Internal draft', json.dumps(client))
                self.assertEqual(client['display_text'], 'Checking your request.')
                self.assertEqual(client['final_text'], '')
                self.assertFalse(client['answer_complete'])
                self.assertEqual(bundle['archive']['summary']['item_count'], 3)
            else:
                self.assertEqual(client['final_text'], 'Order received.')
                self.assertTrue(client['answer_complete'])

    def test_interleaved_workers_root_and_unattributed(self):
        worker, root = message('private', '/root/research'), message('Public')
        unknown = message('unattributed', None)
        events = [added(0, worker), added(1, root), delta('private', 0),
                  delta('unattributed'), delta('Public', 1),
                  terminal([worker, root, unknown])]
        client = self.call(events)['client']
        self.assertEqual(client['display_text'], 'Public')
        self.assertEqual(client['final_text'], 'Public')
        self.assertTrue(client['answer_complete'])

    def test_direct_event_ownership_without_index(self):
        client = self.call([delta('secret', owner='/root/worker'),
                            delta('Progress', owner='/root')])['client']
        self.assertEqual(client['display_text'], 'Progress')
        self.assertEqual(client['status'], 'disconnected')
        self.assertFalse(client['answer_complete'])

    def test_only_explicit_root_final_completes_multi_agent(self):
        cases = [message(owner='/root/worker'), message(owner=None),
                 message(phase=None), message(phase='commentary'),
                 message(phase='future_phase')]
        for item in cases:
            with self.subTest(item=item):
                client = self.call([terminal([item])])['client']
                self.assertEqual(client['final_text'], '')
                self.assertFalse(client['answer_complete'])

    def test_terminal_statuses_and_pending_developer_calls(self):
        for status in ('completed', 'failed', 'incomplete', 'cancelled'):
            with self.subTest(status=status):
                client = self.call([terminal([message()], status)])['client']
                self.assertEqual(client['status'], status)
                self.assertEqual(client['answer_complete'], status == 'completed')
        for owner in ('/root', '/root/worker'):
            call = {'type': 'function_call', 'agent': {'agent_name': owner},
                    'call_id': 'call-418', 'name': 'never_execute',
                    'arguments': '{"command":"do not run"}', 'status': 'completed'}
            client = self.call([terminal([message(), call])])['client']
            self.assertFalse(client['answer_complete'])
            self.assertEqual(client['final_text'], 'Customer answer')

    def test_hosted_unknown_and_partial_items_are_lossless(self):
        items = [message(), {'type': 'multi_agent_call', 'arguments': 'opaque'},
                 {'type': 'multi_agent_call_output', 'output': {'keep': [1, None]}},
                 {'type': 'agent_message', 'encrypted': 'not-executable'},
                 {'type': 'future_hosted_kind', 'id': {'opaque': 42},
                  'nested': {'text': '<private>'}}]
        bundle = self.call([terminal(items)])
        self.assertEqual(bundle['archive']['output_items'], items)
        self.assertTrue(bundle['client']['answer_complete'])
        bundle = self.call([added(i, item) for i, item in enumerate(items)])
        self.assertEqual(bundle['archive']['output_items'], items)
        self.assertEqual(bundle['client']['status'], 'disconnected')
        self.assertEqual(bundle['client']['final_text'], '')
        self.assertFalse(bundle['client']['answer_complete'])

    def test_disconnect_and_stream_error_preserve_only_safe_progress(self):
        events = [added(0, message('internal', '/root/worker')),
                  delta('internal', 0), added(1, message('Working', phase='commentary')),
                  delta('Working', 1)]
        for suffix, expected in (([], 'disconnected'), ([{'type': 'error', 'message': 'lost'}], 'stream_error')):
            client = self.call(events + suffix)['client']
            self.assertEqual(client['status'], expected)
            self.assertEqual(client['display_text'], 'Working')
            self.assertEqual(client['final_text'], '')
            self.assertFalse(client['answer_complete'])

    def test_html_escapes_final_and_provisional_text(self):
        text = '<script>alert("418")</script>&\'safe\''
        expected = '<article>&lt;script&gt;alert(&quot;418&quot;)&lt;/script&gt;&amp;&#x27;safe&#x27;</article>'
        for events, mode in (([terminal([message(text)])], 'multi_agent'),
                             ([delta(text)], 'single')):
            client = self.call(events, mode)['client']
            self.assertEqual(client['html'], expected)
            self.assertEqual(client['final_text'] or client['display_text'], text)

    def test_capture_errors_never_publish(self):
        root, child = message(), message(owner='/root/worker')
        bad = [
            [{'type': 'response.completed', 'response': {'status': 'failed', 'output': []}}],
            [{'type': 'response.completed'}],
            [terminal([root], error={'message': 'bad'})],
            [terminal([root], incomplete_details={'reason': 'limit'})],
            [terminal([root]), terminal([root])],
            [terminal([root]), delta('after')],
            [{'type': 'error'}, terminal([root])],
            [added(0, child), delta('forged', 0, '/root')],
            [added(0, child), added(0, root)],
            [added(0, child), terminal([root])],
            [added(0, root, agent={'agent_name': '/root/worker'})],
            [delta('bad', index=-1)],
            [delta(42)],
            [terminal([{'type': 'message', 'agent': 'root', 'content': []}])],
            [terminal([{'type': 'message', 'content': 'bad'}])],
            [terminal([None])],
            [{'type': 'response.completed', 'response': {'status': 'completed', 'output': {}}}],
        ]
        same_id_child, same_id_root = copy.deepcopy(child), copy.deepcopy(root)
        same_id_child['id'] = same_id_root['id'] = 'same-message'
        bad.append([added(0, same_id_child), terminal([{}, same_id_root])])
        for events in bad:
            with self.subTest(events=events):
                self.call(events, reject=True)
        self.call([terminal([root])], mode='single', reject=True)

    def test_healthy_legacy_commentary_and_empty_completion(self):
        client = self.call([terminal([message('Progress', None, 'commentary'),
                                     message('Done', None, None)])], 'single')['client']
        self.assertEqual(client['final_text'], 'Done')
        self.assertTrue(client['answer_complete'])
        self.assertFalse(self.call([terminal([])], 'single')['client']['answer_complete'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
