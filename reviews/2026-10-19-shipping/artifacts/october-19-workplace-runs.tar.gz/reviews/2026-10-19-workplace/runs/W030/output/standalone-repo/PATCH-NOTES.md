# Incident 418: response gateway repair

The customer view now excludes worker and unattributed multi-agent text. The
saved incident displays `Checking your request.`, with empty `final_text` and
`answer_complete: false`. Transport `status: completed` is retained as recorded;
consumers must use `answer_complete` for the answer badge. All three captured
output items, including the opaque `agent_message`, remain in the ops archive.

## Cause and implementation

The old projector concatenated every delta without checking its owner and
accepted any message with a final or missing phase. It therefore promoted the
worker's `Internal draft` to the customer's final answer. Completion depended
only on transport status and nonempty text. Replay also filtered out hosted and
unknown item types, obscuring diagnosis, and presentation inserted raw text into
HTML.

- `gateway/projection.py` tracks ownership by output index and item identity,
  checks event/item/terminal consistency, and resolves delta attribution when
  received. Multi-agent final text requires an explicit `/root` `final_answer`.
  Root commentary remains progress. Unattributed deltas stay in the archive.
- A terminal event must match `response.status`. Completed responses containing
  errors or incomplete details, conflicting owners, and events after an outcome
  fail validation. Missing terminals stay disconnected; an error-only ending is
  `stream_error`. Failed, incomplete and cancelled outcomes cannot complete an
  answer. Any developer `function_call` in final output blocks completion,
  including calls owned by workers. Captured tools are never executed.
- `gateway/replay.py` deep-copies all events and output items without a type
  allowlist. Terminal output is authoritative; disconnected streams retain the
  latest captured added/done item for each index. Captured data is not rewritten.
- `gateway/render.py` escapes visible text inside the existing article element.
  `gateway/validation.py` also rejects non-object direct API inputs cleanly.
- Existing CLI arguments, JSON keys, atomic publication and phase-less legacy
  single-agent answers remain supported. Capture errors return exit 2 and JSON
  `{ "error": "..." }` before attempting publication.

## Reproduction and verification

Run from `repo/`, with artifacts under the workspace's `output/`:

```sh
python3 -m gateway --capture traces/incident.json --out ../output/repaired-incident.json
python3 -m gateway --capture traces/legacy.json --out ../output/repaired-legacy.json
env TMPDIR=../output/tmp PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests
python3 ../output/test_gateway_regression.py
```

Create `../output/tmp` first if needed. Before repair, replay of the saved
incident produced `display_text: Internal draftChecking your request.`,
`final_text: Internal draft`, `answer_complete: true`, and only two archived
items. `output/baseline-incident.json` records that reproduction. The repaired
artifact retains three items and publishes only root progress.

Verification passed: the three unmodified public tests and ten focused
regression tests. A separate copy of the repo under `output/standalone-repo/`
also replayed both saved traces with `PYTHONPATH` removed, confirming no skills
dependency. `output/verification.json` records these outcomes.
The regression module drives the real CLI for saved incident
and legacy captures, interleaved owners, direct attribution, unassigned text,
phase rules, four terminal statuses, worker/root pending calls, opaque hosted
and unknown items, disconnect/error, HTML escaping, and malformed/contradictory
captures. Rejected CLI replays are checked both with and without an existing
publication, including absence of temporary output files.

## Provenance and limits

The response-boundary design and validation approach were adapted locally from
AMind Engineering 0.3.1 `scripts/response_contract.py`; its Apache-2.0 license
and attribution notice are included in `third_party/amind-engineering/`.
The application adapter adds cancelled outcomes, partial-item retention and
HTML presentation. It keeps unknown types opaque without inferring their
execution semantics. It deliberately resolves streaming visibility at receipt
time rather than retrospectively assigning unknown deltas to a later owner.
No runtime import, absolute path or dependency on the skill distribution exists.
The companion eval-improve skill identifies ordinary regression testing as
outside its model-evaluation workflow; no model evaluation was needed here.

All verification is offline fixture replay, not evidence of hosted SDK or live
service compatibility. This gateway does not dispatch tools, reconcile tool
results, resume remote work, or determine whether an answer is factually correct.
`final_text` on a non-completed terminal may contain a captured partial draft;
`answer_complete` remains false. Unknown items alone do not assert pending work;
actual developer function calls do. A single capture represents one response:
concatenated outcomes or data following a terminal/error must be split upstream.
