# Support judge incident repair

The product remains a standard-library package runnable with:

```sh
cd repo
python3 -m judgecheck --input examples/review.json
python3 -m unittest discover -s tests -v
```

Changed `calibration.py`, `comparison.py`, and `__main__.py`; added `validation.py`.

- Confusion cells require both an adjudicated human label and a binary judge decision. Abstentions and unresolved adjudications remain separate, visible counts. Missing rates are null and named in `unmeasured`.
- Families with human labels are counted once regardless of repeated records. Duplicate case/repetition keys, invalid binary types, incomplete evaluation identities and family split leakage invalidate integrity.
- Workers count as completed only after explicit success for that required identity; missing, unknown, failed and duplicate reports cannot supply coverage.
- Pairing requires complete matching case/repetition populations and matching human/family/split metadata. Dataset/rubric identities are fixed; judge/grader changes are permitted. Incomplete judgments produce partial comparisons, with deltas computed only on comparable pairs.
- Drift fixes judge/grader/rubric identity and requires negative controls. Exact count fractions prevent a floating-point subtraction from turning equality with the declared margin into an alert.
- Deployment precision uses sensitivity and FPR with the supplied prevalence as a scenario. Readiness requires both evaluated classes and all documented evidence gates; it is never deployment approval.
- Structural input and JSON failures produce a JSON error with exit 2. Semantic holds retain exit 0. Duplicate JSON keys and non-JSON numeric constants are rejected.

Evidence:

- `baseline-review.json`: original incident was incorrectly marked ready; security was counted complete and abstention was converted into a true negative.
- `repaired-review.json`: the unchanged saved example now holds, with TP=2, TN=1, FP=1, FN=1; evaluated=5, abstained=1, coverage=5/6, two completed workers and uncovered security. Sample precision is 2/3; prevalence-0.001 scenario precision is approximately 0.001332889.
- `public-tests.log`: all 3 unchanged public tests passed.
- `integration_checks.py`, `integration.log`, `integration-results.json`, `fixtures/`: 11 local test groups, 63 actual CLI invocations, all passed. Cases include missing classes, unknown adjudications, constant/all-abstaining judges, repeated families, duplicate keys, paired population/identity mismatches, strict drift boundaries (including 0.4 minus 0.3 at margin 0.1), unavailable prevalence, malformed input and missing files.
- `standalone-check.json`: copied product source/examples into a local folder without skills, cleared PYTHONPATH, ran the documented CLI, and verified identical output.

All verification was offline and deterministic using local fixtures. No model-quality improvement, statistical significance, or deployment approval is inferred from these software checks. Existing `repo/tests/`, skills and task metadata were not edited.
