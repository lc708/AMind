"""Pair judges on a complete population; monitor a fixed judge across cohorts."""
from fractions import Fraction

from .calibration import audit, valid_identity


def paired(previous, current):
    if previous is None:
        return {'status': 'unmeasured'}, []
    issues = []
    for cohort in (previous, current):
        _, _, cohort_issues = audit(cohort)
        issues.extend(cohort_issues)
    if all(valid_identity(c.get('identity')) for c in (previous, current)):
        if any(previous['identity'][key] != current['identity'][key]
               for key in ('dataset_version', 'rubric')):
            issues.append('paired_identity_mismatch')
    # Validate before indexing: malformed or duplicate keys must never be collapsed.
    if issues:
        return {'status': 'invalid', 'pairs': len(current['records']), 'evaluated_pairs': 0}, issues
    def index(cohort):
        return {(row['id'], row.get('rep', 0)): row for row in cohort['records']}
    a, b = index(previous), index(current)
    if set(a) != set(b) or any(a[k][field] != b[k][field]
                              for k in set(a) & set(b) for field in ('human', 'family', 'split')):
        return {'status': 'invalid', 'pairs': len(b), 'evaluated_pairs': 0}, ['paired_population_mismatch']
    comparable = [k for k in b if b[k]['human'] is not None
                  and a[k]['decision'] is not None and b[k]['decision'] is not None]
    improved = sum(a[k]['decision'] != a[k]['human'] and b[k]['decision'] == b[k]['human'] for k in comparable)
    regressed = sum(a[k]['decision'] == a[k]['human'] and b[k]['decision'] != b[k]['human'] for k in comparable)
    return {'status': ('unmeasured' if not b else
                       'complete' if len(comparable) == len(b) else 'partial'),
            'pairs': len(b), 'evaluated_pairs': len(comparable), 'improved': improved, 'regressed': regressed,
            'agreement_delta': (improved - regressed) / len(comparable) if comparable else None}, []


def drift(previous, current, margin):
    if previous is None:
        return {'status': 'unmeasured', 'fpr_delta': None}, []
    old, _, issues = audit(previous)
    new, _, new_issues = audit(current)
    issues.extend(new_issues)
    if all(valid_identity(c.get('identity')) for c in (previous, current)):
        if any(previous['identity'][key] != current['identity'][key]
               for key in ('judge', 'grader_version', 'rubric')):
            issues.append('drift_judge_mismatch')
    if issues:
        return {'status': 'invalid', 'fpr_delta': None}, issues
    if old['fpr'] is None or new['fpr'] is None:
        return {'status': 'unmeasured', 'fpr_delta': None, 'margin': margin}, []
    # Compare counts exactly so an equal decimal margin cannot become an alert
    # through floating-point subtraction (for example, 0.4 - 0.3 > 0.1).
    delta = (Fraction(new['confusion']['fp'], new['denominators']['evaluated_negative'])
             - Fraction(old['confusion']['fp'], old['denominators']['evaluated_negative']))
    return {'status': 'alert' if delta > Fraction(str(margin)) else 'within_margin',
            'fpr_delta': float(delta), 'margin': margin}, []
