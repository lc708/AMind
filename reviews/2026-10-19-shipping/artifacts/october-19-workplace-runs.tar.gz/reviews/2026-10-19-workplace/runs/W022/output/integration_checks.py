"""Offline regression checks through the documented CLI; fixtures stay here."""
import copy
import json
from pathlib import Path
import subprocess
import sys
import unittest

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent / 'repo'
FIXTURES = HERE / 'fixtures'
FIXTURES.mkdir(exist_ok=True)
EXAMPLE = json.loads((ROOT / 'examples/review.json').read_text())
EVIDENCE = []


def base():
    job = copy.deepcopy(EXAMPLE)
    job['current']['records'][2]['decision'] = 0
    for worker in job['worker_reports']:
        worker['status'] = 'succeeded'
    return job


class CLIIntegration(unittest.TestCase):
    def run_job(self, job, name, exit_code=0):
        path = FIXTURES / (name + '.json')
        path.write_text(json.dumps(job))
        return self.run_path(path, name, exit_code)

    def run_path(self, path, name, exit_code):
        proc = subprocess.run([sys.executable, '-m', 'judgecheck', '--input', str(path)],
                              cwd=ROOT, capture_output=True, text=True)
        self.assertEqual(proc.returncode, exit_code, proc.stderr + proc.stdout)
        self.assertEqual(proc.stderr, '')
        packet = json.loads(proc.stdout)
        EVIDENCE.append({'case': name, 'exit_code': proc.returncode, 'packet': packet})
        return packet

    def test_saved_incident(self):
        p = self.run_job(EXAMPLE, 'saved-incident')
        self.assertEqual(p['status'], 'hold')
        self.assertEqual(p['calibration']['confusion'], dict(tp=2, tn=1, fp=1, fn=1))
        self.assertEqual(p['workers']['uncovered'], ['security'])
        self.assertAlmostEqual(p['deployment_precision']['value'], (2/3 * .001) / (2/3 * .001 + .5 * .999))

    def test_ready_and_unresolved(self):
        p = self.run_job(base(), 'complete')
        self.assertEqual(p['status'], 'ready_for_review')
        job = base()
        job['current']['records'][2]['human'] = None
        p = self.run_job(job, 'unresolved')
        self.assertEqual(p['status'], 'hold')
        self.assertEqual(p['calibration']['denominators']['unknown_human'], 1)
        self.assertEqual(p['calibration']['denominators']['adjudicated'], 5)
        self.assertEqual(p['calibration']['denominators']['evaluated'], 5)
        self.assertEqual(p['calibration']['confusion']['tn'], 1)
        job['current']['records'][2]['decision'] = None
        p = self.run_job(job, 'unresolved-abstention')
        self.assertEqual(p['calibration']['denominators']['abstained'], 1)
        self.assertEqual(p['calibration']['denominators']['unknown_human'], 1)

    def test_missing_classes_and_constant_judges(self):
        for label, missing in ((1, 'fpr'), (0, 'fnr')):
            job = base()
            job['current']['records'] = [r for r in job['current']['records'] if r['human'] == label]
            p = self.run_job(job, 'only-class-' + str(label))
            self.assertIsNone(p['calibration'][missing])
            self.assertIn(missing, p['calibration']['unmeasured'])
            self.assertEqual(p['status'], 'hold')
            self.assertIsNone(p['deployment_precision']['value'])
        for decision in (0, 1, None):
            job = base()
            for row in job['current']['records']:
                row['decision'] = decision
            p = self.run_job(job, 'constant-' + str(decision))
            if decision == 0:
                self.assertEqual(p['calibration']['fnr'], 1)
                self.assertIsNone(p['calibration']['precision'])
            elif decision == 1:
                self.assertEqual(p['calibration']['fpr'], 1)
            else:
                self.assertEqual(p['status'], 'hold')
                self.assertEqual(p['calibration']['denominators']['abstained'], 6)
        job['current']['records'] = []
        p = self.run_job(job, 'empty-population')
        self.assertEqual(p['status'], 'hold')
        self.assertIsNone(p['calibration']['judgment_coverage'])

    def test_family_count_and_repetitions(self):
        job = base()
        for row in job['current']['records']:
            row['family'] = 'one-family'
        p = self.run_job(job, 'one-family')
        self.assertEqual(p['family_count'], 1)
        self.assertEqual(p['status'], 'hold')
        job['current']['records'][0]['split'] = 'train'
        p = self.run_job(job, 'family-leakage')
        self.assertIn('family_crosses_split', p['integrity']['issues'])
        job = base()
        row = copy.deepcopy(job['current']['records'][0])
        row['rep'] = 1
        job['current']['records'].append(row)
        p = self.run_job(job, 'repeated-family')
        self.assertEqual(p['family_count'], 6)
        self.assertEqual(p['calibration']['denominators']['evaluated'], 7)
        job['current']['records'].append(copy.deepcopy(row))
        p = self.run_job(job, 'duplicate-repetition')
        self.assertEqual(p['integrity']['status'], 'invalid')
        self.assertEqual(p['status'], 'hold')

    def test_integrity_types(self):
        for field, value in [('human', True), ('decision', '1'), ('rep', False), ('id', []), ('split', 'test')]:
            job = base()
            job['current']['records'][0][field] = value
            p = self.run_job(job, 'bad-row-' + field)
            self.assertEqual(p['integrity']['status'], 'invalid')
            self.assertEqual(p['status'], 'hold')
        job = base()
        job['current']['identity']['extra'] = 'not-exact'
        self.assertEqual(self.run_job(job, 'identity-extra')['integrity']['status'], 'invalid')

    def test_workers(self):
        for status in ('unknown', 'failed', None, 'success'):
            job = base()
            job['worker_reports'][2]['status'] = status
            p = self.run_job(job, 'worker-' + str(status))
            self.assertEqual(p['workers']['uncovered'], ['security'])
            self.assertEqual(p['workers']['completed'], 2)
        job = base()
        job['worker_reports'].pop()
        job['worker_reports'].append({'id': 'extra', 'status': 'succeeded'})
        p = self.run_job(job, 'missing-extra-worker')
        self.assertEqual(p['workers']['uncovered'], ['security'])
        self.assertIn('unexpected_worker', p['integrity']['issues'])
        job = base()
        job['worker_reports'].append(copy.deepcopy(job['worker_reports'][2]))
        p = self.run_job(job, 'duplicate-worker')
        self.assertIn('duplicate_worker', p['integrity']['issues'])
        self.assertEqual(p['status'], 'hold')
        job = base()
        job['required_workers'] = []
        job['worker_reports'] = []
        p = self.run_job(job, 'no-required-workers')
        self.assertEqual(p['workers']['status'], 'unmeasured')
        self.assertEqual(p['status'], 'hold')

    def test_paired_complete_partial_and_mismatch(self):
        job = base()
        job['baseline'] = copy.deepcopy(job['current'])
        job['baseline']['identity']['judge'] = 'old'
        job['baseline']['identity']['grader_version'] = 'old'
        job['baseline']['records'][0]['decision'] = 0
        job['baseline']['records'][4]['decision'] = 0
        p = self.run_job(job, 'paired-complete')
        self.assertEqual(p['paired'], dict(status='complete', pairs=6, evaluated_pairs=6,
                                          improved=1, regressed=1, agreement_delta=0))
        self.assertEqual(p['status'], 'ready_for_review')
        partial = copy.deepcopy(job)
        partial['baseline']['records'][2]['decision'] = None
        p = self.run_job(partial, 'paired-abstention')
        self.assertEqual(p['paired']['status'], 'partial')
        self.assertEqual(p['paired']['evaluated_pairs'], 5)
        self.assertEqual(p['paired']['pairs'], 6)
        self.assertEqual(p['status'], 'hold')
        for field, value in [('human', 0), ('family', 'different'), ('split', 'train'), ('rep', 1)]:
            bad = copy.deepcopy(job)
            bad['baseline']['records'][0][field] = value
            p = self.run_job(bad, 'paired-mismatch-' + field)
            self.assertEqual(p['paired']['status'], 'invalid')
            self.assertIn('paired_population_mismatch', p['integrity']['issues'])
        for change in ('missing', 'extra', 'dataset', 'rubric', 'duplicate'):
            bad = copy.deepcopy(job)
            if change == 'missing':
                bad['baseline']['records'].pop()
            elif change == 'extra':
                row = copy.deepcopy(bad['baseline']['records'][0])
                row['id'] = 'extra'
                bad['baseline']['records'].append(row)
            elif change == 'duplicate':
                bad['baseline']['records'].append(copy.deepcopy(bad['baseline']['records'][0]))
            else:
                bad['baseline']['identity']['dataset_version' if change == 'dataset' else 'rubric'] = 'different'
            self.assertEqual(self.run_job(bad, 'paired-' + change)['paired']['status'], 'invalid')

    def test_drift_identity_controls_and_margin(self):
        job = base()
        job['drift_reference'] = copy.deepcopy(job['current'])
        job['drift_reference']['identity']['dataset_version'] = 'previous-cohort'
        p = self.run_job(job, 'drift-fixed-judge')
        self.assertEqual(p['drift']['status'], 'within_margin')
        self.assertEqual(p['status'], 'ready_for_review')
        for key in ('judge', 'grader_version', 'rubric'):
            bad = copy.deepcopy(job)
            bad['drift_reference']['identity'][key] = 'changed'
            p = self.run_job(bad, 'drift-changed-' + key)
            self.assertEqual(p['drift']['status'], 'invalid')
            self.assertIn('drift_judge_mismatch', p['integrity']['issues'])
        job['drift_reference']['records'] = [r for r in job['drift_reference']['records'] if r['human'] == 1]
        self.assertEqual(self.run_job(job, 'drift-no-negative-controls')['drift']['status'], 'unmeasured')
        job = base()
        job['current']['records'] = [dict(id='p', family='p', split='holdout', human=1, decision=1),
                                     dict(id='n1', family='n1', split='holdout', human=0, decision=1),
                                     dict(id='n2', family='n2', split='holdout', human=0, decision=0)]
        job['drift_reference'] = copy.deepcopy(job['current'])
        job['drift_reference']['records'][1]['decision'] = 0
        job['limits']['max_fpr_increase'] = .5
        self.assertEqual(self.run_job(job, 'drift-at-margin')['drift']['status'], 'within_margin')
        job['limits']['max_fpr_increase'] = .49
        p = self.run_job(job, 'drift-over-margin')
        self.assertEqual(p['drift']['status'], 'alert')
        self.assertEqual(p['status'], 'hold')

    def test_decimal_margin_and_empty_pairs(self):
        job = base()
        rows = [dict(id='p', family='p', split='holdout', human=1, decision=1)]
        rows += [dict(id='n' + str(i), family='n' + str(i), split='holdout',
                      human=0, decision=int(i < 4)) for i in range(10)]
        job['current']['records'] = rows
        job['drift_reference'] = copy.deepcopy(job['current'])
        job['drift_reference']['records'][4]['decision'] = 0
        job['limits']['max_fpr_increase'] = .1
        packet = self.run_job(job, 'decimal-margin-equality')
        self.assertEqual(packet['drift']['status'], 'within_margin')
        self.assertEqual(packet['drift']['fpr_delta'], .1)
        job = base()
        job['current']['records'] = []
        job['baseline'] = copy.deepcopy(job['current'])
        packet = self.run_job(job, 'empty-paired-population')
        self.assertEqual(packet['paired']['status'], 'unmeasured')
        self.assertEqual(packet['status'], 'hold')

    def test_scenarios_unmeasured(self):
        for i, value in enumerate((-1, 2, True, '0.1', None, 10**200)):
            job = base()
            job['deployment_prevalence'] = value
            p = self.run_job(job, 'invalid-prevalence-' + str(i))
            self.assertEqual(p['deployment_precision'], dict(status='unmeasured', value=None))

    def test_malformed_json_contract(self):
        for i, job in enumerate(([], {}, {'current': None}, dict(base(), current={'records': [None]}),
                                 dict(base(), limits={'max_fpr_increase': True, 'min_labeled_families': 1}),
                                 dict(base(), worker_reports=[None]))):
            self.assertIn('error', self.run_job(job, 'malformed-' + str(i), 2))
        for name, raw in [('invalid-json', '{'), ('duplicate-json-key', '{"current":1,"current":2}'),
                          ('nan-json', '{"value":NaN}')]:
            path = FIXTURES / (name + '.json')
            path.write_text(raw)
            self.assertIn('error', self.run_path(path, name, 2))
        self.assertIn('error', self.run_path(FIXTURES / 'does-not-exist.json', 'unreadable', 2))


if __name__ == '__main__':
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(CLIIntegration)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    (HERE / 'integration-results.json').write_text(json.dumps({'successful': result.wasSuccessful(),
                                                             'cli_cases': len(EVIDENCE), 'cases': EVIDENCE}, indent=2))
    raise SystemExit(0 if result.wasSuccessful() else 1)
