"""Validate input structure before semantic calibration and integrity checks."""
import math


def validate(job):
    if not isinstance(job, dict):
        raise ValueError('input must be a JSON object')
    if not isinstance(job.get('positive_event'), str) or not job['positive_event'].strip():
        raise ValueError('positive_event must be a nonempty string describing label 1')
    if 'current' not in job:
        raise ValueError('current cohort is required')
    for name in ('current', 'baseline', 'drift_reference'):
        if name not in job or (name != 'current' and job[name] is None):
            continue
        cohort = job[name]
        if not isinstance(cohort, dict) or not isinstance(cohort.get('records'), list):
            raise ValueError(f'{name} must be an object with a records array')
        if any(not isinstance(row, dict) for row in cohort['records']):
            raise ValueError(f'{name}.records must contain objects')
    if not isinstance(job.get('required_workers'), list):
        raise ValueError('required_workers must be an array')
    reports = job.get('worker_reports', [])
    if not isinstance(reports, list) or any(not isinstance(row, dict) for row in reports):
        raise ValueError('worker_reports must be an array of objects')
    limits = job.get('limits')
    if not isinstance(limits, dict):
        raise ValueError('limits must be an object')
    margin = limits.get('max_fpr_increase')
    if (type(margin) not in (int, float) or not 0 <= margin <= 1 or not math.isfinite(margin)):
        raise ValueError('max_fpr_increase must be a finite number between 0 and 1')
    families = limits.get('min_labeled_families')
    if type(families) is not int or families < 0:
        raise ValueError('min_labeled_families must be a nonnegative integer')


def unique_object(pairs):
    """Reject ambiguous JSON objects instead of silently retaining the last key."""
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f'duplicate JSON key: {key}')
        result[key] = value
    return result


def invalid_constant(value):
    raise ValueError(f'invalid JSON constant: {value}')
