"""Join the manifest's full population to verified results and attempt evidence."""
import math
from statistics import mean
from .accounting import account, exact_scope


def finite(value):
    try:
        return type(value) in (int, float) and math.isfinite(value)
    except OverflowError:
        return False


def validate_manifest(manifest):
    if not isinstance(manifest, dict):
        raise ValueError('manifest must be a JSON object')
    for field in ('release_id', 'variant', 'split', 'comparison_hash', 'treatment_hash'):
        if not isinstance(manifest.get(field), str) or not manifest[field]:
            raise ValueError('invalid manifest ' + field)
    ids, reps = manifest.get('case_ids'), manifest.get('repetitions')
    if (not isinstance(ids, list) or any(not isinstance(cid, str) or not cid for cid in ids)
            or len(set(ids)) != len(ids) or type(reps) is not int or reps < 1):
        raise ValueError('invalid planned population')
    metrics = manifest.get('metrics')
    if not isinstance(metrics, list) or not metrics:
        raise ValueError('metrics must be a nonempty list')
    seen = set()
    for metric in metrics:
        if not isinstance(metric, dict) or not isinstance(metric.get('id'), str) or not metric['id']:
            raise ValueError('invalid metric')
        if (metric['id'] in seen or any(not finite(metric.get(k)) for k in ('min', 'max', 'min_mean'))
                or metric['min'] > metric['max']):
            raise ValueError('invalid metric contract')
        seen.add(metric['id'])
    if 'expected_billing_identity' in manifest and not exact_scope(manifest['expected_billing_identity']):
        raise ValueError('invalid expected_billing_identity')
    contract = manifest.get('required_stages', {})
    if (not isinstance(contract, dict)
            or any(not isinstance(k, str) or not k or type(v) is not int or v < 0
                   for k, v in contract.items())):
        raise ValueError('invalid required_stages')


def stage_ok(report, contract):
    if not contract:
        return None
    if not isinstance(report, dict) or not isinstance(report.get('stages'), list):
        return False
    by_id = {}
    for stage in report['stages']:
        if (not isinstance(stage, dict) or not isinstance(stage.get('id'), str)
                or stage['id'] in by_id):
            return False
        by_id[stage['id']] = stage
    if set(by_id) != set(contract):
        return False
    for key, total in contract.items():
        row = by_id[key]
        counts = row.get('counts')
        if (type(row.get('total')) is not int or row['total'] != total
                or not finite(row.get('coverage')) or row['coverage'] != 1
                or row.get('uncovered') != [] or not isinstance(counts, dict)
                or counts.get('succeeded') != total
                or any(type(v) is not int or v < 0 for v in counts.values())
                or any(v != 0 for k, v in counts.items() if k != 'succeeded')):
            return False
    return True


def build(manifest, results, events, rates, requested_variant):
    validate_manifest(manifest)
    if not isinstance(rates, dict) or not isinstance(rates.get('rates'), list):
        raise ValueError('rate card must contain a rates list')
    if any(not isinstance(rate, dict) for rate in rates['rates']):
        raise ValueError('rate entries must be JSON objects')
    issues = []
    if requested_variant != manifest['variant']:
        issues.append('variant_mismatch')
    ids, reps = manifest['case_ids'], manifest['repetitions']
    population = [(cid, rep) for cid in ids for rep in range(reps)]
    planned = set(population)
    seen, accepted = set(), {}
    for row in results:
        if not isinstance(row, dict):
            raise ValueError('results must be JSON objects')
        if (not isinstance(row.get('case_id'), str) or type(row.get('rep')) is not int):
            issues.append('unexpected_result')
            continue
        key = row['case_id'], row['rep']
        if key in seen:
            issues.append('duplicate_result')
            accepted.pop(key, None)
            continue
        seen.add(key)
        if key not in planned:
            issues.append('unexpected_result')
            continue
        identity = {'comparison_hash': manifest['comparison_hash'], 'treatment_hash': manifest['treatment_hash'],
                    'case_id': key[0], 'rep': key[1]}
        actual_identity = row.get('result_identity')
        if (not isinstance(actual_identity, dict) or actual_identity != identity
                or type(actual_identity.get('rep')) is not int):
            issues.append('result_identity_mismatch')
            continue
        pin = manifest.get('expected_billing_identity')
        if pin is not None and row.get('billing_identity') != pin:
            issues.append('serving_identity_mismatch')
            continue
        if row.get('status') != 'ok':
            continue
        grade = row.get('grade')
        valid = isinstance(grade, dict) and set(grade) == {m['id'] for m in manifest['metrics']}
        if valid:
            valid = all(finite(grade[m['id']]) and m['min'] <= grade[m['id']] <= m['max']
                        for m in manifest['metrics'])
        if not valid:
            issues.append('invalid_grade')
            continue
        accepted[key] = row
    missing = [{'case_id': cid, 'rep': rep} for cid, rep in population if (cid, rep) not in accepted]
    metrics = {}
    for metric in manifest['metrics']:
        values = [row['grade'][metric['id']] for row in accepted.values()]
        metrics[metric['id']] = {'mean': mean(values) if values else None,
                                 'scored': len(values)}
    attempts, cost, ledger_issues = account(events, rates)
    issues.extend(ledger_issues)
    contract = manifest.get('required_stages', {})
    coverage = 'unmeasured'
    if contract:
        coverage = ('complete' if accepted and not missing
                    and all(stage_ok(row.get('coverage'), contract) for row in accepted.values())
                    else 'incomplete')
    quality = all(metrics[m['id']]['mean'] is not None and metrics[m['id']]['mean'] >= m['min_mean']
                  for m in manifest['metrics'])
    ready = not issues and not missing and quality and cost['total_usd'] is not None and coverage == 'complete'
    return {'release_id': manifest['release_id'], 'variant': requested_variant, 'split': manifest['split'],
            'planned_observations': len(population), 'scored_observations': len(accepted), 'missing': missing,
            'metrics': metrics, 'attempts': attempts, 'cost': cost, 'coverage': {'status': coverage},
            'integrity': {'status': 'invalid' if issues else 'verified', 'issues': sorted(set(issues))},
            'decision': 'ready' if ready else 'hold'}
