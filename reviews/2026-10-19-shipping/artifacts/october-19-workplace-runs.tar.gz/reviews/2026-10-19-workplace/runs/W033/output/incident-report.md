# 本地故障修复记录

修复前保存示例错误显示 planned=2、missing=[]、decision=ready；公开测试 1/3 通过。
修复后保存示例显示 planned=3、scored=2，缺少 account-recovery/0，decision=hold，保留已知费用 0.4 美元；公开测试 3/3 通过。

改动：
- report.py：以 manifest 计划的 case × repetition 为分母；过滤不兼容身份、重复和非法成绩；核对阶段覆盖与全部质量门槛。
- accounting.py：按 attempt_id 去重并报告不完整或乱序账本，身份不匹配的 finish 不关闭原始 start；失败调用照常计费，中断或非法费用保留未知；完整 scope 匹配费率，验证 token 类型和子集关系，要求完整计费用量声明。
- __main__.py：保留原参数、JSON 输出和退出状态；畸形 JSONL 提供文件与行号，避免 traceback。

实际执行：
- 在 repo/ 执行 `python3 -m unittest discover -s tests -v`：3/3 通过，临时目录限定为 output/tmp。
- 执行文档中的 `python3 -m releaseboard --bundle examples/saved-run --rates examples/rates.json --variant candidate`：正确 hold。
- 从工作区执行 `python3 output/integration_check.py`：85 个真实 CLI 场景通过。每个场景的输入与输出位于 output/integration/，汇总见 integration-results.json。
- 将 releaseboard 源码单独复制到 output/integration/standalone 后从该目录执行入口：ready，不依赖 skills 或源代码绝对路径。

这些是本地确定性 fixture 检查，不是模型质量或外部服务验证。没有网络或模型调用，未修改 skills/、task.json 或已有 tests/。基线源码、源码哈希与统一差异保存在 output/ 下。
