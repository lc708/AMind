"""Offline checks through the documented CLI; all generated fixtures stay here."""
import copy
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT / 'repo'
ARTIFACTS = ROOT / 'output' / 'integration'
ARTIFACTS.mkdir(exist_ok=True)
MANIFEST = json.loads((REPO / 'examples/saved-run/manifest.json').read_text())
RATES = json.loads((REPO / 'examples/rates.json').read_text())
BASE_RESULTS = [json.loads(x) for x in (REPO / 'examples/saved-run/results.jsonl').read_text().splitlines()]
BASE_EVENTS = [json.loads(x) for x in (REPO / 'examples/saved-run/attempts.jsonl').read_text().splitlines()]
RESULTS = copy.deepcopy(BASE_RESULTS)
last = copy.deepcopy(RESULTS[0])
last['case_id'] = 'account-recovery'
last['result_identity']['case_id'] = last['case_id']
RESULTS.append(last)
EVENTS = copy.deepcopy(BASE_EVENTS)
EVENTS.extend([{'event': 'started', 'attempt_id': 'recovered', 'case_id': 'account-recovery', 'rep': 0},
               {'event': 'finished', 'attempt_id': 'recovered', 'case_id': 'account-recovery', 'rep': 0,
                'status': 'ok', 'cost_usd': 0.1}])
records = []


def run(name, *, manifest=None, results=None, events=None, rates=None, variant='candidate', malformed=None, code=0):
    folder = ARTIFACTS / name
    folder.mkdir(exist_ok=True)
    (folder / 'manifest.json').write_text(json.dumps(MANIFEST if manifest is None else manifest))
    (folder / 'rates.json').write_text(json.dumps(RATES if rates is None else rates))
    for filename, rows in [('results.jsonl', RESULTS if results is None else results),
                           ('attempts.jsonl', EVENTS if events is None else events)]:
        (folder / filename).write_text(''.join(json.dumps(row) + '\n' for row in rows))
    if malformed:
        (folder / malformed[0]).write_text(malformed[1])
    env = dict(os.environ, TMPDIR=str(ROOT / 'output/tmp'), PYTHONDONTWRITEBYTECODE='1')
    proc = subprocess.run([sys.executable, '-m', 'releaseboard', '--bundle', str(folder),
                           '--rates', str(folder / 'rates.json'), '--variant', variant],
                          cwd=REPO, env=env, capture_output=True, text=True)
    assert proc.returncode == code, (name, proc.returncode, proc.stdout, proc.stderr)
    packet = json.loads(proc.stdout)
    assert not proc.stderr, (name, proc.stderr)
    (folder / 'packet.json').write_text(json.dumps(packet, indent=2) + '\n')
    records.append({'scenario': name, 'exit_code': code, 'decision': packet.get('decision')})
    return packet


def hold(packet, issue=None):
    assert packet['decision'] == 'hold', packet
    if issue:
        assert packet['integrity']['status'] == 'invalid', packet
        assert issue in packet['integrity']['issues'], packet


p = run('complete-ready')
assert p['decision'] == 'ready' and p['planned_observations'] == p['scored_observations'] == 3
assert p['coverage']['status'] == 'complete' and p['cost']['total_usd'] == 0.5
p = run('saved-incident', results=BASE_RESULTS, events=BASE_EVENTS)
hold(p)
assert p['missing'] == [{'case_id': 'account-recovery', 'rep': 0}]
assert p['cost']['known_usd'] == 0.4
hold(run('wrong-variant', variant='copied'), 'variant_mismatch')
for name, mutate, issue in [
    ('wrong-treatment', lambda r: r['result_identity'].update(treatment_hash='foreign'), 'result_identity_mismatch'),
    ('wrong-comparison', lambda r: r['result_identity'].update(comparison_hash='foreign'), 'result_identity_mismatch'),
    ('wrong-bound-case', lambda r: r['result_identity'].update(case_id='foreign'), 'result_identity_mismatch'),
    ('wrong-bound-rep', lambda r: r['result_identity'].update(rep=True), 'result_identity_mismatch'),
    ('wrong-serving-scope', lambda r: r['billing_identity'].update(region='elsewhere'), 'serving_identity_mismatch'),
    ('missing-serving-scope', lambda r: r.pop('billing_identity'), 'serving_identity_mismatch'),
    ('missing-identity', lambda r: r.pop('result_identity'), 'result_identity_mismatch'),
    ('boolean-rep', lambda r: r.update(rep=False), 'unexpected_result'),
    ('unexpected-case', lambda r: r.update(case_id='foreign'), 'unexpected_result'),
]:
    rows = copy.deepcopy(RESULTS)
    mutate(rows[0])
    p = run(name, results=rows)
    hold(p, issue)
    assert p['scored_observations'] == 2
p = run('duplicate-result', results=RESULTS + [RESULTS[0]])
hold(p, 'duplicate_result')
assert p['scored_observations'] == 2 and p['missing'] == [{'case_id': 'order-return', 'rep': 0}]
for i, value in enumerate([True, None, '1', -1, 2, float('nan'), float('inf')]):
    rows = copy.deepcopy(RESULTS)
    rows[0]['grade']['quality'] = value
    p = run(f'invalid-grade-{i}', results=rows)
    hold(p, 'invalid_grade')
    assert p['scored_observations'] == 2
rows = copy.deepcopy(RESULTS)
rows[0]['status'] = 'error'
p = run('failed-result', results=rows)
hold(p)
assert p['scored_observations'] == 2
p = run('no-results', results=[])
hold(p)
assert p['metrics']['quality'] == {'mean': None, 'scored': 0} and len(p['missing']) == 3
rows = copy.deepcopy(RESULTS)
for r in rows:
    r['grade']['quality'] = 0.1
hold(run('quality-gate', results=rows))
for name, mutate in [
    ('missing-stage', lambda r: r['coverage']['stages'].pop()),
    ('duplicate-stage', lambda r: r['coverage']['stages'].append(r['coverage']['stages'][0])),
    ('wrong-stage-total', lambda r: r['coverage']['stages'][0].update(total=2)),
    ('stage-failed', lambda r: r['coverage']['stages'][0].update(counts={'succeeded': 2, 'failed': 1})),
    ('stage-uncovered', lambda r: r['coverage']['stages'][0].update(uncovered=['worker-3'])),
    ('stage-fraction', lambda r: r['coverage']['stages'][0].update(coverage=0.5)),
    ('stage-boolean', lambda r: r['coverage']['stages'][0].update(coverage=True)),
    ('bad-stage-shape', lambda r: r['coverage'].update(stages=None)),
    ('missing-coverage', lambda r: r.pop('coverage')),
]:
    rows = copy.deepcopy(RESULTS)
    mutate(rows[0])
    p = run(name, results=rows)
    hold(p)
    assert p['coverage']['status'] == 'incomplete'
m = copy.deepcopy(MANIFEST)
m.pop('required_stages')
p = run('no-stage-contract', manifest=m)
hold(p)
assert p['coverage']['status'] == 'unmeasured'
# Failed calls are billable, explicit zero is known, interrupted calls are unknown.
start = {'event': 'started', 'attempt_id': 'judge-retry', 'case_id': 'order-return', 'rep': 0}
finish = dict(start, event='finished', status='error', cost_usd=0.3)
p = run('failed-retry', events=EVENTS + [start, finish])
assert p['decision'] == 'ready' and abs(p['cost']['total_usd'] - 0.8) < 1e-12
assert p['attempts']['failed'] == 1
p = run('interrupted', events=EVENTS + [start])
hold(p)
assert p['cost'] == {'known_usd': 0.5, 'total_usd': None, 'unknown_attempts': 1}
for i, value in enumerate([None, True, -1, '0.2', float('nan'), float('inf')]):
    p = run(f'unknown-explicit-cost-{i}', events=EVENTS + [start, dict(finish, cost_usd=value)])
    hold(p)
    assert p['cost'] == {'known_usd': 0.5, 'total_usd': None, 'unknown_attempts': 1}
p = run('explicit-zero', events=EVENTS + [start, dict(finish, cost_usd=0)])
assert p['decision'] == 'ready' and p['cost']['total_usd'] == 0.5
for name, extra, issue in [('duplicate-start', [EVENTS[0]], 'duplicate_started'),
                           ('duplicate-finish', [dict(EVENTS[1], cost_usd=9)], 'duplicate_finished')]:
    p = run(name, events=EVENTS + extra)
    hold(p, issue)
    assert p['cost']['known_usd'] == 0.5 and p['attempts']['started'] == p['attempts']['finished'] == 3
p = run('unmatched-finish', events=EVENTS + [finish])
hold(p, 'unmatched_finished')
assert abs(p['cost']['known_usd'] - 0.8) < 1e-12
p = run('mismatched-finish', events=EVENTS + [start, dict(finish, case_id='foreign')])
hold(p, 'unmatched_finished')
assert p['attempts']['interrupted'] == 1 and p['cost']['unknown_attempts'] == 1
assert p['cost']['total_usd'] is None and abs(p['cost']['known_usd'] - 0.8) < 1e-12
p = run('finish-before-start', events=EVENTS + [finish, start])
hold(p, 'unmatched_finished')
assert p['attempts']['interrupted'] == 1 and p['cost']['total_usd'] is None
for name, bad in [('bad-attempt-id', dict(start, attempt_id='')), ('bad-attempt-rep', dict(start, rep=True)),
                  ('bad-attempt-case', dict(start, case_id='')), ('bad-attempt-event', dict(start, event='unknown'))]:
    hold(run(name, events=EVENTS + [bad]), 'invalid_attempt_event')
# Full-scope matching plus cache/reasoning subsets are priced exactly once.
priced = dict(finish, status='ok', billing_identity=MANIFEST['expected_billing_identity'],
              usage={'input_tokens': 1000000, 'cached_input_tokens': 200000, 'output_tokens': 300000,
                     'reasoning_tokens': 100000}, all_billable_usage_included=True)
priced.pop('cost_usd')
p = run('text-estimate', events=EVENTS + [start, priced])
assert p['decision'] == 'ready' and abs(p['cost']['total_usd'] - 14.7) < 1e-12
for field in ('provider', 'interface', 'model', 'service_tier', 'region'):
    event = copy.deepcopy(priced)
    event['billing_identity'][field] = 'unpriced'
    p = run('scope-mismatch-' + field, events=EVENTS + [start, event])
    hold(p)
    assert p['cost']['unknown_attempts'] == 1
for name, mutate in [
    ('partial-usage', lambda e: e.update(all_billable_usage_included=False)),
    ('missing-completeness', lambda e: e.pop('all_billable_usage_included')),
    ('native-usage', lambda e: e['usage'].update(audio_tokens=50)),
    ('float-tokens', lambda e: e['usage'].update(input_tokens=1.5)),
    ('boolean-tokens', lambda e: e['usage'].update(output_tokens=True)),
    ('negative-tokens', lambda e: e['usage'].update(output_tokens=-1)),
    ('cache-over-input', lambda e: e['usage'].update(cached_input_tokens=2000000)),
    ('reasoning-over-output', lambda e: e['usage'].update(reasoning_tokens=400000)),
    ('incomplete-scope', lambda e: e['billing_identity'].pop('region')),
]:
    event = copy.deepcopy(priced)
    mutate(event)
    p = run(name, events=EVENTS + [start, event])
    hold(p)
    assert p['cost']['unknown_attempts'] == 1
input_only = copy.deepcopy(priced)
input_only['billing_identity']['interface'] = 'decisions'
input_only['usage'] = {'input_tokens': 1000000}
p = run('input-only-estimate', events=EVENTS + [start, input_only])
assert p['decision'] == 'ready' and p['cost']['total_usd'] == 2.5
for i, tokens in enumerate([True, 1.5, -1]):
    event = copy.deepcopy(input_only)
    event['usage']['input_tokens'] = tokens
    hold(run(f'invalid-input-only-{i}', events=EVENTS + [start, event]))
rates = copy.deepcopy(RATES)
rates['rates'].append(rates['rates'][0])
hold(run('ambiguous-rate', events=EVENTS + [start, priced], rates=rates))
# Multiple repetitions must preserve the entire Cartesian population.
m = copy.deepcopy(MANIFEST)
m['repetitions'] = 2
p = run('missing-repetitions', manifest=m)
hold(p)
assert p['planned_observations'] == 6 and len(p['missing']) == 3
rows = copy.deepcopy(RESULTS)
for row in RESULTS:
    other = copy.deepcopy(row)
    other['rep'] = other['result_identity']['rep'] = 1
    rows.append(other)
p = run('complete-repetitions', manifest=m, results=rows)
assert p['decision'] == 'ready' and p['scored_observations'] == 6
# Malformed input must produce exactly one JSON error with exit status 2.
for name, filename, content in [('bad-json', 'results.jsonl', '{bad\n'),
                                 ('nonobject-result', 'results.jsonl', '[]\n'),
                                 ('nonobject-event', 'attempts.jsonl', 'null\n'),
                                 ('nonobject-manifest', 'manifest.json', '[]'),
                                 ('bad-rates', 'rates.json', 'null')]:
    p = run(name, malformed=(filename, content), code=2)
    assert set(p) == {'error'}
for name, field, value in [('duplicate-cases', 'case_ids', ['a', 'a']),
                           ('boolean-repetitions', 'repetitions', True),
                           ('zero-repetitions', 'repetitions', 0),
                           ('bad-metrics', 'metrics', None),
                           ('bad-stage-contract', 'required_stages', []),
                           ('bad-billing-pin', 'expected_billing_identity', {})]:
    m = copy.deepcopy(MANIFEST)
    m[field] = value
    assert 'error' in run(name, manifest=m, code=2)
# Relocate only the product and fixture: no skill imports or fixed source path.
standalone = ARTIFACTS / 'standalone'
standalone.mkdir(exist_ok=True)
shutil.copytree(REPO / 'releaseboard', standalone / 'releaseboard', dirs_exist_ok=True,
                ignore=shutil.ignore_patterns('__pycache__'))
shutil.copytree(ARTIFACTS / 'complete-ready', standalone / 'bundle', dirs_exist_ok=True)
proc = subprocess.run([sys.executable, '-m', 'releaseboard', '--bundle', 'bundle',
                       '--rates', 'bundle/rates.json', '--variant', 'candidate'], cwd=standalone,
                      env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'), capture_output=True, text=True)
assert proc.returncode == 0 and json.loads(proc.stdout)['decision'] == 'ready', proc
records.append({'scenario': 'standalone-product', 'exit_code': 0, 'decision': 'ready'})
(ROOT / 'output/integration-results.json').write_text(json.dumps({'passed': len(records), 'runs': records}, indent=2) + '\n')
print(f'{len(records)} CLI integration scenarios passed')
