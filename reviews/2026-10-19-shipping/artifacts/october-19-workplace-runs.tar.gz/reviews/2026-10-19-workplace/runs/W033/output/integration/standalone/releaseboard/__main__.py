"""Build one release dashboard JSON from saved local evidence."""
import argparse
import json
from pathlib import Path
from .report import build


def jsonl(path):
    rows = []
    for line_number, line in enumerate(path.read_text().splitlines(), 1):
        if not line.strip():
            continue
        try:
            row = json.loads(line)
        except ValueError as exc:
            raise ValueError(f'{path.name}:{line_number}: {exc}') from exc
        if not isinstance(row, dict):
            raise ValueError(f'{path.name}:{line_number}: expected a JSON object')
        rows.append(row)
    return rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--bundle', required=True, type=Path)
    parser.add_argument('--rates', required=True, type=Path)
    parser.add_argument('--variant', required=True)
    args = parser.parse_args()
    try:
        manifest = json.loads((args.bundle / 'manifest.json').read_text())
        report = build(manifest, jsonl(args.bundle / 'results.jsonl'), jsonl(args.bundle / 'attempts.jsonl'),
                       json.loads(args.rates.read_text()), args.variant)
        print(json.dumps(report, allow_nan=False))
        return 0
    except (OSError, ValueError, KeyError, TypeError, OverflowError) as exc:
        print(json.dumps({'error': str(exc)}))
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
