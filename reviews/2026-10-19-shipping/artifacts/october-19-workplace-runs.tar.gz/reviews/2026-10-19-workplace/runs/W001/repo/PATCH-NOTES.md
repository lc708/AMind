# Incident 418: response gateway repair

The customer projection now admits only root-owned multi-agent text. Worker and
unattributed text stays in the operations archive. A completed transport without
an explicit root `final_answer` no longer grants an answer-complete badge.
The CLI, its JSON shape, and phase-less single-agent callers remain compatible.

## Cause and reproduction

The old projector concatenated every text delta without associating its output
index with an owner. It also accepted any agent's `final_answer` as customer text
and treated nonempty final text plus a completed transport as sufficient for
completion. The replay layer discarded unfamiliar hosted items, and the renderer
inserted captured text directly into HTML.

From `repo/`, reproduce the saved capture using the unchanged public entry point:

```sh
python3 -m gateway --capture traces/incident.json --out ../output/after-incident.json
```

Before repair, `display_text` was `Internal draftChecking your request.`,
`final_text` was `Internal draft`, and `answer_complete` was `true`. After repair,
the display is `Checking your request.`, final text is empty, and completion is
`false`. Transport status remains `completed`; it describes transport, whereas
`answer_complete` describes the customer answer. The archive retains all three
terminal items, including the opaque `agent_message` receipt.

## Changes

- `gateway/projection.py` binds output indexes and item IDs to message owners and
  phases, checks conflicting attribution, and separates progress from final text.
  Multi-agent finals require root ownership and an explicit `final_answer` phase;
  single-agent messages can still omit ownership and phase.
- Completed, failed, incomplete and cancelled terminal events must match their
  response status. A completed response carrying error or incomplete details,
  a second terminal, or data after a terminal outcome is rejected. Missing
  terminals remain disconnected; error events produce `stream_error`.
- Developer function calls remain pending data and prevent answer completion;
  their arguments never execute. Hosted and unfamiliar items remain opaque.
- `gateway/replay.py` deep-copies every terminal output item and all raw events.
  For a disconnected/error stream, output items are the latest captured item
  snapshots in output-index order; raw events retain every earlier snapshot.
- `gateway/render.py` uses standard-library HTML escaping for visible text.
  Capture envelope validation also handles direct callers supplying a non-object.
- Existing atomic output publication is preserved: protocol errors return exit 2
  and JSON containing `error`, leaving an existing output file untouched and
  creating no new output artifact.

The terminal-state design was informed by the supplied AMind Engineering
`scripts/response_contract.py` reference (Apache-2.0). The gateway implementation
is local application code using only Python's standard library; it neither
imports the skill nor depends on its installation path.

## Verification

From `repo/`, with all temporary fixtures confined to this delivery directory:

```sh
mkdir -p ../output/tmp
TMPDIR="$PWD/../output/tmp" python3 -m unittest discover -s tests -v
python3 ../output/test_gateway_regressions.py -v
python3 -m gateway --capture traces/legacy.json --out ../output/after-legacy.json
python3 -m gateway --capture traces/incident.json --out ../output/after-incident.json
```

The 3 unchanged public tests and 13 new CLI regression tests pass. Regression
subcases cover interleaved agents, exact root matching, unattributed text,
item-ID deltas, commentary and unknown phases, all terminal statuses, disconnects,
stream errors, pending developer calls, unknown hosted data preservation, HTML
escaping, contradictory statuses, conflicting owners/phases/IDs and malformed
known payloads. Error cases verify both preservation of an existing artifact and
absence of a new artifact. Baseline and repaired incident JSON are saved under
`output/`; regression source is `output/test_gateway_regressions.py`.

## Limits

Verification replays local fixtures through the real CLI; no network, hosted SDK,
model call, tool dispatch or browser runtime was used. This repair does not infer
ownership of unattributed multi-agent text or recover a final answer from a
disconnected stream. It rejects events following a terminal outcome rather than
guessing how to combine separate responses. Function calls are not executed or
reconciled by this replay-only gateway. Unknown item contents are archived, not
interpreted. No model setting was added or changed.
