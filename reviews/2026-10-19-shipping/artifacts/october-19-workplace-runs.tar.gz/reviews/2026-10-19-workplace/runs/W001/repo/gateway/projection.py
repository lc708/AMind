"""Customer projection with lossless, non-executable operations data.

Terminal handling is informed by AMind Engineering's offline response-contract
reference (Apache-2.0); ownership rules implement this repository's README.
"""
from .render import render

TERMINALS = {'response.completed': 'completed', 'response.failed': 'failed',
             'response.incomplete': 'incomplete', 'response.cancelled': 'cancelled'}


def owner(value):
    agent = value.get('agent')
    if agent is None:
        return None
    if not isinstance(agent, dict):
        raise ValueError('agent must be an object')
    name = agent.get('agent_name')
    if name is not None and (not isinstance(name, str) or not name):
        raise ValueError('agent_name must be a nonempty string')
    return name


def metadata(value, item=False):
    # Unknown hosted item fields are opaque. Only message metadata participates
    # in customer attribution; an unfamiliar item's own schema is not ours.
    if item and value.get('type') != 'message':
        return {'kind': value.get('type')}
    phase = value.get('phase')
    if phase is not None and not isinstance(phase, str):
        raise ValueError('message phase must be a string')
    return {'owner': owner(value), 'phase': phase,
            'kind': value.get('type') if item else None}


def validate_item(item):
    if not isinstance(item, dict):
        raise ValueError('output item must be an object')
    metadata(item, item=True)
    if item.get('type') == 'message':
        content = item.get('content', [])
        if not isinstance(content, list):
            raise ValueError('message content must be an array')
        for part in content:
            if not isinstance(part, dict):
                raise ValueError('message content item must be an object')
            if part.get('type') == 'output_text' and not isinstance(part.get('text', ''), str):
                raise ValueError('output text must be a string')


class Bindings:
    """Indexes and item IDs must never silently change owners or phases."""
    def __init__(self):
        self.indexes = {}
        self.ids = {}

    def bind(self, index, item_id, values):
        if index is not None and (type(index) is not int or index < 0):
            raise ValueError('output_index must be a nonnegative integer')
        if item_id is not None and (not isinstance(item_id, str) or not item_id):
            raise ValueError('item id must be a nonempty string')
        by_index = self.indexes.get(index) if index is not None else None
        by_id = self.ids.get(item_id) if item_id is not None else None
        candidates = [v for v in (by_index, by_id) if v is not None]
        merged = {}
        for candidate in candidates + [values, {'index': index, 'id': item_id}]:
            for key, value in candidate.items():
                if value is None:
                    continue
                if key in merged and merged[key] != value:
                    raise ValueError('inconsistent item attribution: ' + key)
                merged[key] = value
        for candidate in candidates:
            candidate.update(merged)
        binding = candidates[0] if candidates else merged
        if index is not None:
            self.indexes[index] = binding
        if item_id is not None:
            self.ids[item_id] = binding
        return binding


def visible(binding, multi):
    return (binding.get('kind') in (None, 'message')
            and (binding.get('owner') == '/root'
                 or (not multi and binding.get('owner') is None))
            and binding.get('phase') in (None, 'commentary', 'final_answer'))


def project(capture):
    multi = capture.get('mode', 'single') == 'multi_agent'
    bindings = Bindings()
    display = []
    terminal = None
    status = 'disconnected'
    stream_items = {}
    observed_calls = []
    for event in capture['events']:
        kind = event['type']
        if terminal is not None or status == 'stream_error':
            raise ValueError('event after terminal outcome')
        if kind in ('response.output_item.added', 'response.output_item.done'):
            item = event.get('item')
            validate_item(item)
            index = event.get('output_index')
            if index is None:
                raise ValueError('item event requires output_index')
            bindings.bind(index, item.get('id'), metadata(item, item=True))
            bindings.bind(index, item.get('id'), metadata(event))
            stream_items[index] = item
            if item.get('type') == 'function_call':
                observed_calls.append(item)
        elif kind == 'response.output_text.delta':
            delta = event.get('delta', '')
            if not isinstance(delta, str):
                raise ValueError('text delta must be a string')
            binding = bindings.bind(event.get('output_index'), event.get('item_id'), metadata(event))
            if visible(binding, multi):
                display.append(delta)
        elif kind in TERMINALS:
            terminal = event.get('response')
            status = TERMINALS[kind]
            if not isinstance(terminal, dict) or terminal.get('status') != status:
                raise ValueError('terminal event/status mismatch')
            if status == 'completed' and (terminal.get('error') is not None
                                          or terminal.get('incomplete_details') is not None):
                raise ValueError('completed response contains an error or incomplete details')
        elif kind == 'error':
            status = 'stream_error'

    items = terminal.get('output', []) if terminal is not None else [
        stream_items[index] for index in sorted(stream_items)]
    if not isinstance(items, list):
        raise ValueError('response output must be an array')
    final = []
    stream_indexes = sorted(stream_items)
    for index, item in enumerate(items):
        validate_item(item)
        # Terminal output arrays carry the original output-index ordering.
        output_index = index if terminal is not None else stream_indexes[index]
        binding = bindings.bind(output_index, item.get('id'), metadata(item, item=True))
        if item.get('type') != 'message' or not visible(binding, multi):
            continue
        phase = binding.get('phase')
        is_final = phase == 'final_answer' or (not multi and phase is None)
        if terminal is not None and is_final:
            final.extend(part.get('text', '') for part in item.get('content', [])
                         if part.get('type') == 'output_text')
    # Calls remain data: a completed arguments stream never executes a tool or
    # resolves a developer function call on behalf of the application.
    pending_calls = observed_calls + [item for item in items if item.get('type') == 'function_call']
    final_text = ''.join(final)
    display_text = ''.join(display)
    client = {'status': status, 'display_text': display_text, 'final_text': final_text,
              'answer_complete': status == 'completed' and bool(final_text) and not pending_calls,
              'html': render(final_text or display_text)}
    return client, items
