"""Offline regression coverage through the unchanged public CLI.

Run from repo: python3 ../output/test_gateway_regressions.py -v
All fixtures, temporary directories and subprocess outputs stay in this checkout.
"""
import html
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT / 'repo'
TEMP = ROOT / 'output' / 'tmp'
TEMP.mkdir(exist_ok=True)


def message(text, agent='/root', phase='final_answer', **extra):
    item = {'type': 'message', 'content': [{'type': 'output_text', 'text': text}]}
    if agent is not None:
        item['agent'] = {'agent_name': agent}
    if phase is not None:
        item['phase'] = phase
    return dict(item, **extra)


def terminal(items, status='completed', **extra):
    return {'type': 'response.' + status,
            'response': dict(status=status, output=items, **extra)}


def added(item, index=0):
    return {'type': 'response.output_item.added', 'output_index': index, 'item': item}


def delta(text, index=0, **extra):
    return dict(type='response.output_text.delta', output_index=index, delta=text, **extra)


class GatewayRegressions(unittest.TestCase):
    def call(self, events=None, mode='multi_agent', capture=None, error=False):
        capture = capture if capture is not None else {'mode': mode, 'events': events}
        with tempfile.TemporaryDirectory(dir=TEMP) as directory:
            directory = Path(directory)
            source = directory / 'capture.json'
            target = directory / 'view.json'
            source.write_text(json.dumps(capture), encoding='utf-8')
            old = '{"previous":"published artifact"}'
            if error:
                target.write_text(old, encoding='utf-8')
            process = subprocess.run(
                [sys.executable, '-m', 'gateway', '--capture', str(source), '--out', str(target)],
                cwd=REPO, capture_output=True, text=True,
                env=dict(os.environ, TMPDIR=str(TEMP)), timeout=10)
            self.assertEqual(process.returncode, 2 if error else 0, process.stdout + process.stderr)
            self.assertEqual(process.stderr, '')
            if error:
                self.assertIsInstance(json.loads(process.stdout)['error'], str)
                self.assertEqual(target.read_text(), old)
                target.unlink()
                process = subprocess.run(
                    [sys.executable, '-m', 'gateway', '--capture', str(source), '--out', str(target)],
                    cwd=REPO, capture_output=True, text=True, timeout=10)
                self.assertEqual(process.returncode, 2)
                self.assertFalse(target.exists())
                return
            return json.loads(target.read_text(encoding='utf-8'))

    def test_saved_incident_does_not_publish_worker_or_promote_commentary(self):
        capture = json.loads((REPO / 'traces/incident.json').read_text())
        result = self.call(capture=capture)
        self.assertEqual(result['client'], {
            'status': 'completed', 'display_text': 'Checking your request.',
            'final_text': '', 'answer_complete': False,
            'html': '<article>Checking your request.</article>'})
        self.assertEqual(result['archive']['events'], capture['events'])
        self.assertEqual(result['archive']['output_items'], capture['events'][-1]['response']['output'])
        self.assertEqual(result['archive']['summary']['item_count'], 3)

    def test_healthy_legacy_default_and_single_modes(self):
        item = message('Order received.', agent=None, phase=None)
        for capture in ({'events': [terminal([item])]},
                        {'mode': 'single', 'events': [terminal([item])] },
                        json.loads((REPO / 'traces/legacy.json').read_text())):
            with self.subTest(capture=capture):
                client = self.call(capture=capture)['client']
                self.assertEqual(client['final_text'], 'Order received.')
                self.assertTrue(client['answer_complete'])

    def test_interleaved_worker_and_root_keep_only_customer_text(self):
        worker = message('PRIVATE', agent='/root/search', id='worker')
        progress = message('Checking. ', phase='commentary', id='progress')
        answer = message('Ready.', id='answer')
        events = [added(worker), added(progress, 1), added(answer, 2),
                  delta('PRIVATE'), delta('Checking. ', 1), delta('Ready.', 2),
                  terminal([worker, progress, answer])]
        client = self.call(events)['client']
        self.assertEqual(client['display_text'], 'Checking. Ready.')
        self.assertEqual(client['final_text'], 'Ready.')
        self.assertTrue(client['answer_complete'])

    def test_multi_agent_requires_root_and_explicit_final_phase(self):
        for agent in (None, '/root/search', '/root2', '/root/'):
            with self.subTest(agent=agent):
                item = message('private', agent=agent)
                client = self.call([added(item), delta('private'), terminal([item])])['client']
                self.assertEqual(client['display_text'], '')
                self.assertEqual(client['final_text'], '')
                self.assertFalse(client['answer_complete'])
        for phase in (None, 'commentary', 'future_phase'):
            with self.subTest(phase=phase):
                item = message('progress', phase=phase)
                client = self.call([terminal([item])])['client']
                self.assertEqual(client['final_text'], '')
                self.assertFalse(client['answer_complete'])

    def test_unattributed_delta_is_not_retroactively_guessed_as_root(self):
        item = message('Final.')
        events = [delta('unattributed'), terminal([item])]
        result = self.call(events)
        self.assertEqual(result['client']['display_text'], '')
        self.assertEqual(result['client']['final_text'], 'Final.')
        self.assertEqual(result['archive']['events'], events)

    def test_item_id_can_identify_delta_without_output_index(self):
        item = message('Visible', id='m-root')
        event = {'type': 'response.output_text.delta', 'item_id': 'm-root', 'delta': 'Visible'}
        result = self.call([added(item), event, terminal([item])])
        self.assertEqual(result['client']['display_text'], 'Visible')

    def test_disconnected_and_error_streams_never_complete(self):
        for mode in ('single', 'multi_agent'):
            for error in (False, True):
                with self.subTest(mode=mode, error=error):
                    item = message('Working', phase='commentary')
                    events = [added(item), delta('Working')]
                    if error:
                        events.append({'type': 'error', 'message': 'connection lost'})
                    result = self.call(events, mode=mode)
                    self.assertEqual(result['client']['status'], 'stream_error' if error else 'disconnected')
                    self.assertFalse(result['client']['answer_complete'])
                    self.assertEqual(result['client']['final_text'], '')
                    self.assertEqual(result['archive']['events'], events)
                    self.assertEqual(result['archive']['output_items'], [item])

    def test_all_terminal_statuses_and_empty_completed(self):
        for status in ('completed', 'failed', 'incomplete', 'cancelled'):
            with self.subTest(status=status):
                client = self.call([terminal([message('Text')], status)])['client']
                self.assertEqual(client['status'], status)
                self.assertEqual(client['answer_complete'], status == 'completed')
        self.assertFalse(self.call([terminal([])])['client']['answer_complete'])

    def test_developer_call_prevents_completion_but_hosted_items_do_not(self):
        call = {'type': 'function_call', 'name': 'do_not_execute', 'call_id': 'c1',
                'arguments': '{"command":"never execute captured arguments"}', 'status': 'completed'}
        result = self.call([terminal([message('Draft'), call])])
        self.assertFalse(result['client']['answer_complete'])
        unknown = {'type': 'future_hosted_call', 'payload': {'nested': [None, 7, 'opaque']},
                   'agent': 'opaque hosted field', 'phase': {'opaque': True}}
        items = [message('Done'), {'type': 'web_search_call', 'status': 'completed'}, unknown]
        result = self.call([terminal(items)])
        self.assertTrue(result['client']['answer_complete'])
        self.assertEqual(result['archive']['output_items'], items)
        self.assertNotIn('payload', json.dumps(result['client']))

    def test_html_escapes_final_and_progress(self):
        text = '<script>alert("x")</script> & \'quoted\' 中文'
        for complete in (False, True):
            with self.subTest(complete=complete):
                item = message(text, phase='final_answer' if complete else 'commentary')
                events = [added(item), delta(text)] + ([terminal([item])] if complete else [])
                client = self.call(events)['client']
                self.assertEqual(client['html'], '<article>' + html.escape(text) + '</article>')
                self.assertEqual(client['display_text'], text)

    def test_terminal_contradictions_preserve_published_artifact(self):
        cases = [
            [{'type': 'response.completed', 'response': {'status': 'failed', 'output': []}}],
            [{'type': 'response.failed', 'response': {'status': 'completed', 'output': []}}],
            [{'type': 'response.completed'}],
            [terminal([], error={'message': 'failure'})],
            [terminal([], incomplete_details={})],
            [terminal([]), terminal([])],
            [terminal([]), delta('late')],
            [{'type': 'error'}, terminal([])],
        ]
        for events in cases:
            with self.subTest(events=events):
                self.call(events, error=True)

    def test_owner_phase_and_identity_conflicts_are_capture_errors(self):
        worker = message('private', agent='/root/search', id='worker')
        cases = [
            [added(worker), terminal([message('private', id='worker')])],
            [added(worker), delta('private', agent={'agent_name': '/root'})],
            [added(message('progress', phase='commentary')), terminal([message('final')])],
            [added(message('root', id='root')), added(worker, 1), delta('private', 0, item_id='worker')],
            [added(worker), added(message('new', id='other'))],
        ]
        for events in cases:
            with self.subTest(events=events):
                self.call(events, error=True)

    def test_malformed_known_payloads_are_json_errors(self):
        cases = [
            [terminal('not an output array')],
            [terminal([None])],
            [terminal([{'type': 'message', 'content': 'wrong'}])],
            [terminal([{'type': 'message', 'content': [None]}])],
            [terminal([message(42)])],
            [delta(42)],
            [delta('bad', -1)],
            [delta('bad', True)],
        ]
        for events in cases:
            with self.subTest(events=events):
                self.call(events, error=True)


if __name__ == '__main__':
    unittest.main()
