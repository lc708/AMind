# 本地事故修复与验证

范围：保持 `python3 -m judgecheck --input ...` 和既有 JSON 顶层字段；全部使用本地数据与标准库。未修改 skills/、task.json 或 repo/tests/，未调用网络、模型或子 agent。

修复：

- calibration.py 分开统计未裁定、弃权、已裁定及可评分样本；使用正确类别分母，缺失指标输出 null/unmeasured；按已裁定 family 去重计数。
- 精确率情景计算加入负例发生率 `(1 - prevalence)`；非法发生率和不可计算情景保持 unmeasured。
- comparison.py 校验完整 case/rep/human/family/split 人口，拒绝静默取交集；不完整判断保留 partial 和总配对数。漂移固定 judge/grader/rubric，并使用精确比率比较阈值。
- 必需 worker 只有明确 succeeded 才计入完成；重复报告不增加完成数，额外报告不能补缺，重复记录使完整性无效。
- 新增 validation.py，区分结构错误（JSON error，退出 2）和证据缺陷（hold，退出 0）；检查跨 cohort 的 family split。
- README.md 补充各分母、覆盖率和边界行为。

已执行的证据：

| 检查 | 结果 | 保存文件 |
| --- | --- | --- |
| 修复前公开测试 | 3 项中 2 项失败 | baseline-tests.txt |
| 修复后公开测试 | 3 项全部通过 | public-tests.txt |
| 真实 CLI 集成检查 | 67 个场景全部通过 | integration_check.py、integration-results.json、fixtures/ |
| 独立产品副本 | 无 skills，空 PYTHONPATH，禁用用户 site；公开入口结果一致 | standalone-check.json、standalone-product/ |
| 最终源码和输入版本 | SHA-256 | source-sha256.json |

保存的事故示例修复前误报 ready_for_review；修复后为 hold。FPR 从 1/3 修正为 1/2，弃权为 1 条，security 未覆盖，情景精确率由错误的 0.666667 修正为约 0.001333。原始与修复结果分别在 baseline-review.json、repaired-review.json。

集成场景涵盖缺失类别、未知裁定、弃权、常量判断负控制、重复 rep/family、split 泄漏、无效身份和标签、配对人口变化、版本差异、漂移缺失负例、严格阈值及浮点边界、worker 缺失/未知/重复/额外、无效发生率，以及畸形 JSON/结构。它们验证的是离线管道行为；没有新增真实裁定或部署观测，不能据此声称评审器质量提升或批准部署。

复现：在 repo/ 运行 `python3 -m unittest discover -s tests -v`、`python3 -m judgecheck --input examples/review.json` 和 `python3 ../output/integration_check.py`。
