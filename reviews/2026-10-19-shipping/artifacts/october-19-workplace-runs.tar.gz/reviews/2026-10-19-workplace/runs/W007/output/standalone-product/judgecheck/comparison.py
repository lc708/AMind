"""Pair judge versions on fixed examples; monitor a fixed judge across cohorts."""
from fractions import Fraction
from .calibration import audit


def paired(previous, current):
    if previous is None:
        return {'status': 'unmeasured'}, []
    issues = []
    _, _, old_issues = audit(previous)
    _, _, new_issues = audit(current)
    issues.extend(old_issues + new_issues)
    if issues:
        return {'status': 'invalid', 'pairs': len(current['records']), 'evaluated_pairs': 0}, issues
    for key in ('dataset_version', 'rubric'):
        if previous.get('identity', {}).get(key) != current.get('identity', {}).get(key):
            issues.append('paired_identity_mismatch')
    if issues:
        return {'status': 'invalid', 'pairs': len(current['records']), 'evaluated_pairs': 0}, issues
    key = lambda row: (row['id'], row.get('rep', 0))
    a, b = ({key(r): r for r in c['records']} for c in (previous, current))
    if a.keys() != b.keys() or any(
        a[k][field] != b[k][field] for k in a.keys() & b.keys()
        for field in ('human', 'family', 'split')
    ):
        return {'status': 'invalid', 'pairs': len(b), 'evaluated_pairs': 0}, ['paired_population_mismatch']
    comparable = [k for k in a if all(r[f] is not None for r in (a[k], b[k]) for f in ('human', 'decision'))]
    improved = sum(a[k]['decision'] != a[k]['human'] and b[k]['decision'] == b[k]['human'] for k in comparable)
    regressed = sum(a[k]['decision'] == a[k]['human'] and b[k]['decision'] != b[k]['human'] for k in comparable)
    return {'status': 'complete' if len(comparable) == len(a) else 'partial', 'pairs': len(a),
            'evaluated_pairs': len(comparable), 'improved': improved, 'regressed': regressed,
            'agreement_delta': (improved - regressed) / len(comparable) if comparable else None}, []


def drift(previous, current, margin):
    if previous is None:
        return {'status': 'unmeasured', 'fpr_delta': None}, []
    old, _, issues = audit(previous)
    new, _, new_issues = audit(current)
    issues.extend(new_issues)
    if issues:
        return {'status': 'invalid', 'fpr_delta': None}, issues
    for key in ('judge', 'grader_version', 'rubric'):
        if previous.get('identity', {}).get(key) != current.get('identity', {}).get(key):
            issues.append('drift_judge_mismatch')
    if issues:
        return {'status': 'invalid', 'fpr_delta': None}, issues
    if old['fpr'] is None or new['fpr'] is None:
        return {'status': 'unmeasured', 'fpr_delta': None, 'margin': margin}, []
    # Compare exact count ratios so rounding cannot turn equality into an alert.
    delta = (Fraction(new['confusion']['fp'], new['denominators']['evaluated_negative'])
             - Fraction(old['confusion']['fp'], old['denominators']['evaluated_negative']))
    return {'status': 'alert' if delta > Fraction(str(margin)) else 'within_margin',
            'fpr_delta': float(delta), 'margin': margin}, []
