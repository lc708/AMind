"""Offline behavioral probes through the documented CLI; fixtures stay here."""
import copy
import json
from pathlib import Path
import subprocess
import sys

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent / 'repo'
FIXTURES = OUT / 'fixtures'
FIXTURES.mkdir(exist_ok=True)
RESULTS = []


def base():
    return {
        'positive_event': 'genuine_support_policy_issue',
        'current': {
            'identity': {'dataset_version': 'v1', 'judge': 'current',
                         'grader_version': 'g1', 'rubric': 'policy-v1'},
            'records': [
                {'id': name, 'family': name, 'split': 'holdout', 'human': h, 'decision': d}
                for name, h, d in [('tp', 1, 1), ('fn', 1, 0), ('fp', 0, 1), ('tn', 0, 0)]
            ]},
        'required_workers': ['billing', 'support', 'security'],
        'worker_reports': [{'id': name, 'status': 'succeeded'}
                           for name in ['billing', 'support', 'security']],
        'deployment_prevalence': 0.001,
        'limits': {'max_fpr_increase': 0.03, 'min_labeled_families': 2},
    }


def run(name, job, code=0):
    path = FIXTURES / (name + '.json')
    path.write_text(json.dumps(job, indent=2))
    p = subprocess.run([sys.executable, '-m', 'judgecheck', '--input', str(path)],
                       cwd=ROOT, capture_output=True, text=True, timeout=10)
    assert p.returncode == code, (name, p.returncode, p.stdout, p.stderr)
    assert not p.stderr, (name, p.stderr)
    data = json.loads(p.stdout)
    RESULTS.append({'case': name, 'exit_code': p.returncode, 'output': data})
    if code == 2:
        assert set(data) == {'error'}, (name, data)
    return data


def invalid(name, job, issue):
    data = run(name, job)
    assert data['status'] == 'hold'
    assert data['integrity']['status'] == 'invalid'
    assert issue in data['integrity']['issues'], (name, data)
    return data


def main():
    saved = json.loads((ROOT / 'examples/review.json').read_text())
    d = run('saved-example', saved)
    assert d['calibration']['confusion'] == {'tp': 2, 'tn': 1, 'fp': 1, 'fn': 1}
    assert d['calibration']['fpr'] == 0.5
    assert d['workers']['uncovered'] == ['security']
    assert abs(d['deployment_precision']['value'] - 0.0013328890369876708) < 1e-15

    d = run('complete-review', base())
    assert d['status'] == 'ready_for_review' and d['integrity']['status'] == 'verified'
    assert all(d['calibration'][name] == 0.5 for name in ['fpr', 'fnr', 'precision', 'recall'])
    assert d['deployment_precision'] == {'status': 'scenario', 'value': 0.001}

    j = base()
    for i, (h, decision) in enumerate([(None, 1), (None, None), (0, None), (1, None)]):
        j['current']['records'].append(dict(id=f'extra{i}', family=f'extra{i}', split='holdout', human=h, decision=decision))
    d = run('unresolved-and-abstained', j)
    assert d['calibration']['denominators'] == dict(adjudicated=6, human_positive=3, human_negative=3,
        evaluated=4, evaluated_positive=2, evaluated_negative=2, abstained=3, unknown_human=2)
    assert d['calibration']['judgment_coverage'] == 0.5 and d['family_count'] == 6
    assert d['status'] == 'hold'

    for human, missing in [(1, 'fpr'), (0, 'fnr')]:
        j = base(); j['current']['records'] = [r for r in j['current']['records'] if r['human'] == human]
        d = run(f'missing-class-{human}', j)
        assert d['calibration'][missing] is None and missing in d['calibration']['unmeasured']
        assert d['status'] == 'hold' and d['deployment_precision']['status'] == 'unmeasured'
    j = base(); j['current']['records'] = []
    d = run('empty-cohort', j)
    assert d['status'] == 'hold' and d['calibration']['judgment_coverage'] is None
    assert set(d['calibration']['unmeasured']) == {'fpr', 'fnr', 'precision', 'recall'}
    j = base()
    for r in j['current']['records']: r['decision'] = 0
    d = run('constant-negative-control', j)
    assert d['calibration']['recall'] == 0 and d['calibration']['fnr'] == 1
    assert d['calibration']['precision'] is None and d['deployment_precision']['value'] is None
    j = base()
    for r in j['current']['records']: r['decision'] = 1
    d = run('constant-positive-control', j)
    assert d['calibration']['fpr'] == 1 and d['deployment_precision']['value'] == 0.001

    j = base()
    j['current']['records'] += [dict(r, rep=1) for r in j['current']['records']]
    j['limits']['min_labeled_families'] = 5
    d = run('replicas-do-not-add-families', j)
    assert d['family_count'] == 4 and d['status'] == 'hold'
    j = base(); j['current']['records'].append(copy.deepcopy(j['current']['records'][0]))
    invalid('duplicate-example', j, 'duplicate_or_invalid_example')
    j = base(); j['current']['records'][1]['family'] = 'tp'; j['current']['records'][1]['split'] = 'train'
    invalid('family-split-leak', j, 'family_crosses_split')
    for field, value, issue in [('human', True, 'invalid_human_label'), ('decision', '0', 'invalid_judge_decision'),
                                ('id', [], 'duplicate_or_invalid_example'), ('rep', -1, 'duplicate_or_invalid_example')]:
        j = base(); j['current']['records'][0][field] = value
        invalid('invalid-' + field, j, issue)
    j = base(); del j['current']['records'][0]['human']
    invalid('absent-label-is-not-null', j, 'missing_label')
    for ident in [None, [], {}, dict(base()['current']['identity'], extra='untracked')]:
        j = base(); j['current']['identity'] = ident
        invalid('identity-' + str(len(RESULTS)), j, 'invalid_evaluation_identity')

    j = base(); j['baseline'] = copy.deepcopy(j['current'])
    j['baseline']['identity'].update(judge='previous', grader_version='old-grader')
    for r, decision in zip(j['baseline']['records'], [0, 1, 1, 1]): r['decision'] = decision
    j['baseline']['records'].reverse()
    d = run('complete-paired-change', j)
    assert d['paired'] == dict(status='complete', pairs=4, evaluated_pairs=4, improved=2, regressed=1, agreement_delta=0.25)
    assert d['status'] == 'ready_for_review'
    partial = copy.deepcopy(j); partial['baseline']['records'][0]['decision'] = None
    d = run('paired-abstention', partial)
    assert d['paired'] == dict(status='partial', pairs=4, evaluated_pairs=3, improved=1, regressed=1, agreement_delta=0.0)
    assert d['status'] == 'hold'
    for field, value in [('human', 1), ('family', 'other'), ('split', 'validation'), ('rep', 1)]:
        broken = copy.deepcopy(j); broken['baseline']['records'][0][field] = value
        d = invalid('paired-mismatch-' + field, broken, 'paired_population_mismatch')
        assert d['paired']['status'] == 'invalid'
    broken = copy.deepcopy(j); broken['baseline']['records'].pop()
    invalid('missing-pair', broken, 'paired_population_mismatch')
    for field in ['dataset_version', 'rubric']:
        broken = copy.deepcopy(j); broken['baseline']['identity'][field] = 'changed'
        invalid('paired-identity-' + field, broken, 'paired_identity_mismatch')
    broken = copy.deepcopy(j); broken['baseline']['identity'] = None
    invalid('paired-malformed-identity', broken, 'invalid_evaluation_identity')

    j = base(); j['drift_reference'] = copy.deepcopy(j['current'])
    j['drift_reference']['identity']['dataset_version'] = 'older-data'
    for r in j['drift_reference']['records']:
        if r['human'] == 0: r['decision'] = 0
    for margin, status in [(0.5, 'within_margin'), (0.49, 'alert')]:
        j['limits']['max_fpr_increase'] = margin
        d = run('drift-' + status, j)
        assert d['drift']['status'] == status and d['drift']['fpr_delta'] == 0.5
        assert d['status'] == ('ready_for_review' if status == 'within_margin' else 'hold')
    for field in ['judge', 'grader_version', 'rubric']:
        broken = copy.deepcopy(j); broken['drift_reference']['identity'][field] = 'changed'
        d = invalid('drift-identity-' + field, broken, 'drift_judge_mismatch')
        assert d['drift']['status'] == 'invalid'
    broken = copy.deepcopy(j)
    broken['drift_reference']['records'] = [r for r in broken['drift_reference']['records'] if r['human'] == 1]
    d = run('drift-no-negative-controls', broken)
    assert d['drift']['status'] == 'unmeasured' and d['drift']['fpr_delta'] is None
    j = base(); j['drift_reference'] = copy.deepcopy(j['current'])
    for cohort, false_positives in [(j['current'], 4), (j['drift_reference'], 3)]:
        cohort['records'] = [dict(id=f'n{i}', family=f'n{i}', split='holdout', human=0, decision=int(i < false_positives)) for i in range(10)]
    j['limits']['max_fpr_increase'] = 0.1
    d = run('drift-exact-decimal-boundary', j)
    assert d['drift']['status'] == 'within_margin' and d['drift']['fpr_delta'] == 0.1

    for status in ['failed', 'unknown', 'running', None]:
        j = base(); j['worker_reports'][-1]['status'] = status
        d = run('worker-' + str(status), j)
        assert d['workers']['completed'] == 2 and d['workers']['uncovered'] == ['security'] and d['status'] == 'hold'
    j = base(); j['worker_reports'].pop()
    d = run('worker-missing', j)
    assert d['workers']['uncovered'] == ['security']
    j['worker_reports'].append(dict(id='extra', status='succeeded'))
    d = invalid('worker-extra-cannot-substitute', j, 'unexpected_worker')
    assert d['workers']['completed'] == 2
    j = base(); j['worker_reports'].append(dict(id='security', status='succeeded'))
    d = invalid('worker-duplicate', j, 'duplicate_worker')
    assert d['workers']['completed'] == 3
    j = base(); j['worker_reports'].pop(); j['worker_reports'].append(dict(id='billing', status='succeeded'))
    d = invalid('worker-duplicate-cannot-substitute', j, 'duplicate_worker')
    assert d['workers']['completed'] == 2 and d['workers']['uncovered'] == ['security']
    j = base(); j['required_workers'].append('security')
    invalid('duplicate-required-worker', j, 'duplicate_required_worker')
    j = base(); j['required_workers'] = []; j['worker_reports'] = []
    d = run('no-required-workers', j)
    assert d['workers']['status'] == 'unmeasured' and d['status'] == 'hold'

    for i, prevalence in enumerate([None, -1, 2, '0.1', True, float('nan'), float('inf'), 10 ** 500]):
        j = base(); j['deployment_prevalence'] = prevalence
        d = run('invalid-prevalence-' + str(i), j)
        assert d['deployment_precision'] == {'status': 'unmeasured', 'value': None}
    for prevalence in [0, 1]:
        j = base(); j['deployment_prevalence'] = prevalence
        assert run('prevalence-' + str(prevalence), j)['deployment_precision']['value'] == prevalence

    for name, mutate in [
        ('missing-current', lambda j: j.pop('current')),
        ('bad-cohort', lambda j: j.update(current=[])),
        ('bad-records', lambda j: j['current'].update(records={})),
        ('bad-row', lambda j: j['current']['records'].append(None)),
        ('bad-worker-array', lambda j: j.update(worker_reports={})),
        ('bad-required-worker', lambda j: j.update(required_workers=[{}])),
        ('bad-margin', lambda j: j['limits'].update(max_fpr_increase='0.1')),
        ('bad-family-limit', lambda j: j['limits'].update(min_labeled_families=True)),
    ]:
        j = base(); mutate(j); run(name, j, code=2)
    run('non-object-input', [], code=2)
    path = FIXTURES / 'malformed-json.json'; path.write_text('{')
    p = subprocess.run([sys.executable, '-m', 'judgecheck', '--input', str(path)], cwd=ROOT, capture_output=True, text=True)
    assert p.returncode == 2 and 'error' in json.loads(p.stdout) and not p.stderr
    RESULTS.append(dict(case='malformed-json', exit_code=2, output=json.loads(p.stdout)))


if __name__ == '__main__':
    main()
    (OUT / 'integration-results.json').write_text(json.dumps({'passed': len(RESULTS), 'results': RESULTS}, indent=2) + '\n')
    print(f'{len(RESULTS)} CLI integration cases passed; fixtures and results saved under output/.')
