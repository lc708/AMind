"""Validate JSON structure; evidence-integrity defects are semantic holds."""
import math


def validate_job(job):
    if not isinstance(job, dict):
        raise ValueError('input must be a JSON object')
    if not isinstance(job.get('positive_event'), str) or not job['positive_event'].strip():
        raise ValueError('positive_event must be a nonempty string (label 1)')
    for name in ('current', 'baseline', 'drift_reference'):
        cohort = job.get(name)
        if cohort is None and name != 'current':
            continue
        if not isinstance(cohort, dict) or not isinstance(cohort.get('records'), list):
            raise ValueError(name + ' must contain a records array')
        if any(not isinstance(row, dict) for row in cohort['records']):
            raise ValueError(name + ' records must be objects')
    required = job.get('required_workers')
    if not isinstance(required, list) or any(not isinstance(x, str) or not x for x in required):
        raise ValueError('required_workers must be an array of nonempty worker IDs')
    reports = job.get('worker_reports', [])
    if not isinstance(reports, list) or any(not isinstance(row, dict) for row in reports):
        raise ValueError('worker_reports must be an array of objects')
    limits = job.get('limits')
    if not isinstance(limits, dict):
        raise ValueError('limits must be an object')
    margin = limits.get('max_fpr_increase')
    try:
        valid_margin = type(margin) in (int, float) and math.isfinite(margin) and margin >= 0
    except OverflowError:
        valid_margin = False
    if not valid_margin:
        raise ValueError('max_fpr_increase must be a finite nonnegative number')
    families = limits.get('min_labeled_families')
    if type(families) is not int or families < 0:
        raise ValueError('min_labeled_families must be a nonnegative integer')


def split_issues(job):
    """A family must keep its split even when it appears in another cohort."""
    splits = {}
    for name in ('current', 'baseline', 'drift_reference'):
        cohort = job.get(name)
        if cohort is None:
            continue
        for row in cohort['records']:
            family, split = row.get('family'), row.get('split')
            if isinstance(family, str) and isinstance(split, str):
                splits.setdefault(family, set()).add(split)
    return ['family_crosses_split'] if any(len(values) > 1 for values in splits.values()) else []
