"""Keep adjudication, abstention, family and class denominators visible."""
import math


def ratio(a, b):
    return a / b if b else None


def valid_identity(identity):
    keys = {'dataset_version', 'judge', 'grader_version', 'rubric'}
    return (isinstance(identity, dict) and set(identity) == keys
            and all(isinstance(x, str) and x.strip() for x in identity.values()))


def audit(cohort):
    issues, seen, family_splits = [], set(), {}
    if not valid_identity(cohort.get('identity')):
        issues.append('invalid_evaluation_identity')
    counts = dict(tp=0, tn=0, fp=0, fn=0)
    adjudicated, evaluated, abstained, unknown_human = 0, 0, 0, 0
    labeled_families = set()
    human_pos, human_neg = 0, 0
    for row in cohort['records']:
        example_key = (row.get('id'), row.get('rep', 0))
        if (not isinstance(example_key[0], str) or not example_key[0]
                or type(example_key[1]) is not int or example_key[1] < 0 or example_key in seen):
            issues.append('duplicate_or_invalid_example')
            continue
        seen.add(example_key)
        family, split = row.get('family'), row.get('split')
        if not isinstance(family, str) or not family or split not in ('train', 'validation', 'holdout'):
            issues.append('invalid_family_or_split')
            continue
        family_splits.setdefault(family, set()).add(split)
        if 'human' not in row or 'decision' not in row:
            issues.append('missing_label')
            continue
        human, decision = row['human'], row['decision']
        if human is not None and (type(human) is not int or human not in (0, 1)):
            issues.append('invalid_human_label')
            continue
        if decision is not None and (type(decision) is not int or decision not in (0, 1)):
            issues.append('invalid_judge_decision')
            continue
        if decision is None:
            abstained += 1
        if human is None:
            unknown_human += 1
            continue
        adjudicated += 1
        labeled_families.add(family)
        human_pos += human == 1
        human_neg += human == 0
        if decision is None:
            continue
        evaluated += 1
        cell = 'tp' if human and decision else 'fn' if human else 'fp' if decision else 'tn'
        counts[cell] += 1
    if any(len(splits) > 1 for splits in family_splits.values()):
        issues.append('family_crosses_split')
    pos, neg = counts['tp'] + counts['fn'], counts['tn'] + counts['fp']
    result = {'confusion': counts, 'fpr': ratio(counts['fp'], neg), 'fnr': ratio(counts['fn'], pos),
              'precision': ratio(counts['tp'], counts['tp'] + counts['fp']), 'recall': ratio(counts['tp'], pos),
              'denominators': {'adjudicated': adjudicated, 'human_positive': human_pos, 'human_negative': human_neg,
                               'evaluated': evaluated, 'evaluated_positive': pos, 'evaluated_negative': neg,
                               'abstained': abstained, 'unknown_human': unknown_human},
              'judgment_coverage': ratio(evaluated, len(cohort['records']))}
    result['unmeasured'] = [name for name in ('fpr', 'fnr', 'precision', 'recall') if result[name] is None]
    return result, len(labeled_families), issues


def workers(required, reports):
    by_id, issues = {}, []
    expected = list(dict.fromkeys(required))
    if len(expected) != len(required):
        issues.append('duplicate_required_worker')
    for row in reports:
        key = row.get('id')
        if not isinstance(key, str) or not key:
            issues.append('invalid_worker')
            continue
        if key in by_id:
            issues.append('duplicate_worker')
            continue
        by_id[key] = row
    if set(by_id) - set(required):
        issues.append('unexpected_worker')
    uncovered = [key for key in expected if by_id.get(key, {}).get('status') != 'succeeded']
    return {'expected': len(expected), 'completed': len(expected) - len(uncovered), 'uncovered': uncovered,
            'status': 'unmeasured' if not expected else 'incomplete' if uncovered else 'complete'}, issues


def scenario(calibration, prevalence):
    def probability(value):
        return type(value) in (int, float) and 0 <= value <= 1 and math.isfinite(value)

    if not probability(prevalence):
        return {'status': 'unmeasured', 'value': None}
    tpr, fpr = calibration['recall'], calibration['fpr']
    if not probability(tpr) or not probability(fpr):
        return {'status': 'unmeasured', 'value': None}
    value = ratio(tpr * prevalence, tpr * prevalence + fpr * (1 - prevalence))
    return {'status': 'scenario' if value is not None else 'unmeasured', 'value': value}
