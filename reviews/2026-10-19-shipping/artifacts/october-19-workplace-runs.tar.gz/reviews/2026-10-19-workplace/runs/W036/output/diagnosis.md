# Support judge incident repair

The original saved-example CLI returned `ready_for_review`, treated the abstaining clean ticket as TN, counted security's unknown report as succeeded, and substituted sample precision for deployment scenario precision. The original public suite failed two of three tests.

Changes in `repo/judgecheck/`:

- `calibration.py`: preserve null human/decision observations, compute class-specific rates only from evaluated labels, expose undefined metrics, count distinct adjudicated families, reject duplicate case/rep keys and family split leakage, require explicit and unique worker success, and apply Bayes' rule with the negative-event prevalence term.
- `comparison.py`: validate both cohorts, require exact paired populations and fixed dataset/rubric identity, report partial comparisons without losing total pairs, and enforce fixed judge/grader/rubric for drift. Compare exact count ratios to decimal drift margins to avoid floating-point alerts at equality.
- `__main__.py`: validate input structure and limits, emit JSON errors with exit 2 for malformed inputs, preserve semantic holds with exit 0, and gate readiness on measured classes and complete evidence.

Verification actually executed:

- `cd repo && python3 -m unittest discover -s tests -v`: all 3 existing public tests passed without modifying tests.
- `python3 output/test_integration.py`: all 10 integration test groups passed, making 51 separate invocations of the documented CLI. Fixtures and full packets are retained in `output/fixtures/` and `output/integration-results.json`.
- A copy of only `judgecheck/` and `examples/` ran with Python site packages disabled (`python3 -S -m judgecheck --input examples/review.json`) from `output/standalone/`. It produced the identical saved-example packet, confirming independence from skills and installed helpers.

The repaired incident packet is `output/review.json`: hold, TP=2/TN=1/FP=1/FN=1, evaluated=5, abstained=1, coverage=5/6, security uncovered, FPR=0.5, scenario precision=0.0013328890369876708 at supplied prevalence 0.001. Scenario precision remains a hypothetical base-rate calculation, not observed deployment performance. No services or models were invoked. No deployment claim is made.
