"""Produce a review packet, never a deployment approval."""
import argparse
import json
import math
from pathlib import Path
from .calibration import audit, scenario, workers
from .comparison import paired, drift


def validate_job(job):
    """Reject malformed containers/limits before calculating a review packet.

    Evidence defects (labels, identities, duplicates, coverage) are semantic
    holds reported by the audit, rather than CLI failures.
    """
    if not isinstance(job, dict):
        raise ValueError('input must be a JSON object')
    if not isinstance(job.get('positive_event'), str) or not job['positive_event'].strip():
        raise ValueError('positive_event must declare the event represented by label 1')
    for key in ('current', 'required_workers', 'limits'):
        if key not in job:
            raise ValueError('missing required field: ' + key)
    limits = job['limits']
    if not isinstance(limits, dict):
        raise ValueError('limits must be an object')
    margin = limits.get('max_fpr_increase')
    minimum = limits.get('min_labeled_families')
    if type(margin) not in (int, float) or not math.isfinite(margin) or margin < 0:
        raise ValueError('max_fpr_increase must be a finite nonnegative number')
    if type(minimum) is not int or minimum < 0:
        raise ValueError('min_labeled_families must be a nonnegative integer')


def build(job):
    validate_job(job)
    current = job['current']
    calibration, families, issues = audit(current)
    worker_state, worker_issues = workers(job['required_workers'], job.get('worker_reports', []))
    pair_state, pair_issues = paired(job.get('baseline'), current)
    drift_state, drift_issues = drift(job.get('drift_reference'), current, job['limits']['max_fpr_increase'])
    issues.extend(worker_issues + pair_issues + drift_issues)
    ready = (not issues and calibration['fpr'] is not None and calibration['fnr'] is not None
             and calibration['judgment_coverage'] == 1
             and families >= job['limits']['min_labeled_families'] and worker_state['status'] == 'complete'
             and (job.get('baseline') is None or pair_state['status'] == 'complete')
             and (job.get('drift_reference') is None or drift_state['status'] == 'within_margin'))
    return {'status': 'ready_for_review' if ready else 'hold', 'calibration': calibration,
            'family_count': families, 'workers': worker_state, 'paired': pair_state, 'drift': drift_state,
            'deployment_precision': scenario(calibration, job.get('deployment_prevalence')),
            'integrity': {'status': 'invalid' if issues else 'verified', 'issues': sorted(set(issues))},
            'limits': 'Descriptive family-labelled evidence; repetitions and related examples are not independent population samples. Scenario precision is not observed deployment traffic. Review readiness is not deployment approval.'}


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--input', required=True, type=Path)
    a = p.parse_args()
    try:
        packet = build(json.loads(a.input.read_text(encoding='utf-8')))
        print(json.dumps(packet, allow_nan=False))
        return 0
    except (OSError, ValueError, KeyError, TypeError, OverflowError) as exc:
        print(json.dumps({'error': str(exc)}))
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
