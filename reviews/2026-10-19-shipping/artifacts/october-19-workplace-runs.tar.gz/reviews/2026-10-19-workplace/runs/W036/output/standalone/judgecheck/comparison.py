"""Pair judge versions on fixed examples; monitor a fixed judge across cohorts."""
from fractions import Fraction
from .calibration import audit


def paired(previous, current):
    if previous is None:
        return {'status': 'unmeasured'}, []
    _, _, issues = audit(previous)
    _, _, current_issues = audit(current)
    issues.extend(current_issues)
    # Do not index malformed populations, even when their labels look comparable.
    if issues:
        return {'status': 'invalid', 'pairs': len(current['records']), 'evaluated_pairs': 0}, issues
    for key in ('dataset_version', 'rubric'):
        if previous['identity'][key] != current['identity'][key]:
            issues.append('paired_identity_mismatch')
    def index(cohort):
        return {(row['id'], row.get('rep', 0)): row for row in cohort['records']}
    a, b = index(previous), index(current)
    if set(a) != set(b) or any(
            any(a[k][field] != b[k][field] for field in ('human', 'family', 'split'))
            for k in a.keys() & b.keys()):
        issues.append('paired_population_mismatch')
    if issues:
        return {'status': 'invalid', 'pairs': len(b), 'evaluated_pairs': 0}, issues
    comparable = [k for k in a if a[k]['human'] is not None
                  and a[k]['decision'] is not None and b[k]['decision'] is not None]
    improved = sum(a[k]['decision'] != a[k]['human'] and b[k]['decision'] == b[k]['human'] for k in comparable)
    regressed = sum(a[k]['decision'] == a[k]['human'] and b[k]['decision'] != b[k]['human'] for k in comparable)
    return {'status': 'complete' if len(comparable) == len(a) and a else 'partial', 'pairs': len(a),
            'evaluated_pairs': len(comparable), 'improved': improved, 'regressed': regressed,
            'agreement_delta': (improved - regressed) / len(comparable) if comparable else None}, []


def drift(previous, current, margin):
    if previous is None:
        return {'status': 'unmeasured', 'fpr_delta': None}, []
    old, _, issues = audit(previous)
    new, _, current_issues = audit(current)
    issues.extend(current_issues)
    # Dataset versions may change; the measuring instrument must stay fixed.
    if not issues:
        for key in ('judge', 'grader_version', 'rubric'):
            if previous['identity'][key] != current['identity'][key]:
                issues.append('drift_judge_mismatch')
    if issues:
        return {'status': 'invalid', 'fpr_delta': None}, issues
    if old['fpr'] is None or new['fpr'] is None:
        return {'status': 'unmeasured', 'fpr_delta': None, 'margin': margin}, []
    # Compare exact count ratios to the declared decimal margin. Subtracting
    # floats (e.g. 0.4 - 0.1) can incorrectly alert at an equal margin of 0.3.
    delta = (Fraction(new['confusion']['fp'], new['denominators']['evaluated_negative'])
             - Fraction(old['confusion']['fp'], old['denominators']['evaluated_negative']))
    return {'status': 'alert' if delta > Fraction(str(margin)) else 'within_margin',
            'fpr_delta': float(delta), 'margin': margin}, []
