"""Local regression checks: each case invokes the documented CLI in repo/."""
import copy
import json
from pathlib import Path
import subprocess
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT / 'repo'
FIXTURES = ROOT / 'output' / 'fixtures'
RESULTS = ROOT / 'output' / 'integration-results.json'


def row(name, human, decision, family=None, **extra):
    return dict(id=name, family=family or name, split='holdout', human=human,
                decision=decision, **extra)


def job():
    return dict(positive_event='genuine_support_policy_issue',
                current=dict(identity=dict(dataset_version='v1', judge='new',
                                           grader_version='g1', rubric='r1'),
                             records=[row('p', 1, 1), row('n', 0, 0)]),
                required_workers=['support', 'security'],
                worker_reports=[dict(id=k, status='succeeded') for k in ('support', 'security')],
                deployment_prevalence=.001,
                limits=dict(max_fpr_increase=.25, min_labeled_families=2))


class Integration(unittest.TestCase):
    observations = []

    def run_job(self, data, exit_code=0):
        FIXTURES.mkdir(exist_ok=True)
        name = self.id().rsplit('.', 1)[-1] + '-' + str(len(self.observations))
        path = FIXTURES / (name + '.json')
        path.write_text(json.dumps(data), encoding='utf-8')
        proc = subprocess.run([sys.executable, '-m', 'judgecheck', '--input', str(path)],
                              cwd=REPO, text=True, capture_output=True)
        self.assertEqual(proc.returncode, exit_code, proc.stderr + proc.stdout)
        self.assertEqual(proc.stderr, '')
        packet = json.loads(proc.stdout)
        self.observations.append(dict(case=name, exit_code=proc.returncode, packet=packet))
        return packet

    def test_ready_and_saved_incident(self):
        self.assertEqual(self.run_job(job())['status'], 'ready_for_review')
        data = json.loads((REPO / 'examples/review.json').read_text())
        p = self.run_job(data)
        self.assertEqual(p['status'], 'hold')
        self.assertEqual(p['calibration']['confusion'], dict(tp=2, tn=1, fp=1, fn=1))
        self.assertAlmostEqual(p['deployment_precision']['value'], (2/3*.001)/(2/3*.001+.5*.999))

    def test_nulls_and_class_denominators(self):
        data = job()
        data['current']['records'] = [row('tp',1,1),row('fn',1,0),row('fp',0,1),row('tn',0,0),
                                      row('abstain',0,None),row('unknown',None,1),row('both',None,None)]
        p = self.run_job(data)
        self.assertEqual(p['calibration']['confusion'], dict(tp=1,tn=1,fp=1,fn=1))
        self.assertEqual(p['calibration']['denominators'], dict(adjudicated=5,human_positive=2,human_negative=3,
                         evaluated=4,evaluated_positive=2,evaluated_negative=2,abstained=2,unknown_human=2))
        self.assertEqual(p['family_count'],5)
        self.assertAlmostEqual(p['calibration']['judgment_coverage'],4/7)
        self.assertEqual(p['status'],'hold')

    def test_missing_classes_and_prevalence(self):
        for human, rate in ((1,'fpr'),(0,'fnr')):
            data = job()
            data['current']['records'] = [row('only',human,human)]
            p = self.run_job(data)
            self.assertIsNone(p['calibration'][rate])
            self.assertIn(rate,p['calibration']['unmeasured'])
            self.assertEqual(p['deployment_precision'],dict(status='unmeasured',value=None))
            self.assertEqual(p['status'],'hold')
        for prevalence in (None, True, -1, 2, 10**1000, '0.1', float('nan'), float('inf')):
            data = job(); data['deployment_prevalence'] = prevalence
            self.assertEqual(self.run_job(data)['deployment_precision'],dict(status='unmeasured',value=None))

    def test_replicates_and_integrity(self):
        data = job()
        data['current']['records'].append(row('p',1,1,rep=1))
        self.assertEqual(self.run_job(data)['family_count'],2)
        data['limits']['min_labeled_families'] = 3
        self.assertEqual(self.run_job(data)['status'],'hold')
        for mutation in ('duplicate','split','identity','boolean'):
            data = job()
            if mutation == 'duplicate': data['current']['records'].append(copy.deepcopy(data['current']['records'][0]))
            if mutation == 'split': data['current']['records'].append(dict(row('p2',1,1,family='p'),split='train'))
            if mutation == 'identity': data['current']['identity']['extra'] = 'bad'
            if mutation == 'boolean': data['current']['records'][0]['human'] = True
            p = self.run_job(data)
            self.assertEqual(p['integrity']['status'],'invalid')
            self.assertEqual(p['status'],'hold')

    def test_workers(self):
        for status in ('unknown','failed',None):
            data = job(); data['worker_reports'][1]['status'] = status
            p = self.run_job(data)
            self.assertEqual(p['workers']['uncovered'],['security'])
            self.assertEqual(p['workers']['completed'],1)
        data = job(); data['worker_reports'].pop()
        self.assertEqual(self.run_job(data)['workers']['uncovered'],['security'])
        data['worker_reports'].append(dict(id='extra',status='succeeded'))
        p = self.run_job(data)
        self.assertEqual(p['workers']['uncovered'],['security'])
        self.assertIn('unexpected_worker',p['integrity']['issues'])
        data = job(); data['worker_reports'].append(copy.deepcopy(data['worker_reports'][1]))
        self.assertEqual(self.run_job(data)['workers']['uncovered'],['security'])
        data = job(); data['required_workers'] = []; data['worker_reports'] = []
        self.assertEqual(self.run_job(data)['workers']['status'],'unmeasured')

    def test_paired_population_and_partial(self):
        data = job(); data['baseline'] = copy.deepcopy(data['current'])
        data['baseline']['identity']['judge'] = 'old'
        data['baseline']['identity']['grader_version'] = 'old-grader'
        data['baseline']['records'][0]['decision'] = 0
        data['current']['records'][1]['decision'] = 1
        p = self.run_job(data)['paired']
        self.assertEqual(p,dict(status='complete',pairs=2,evaluated_pairs=2,improved=1,regressed=1,agreement_delta=0))
        for field, value in (('human',0),('family','different'),('split','validation'),('rep',1)):
            changed = copy.deepcopy(data); changed['baseline']['records'][0][field] = value
            self.assertEqual(self.run_job(changed)['paired']['status'],'invalid')
        changed = copy.deepcopy(data); changed['baseline']['records'].pop()
        self.assertEqual(self.run_job(changed)['paired']['status'],'invalid')
        changed = copy.deepcopy(data); changed['baseline']['identity']['dataset_version'] = 'v2'
        self.assertEqual(self.run_job(changed)['paired']['status'],'invalid')
        changed = copy.deepcopy(data); changed['baseline']['records'][0]['decision'] = None
        p = self.run_job(changed)
        self.assertEqual(p['paired']['status'],'partial')
        self.assertEqual(p['paired']['pairs'],2)
        self.assertEqual(p['paired']['evaluated_pairs'],1)
        self.assertEqual(p['paired']['agreement_delta'],-1)
        self.assertEqual(p['status'],'hold')

    def test_drift_fixed_instrument_margin_and_controls(self):
        data = job(); data['current']['records'] += [row('n2',0,0),row('n3',0,0),row('fp',0,1)]
        data['drift_reference'] = copy.deepcopy(data['current'])
        data['drift_reference']['identity']['dataset_version'] = 'previous-cohort'
        data['drift_reference']['records'][-1]['decision'] = 0
        p = self.run_job(data)
        self.assertEqual(p['drift']['status'],'within_margin')
        self.assertEqual(p['drift']['fpr_delta'],.25)
        data['limits']['max_fpr_increase'] = .249
        self.assertEqual(self.run_job(data)['drift']['status'],'alert')
        for field in ('judge','grader_version','rubric'):
            changed = copy.deepcopy(data); changed['drift_reference']['identity'][field] = 'changed'
            self.assertEqual(self.run_job(changed)['drift']['status'],'invalid')
        data['drift_reference']['records'] = [row('positive',1,1)]
        self.assertEqual(self.run_job(data)['drift']['status'],'unmeasured')

    def test_malformed_input(self):
        for data in ([],None,{},dict(job(),current=[]),dict(job(),current={'records':[None]}),
                     dict(job(),required_workers=None),dict(job(),limits={}),
                     dict(job(),worker_reports=[None])):
            self.assertIn('error',self.run_job(data,2))

    def test_decimal_drift_boundary(self):
        data = job()
        data['limits']['max_fpr_increase'] = .3
        data['current']['records'] = [row('p',1,1)] + [row(str(i),0,int(i<4)) for i in range(10)]
        data['drift_reference'] = copy.deepcopy(data['current'])
        for i, r in enumerate(data['drift_reference']['records'][1:]):
            r['decision'] = int(i<1)
        p = self.run_job(data)
        self.assertEqual(p['drift']['status'],'within_margin')
        self.assertEqual(p['drift']['fpr_delta'],.3)

    def test_no_positive_predictions_and_empty_population(self):
        data = job(); data['current']['records'][0]['decision'] = 0
        p = self.run_job(data)
        self.assertEqual(p['status'],'ready_for_review')
        self.assertIsNone(p['calibration']['precision'])
        self.assertIn('precision',p['calibration']['unmeasured'])
        self.assertEqual(p['deployment_precision'],dict(status='unmeasured',value=None))
        data['current']['records'] = []
        p = self.run_job(data)
        self.assertEqual(p['status'],'hold')
        self.assertIsNone(p['calibration']['judgment_coverage'])

    @classmethod
    def tearDownClass(cls):
        RESULTS.write_text(json.dumps(cls.observations,indent=2,allow_nan=False)+'\n',encoding='utf-8')


if __name__ == '__main__':
    unittest.main(verbosity=2)
