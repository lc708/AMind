import copy
from .projection import project
def replay(capture):
    client,items=project(capture)
    # Operations retains the complete heterogeneous protocol, including future types.
    return {'client':client,'archive':{'events':copy.deepcopy(capture['events']),
                                     'output_items':copy.deepcopy(items)}}
