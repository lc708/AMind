"""Offline incident regressions through the supported CLI; all fixtures stay here.

Run from repo/: python3 -m unittest discover -s ../output -p 'test_gateway*.py' -v
"""
import copy
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from html.parser import HTMLParser

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / 'repo'


def message(text, agent='/root', phase='final_answer'):
    item = {'type': 'message', 'content': [{'type': 'output_text', 'text': text}]}
    if agent is not None:
        item['agent'] = {'agent_name': agent}
    if phase is not None:
        item['phase'] = phase
    return item


def terminal(items, status='completed', **fields):
    return {'type': 'response.' + status,
            'response': dict(status=status, output=items, **fields)}


def added(index, item, **fields):
    return dict(type='response.output_item.added', output_index=index, item=item, **fields)


def delta(text, index=None, agent=None):
    event = {'type': 'response.output_text.delta', 'delta': text}
    if index is not None:
        event['output_index'] = index
    if agent is not None:
        event['agent'] = {'agent_name': agent}
    return event


class ArticleParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.tags = []
        self.text = []

    def handle_starttag(self, tag, attrs):
        self.tags.append(tag)

    def handle_data(self, data):
        self.text.append(data)


class GatewayRegressionTests(unittest.TestCase):
    def invoke(self, capture, error=False, previous=None):
        with tempfile.TemporaryDirectory(dir=ROOT, prefix='gateway-fixture-') as directory:
            source = Path(directory) / 'capture.json'
            destination = Path(directory) / 'view.json'
            source.write_text(json.dumps(capture), encoding='utf-8')
            if previous is not None:
                destination.write_text(previous, encoding='utf-8')
            env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', TMPDIR=directory)
            process = subprocess.run(
                [sys.executable, '-m', 'gateway', '--capture', str(source),
                 '--out', str(destination)], cwd=REPO, env=env,
                text=True, capture_output=True, timeout=10)
            if error:
                self.assertEqual(process.returncode, 2, process.stdout + process.stderr)
                self.assertIn('error', json.loads(process.stdout))
                if previous is None:
                    self.assertFalse(destination.exists())
                else:
                    self.assertEqual(destination.read_text(), previous)
                self.assertEqual(sorted(p.name for p in Path(directory).iterdir()),
                                 ['capture.json'] + (['view.json'] if previous is not None else []))
                return
            self.assertEqual(process.returncode, 0, process.stdout + process.stderr)
            result = json.loads(destination.read_text())
            self.assertEqual(result['archive']['events'], capture['events'])
            self.assertEqual(set(result['client']),
                             {'status', 'display_text', 'final_text', 'answer_complete', 'html'})
            return result

    def run_events(self, events, mode='multi_agent', **kwargs):
        return self.invoke({'mode': mode, 'events': events}, **kwargs)

    def test_saved_incident(self):
        capture = json.loads((REPO / 'traces/incident.json').read_text())
        result = self.invoke(capture)
        client = result['client']
        self.assertEqual(client['display_text'], 'Checking your request.')
        self.assertEqual(client['final_text'], '')
        self.assertFalse(client['answer_complete'])
        self.assertNotIn('Internal draft', json.dumps(client))
        self.assertEqual(result['archive']['output_items'], capture['events'][-1]['response']['output'])
        self.assertEqual(result['archive']['summary']['item_count'], 3)

    def test_root_answer_and_worker_deltas_are_separate(self):
        child = message('worker secret', '/root/search')
        root = message('Visible final')
        events = [added(0, child), delta('worker secret', 0), added(1, root),
                  delta('Visible ', 1), delta('final', 1), terminal([child, root])]
        client = self.run_events(events)['client']
        self.assertEqual(client['display_text'], 'Visible final')
        self.assertEqual(client['final_text'], 'Visible final')
        self.assertTrue(client['answer_complete'])

    def test_direct_delta_attribution_without_index(self):
        client = self.run_events([delta('secret', agent='/root/worker'),
                                  delta('Progress', agent='/root')])['client']
        self.assertEqual(client['display_text'], 'Progress')
        self.assertEqual(client['status'], 'disconnected')
        self.assertFalse(client['answer_complete'])

    def test_unattributed_multi_text_is_never_guessed(self):
        client = self.run_events([delta('unowned', 0), added(0, message('safe')),
                                  terminal([message('safe')])])['client']
        self.assertEqual(client['display_text'], '')
        self.assertEqual(client['final_text'], 'safe')
        self.assertNotIn('unowned', json.dumps(client))

    def test_unattributed_final_stays_in_archive(self):
        item = message('private', None)
        result = self.run_events([terminal([item])])
        self.assertEqual(result['archive']['output_items'], [item])
        self.assertNotIn('private', json.dumps(result['client']))
        self.assertFalse(result['client']['answer_complete'])

    def test_multi_requires_explicit_final_phase(self):
        for phase in [None, 'commentary', 'future_phase']:
            with self.subTest(phase=phase):
                client = self.run_events([terminal([message('progress', phase=phase)])])['client']
                self.assertEqual(client['final_text'], '')
                self.assertFalse(client['answer_complete'])

    def test_commentary_does_not_join_final(self):
        client = self.run_events([terminal([message('progress', phase='commentary'),
                                            message('answer')])])['client']
        self.assertEqual(client['final_text'], 'answer')
        self.assertEqual(client['html'], '<article>answer</article>')

    def test_legacy_default_mode_and_phase(self):
        item = message('Order received.', agent=None, phase=None)
        client = self.invoke({'events': [terminal([item])]})['client']
        self.assertEqual(client['final_text'], 'Order received.')
        self.assertTrue(client['answer_complete'])

    def test_legacy_commentary_is_not_final(self):
        client = self.run_events([terminal([message('progress', None, 'commentary')])],
                                 mode='single')['client']
        self.assertEqual(client['final_text'], '')
        self.assertFalse(client['answer_complete'])

    def test_all_terminal_outcomes(self):
        for status in ['completed', 'failed', 'incomplete', 'cancelled']:
            with self.subTest(status=status):
                client = self.run_events([terminal([message('partial')], status)])['client']
                self.assertEqual(client['status'], status)
                self.assertEqual(client['answer_complete'], status == 'completed')

    def test_disconnected_and_error_keep_partial_output(self):
        item = message('Partial', phase='commentary')
        for ending, status in [([], 'disconnected'), ([{'type': 'error', 'message': 'lost'}], 'stream_error')]:
            with self.subTest(status=status):
                result = self.run_events([added(0, item), delta('Partial', 0)] + ending)
                self.assertEqual(result['client']['status'], status)
                self.assertFalse(result['client']['answer_complete'])
                self.assertEqual(result['archive']['output_items'], [item])

    def test_pending_developer_calls_block_badge_including_child(self):
        for agent in ['/root', '/root/worker']:
            with self.subTest(agent=agent):
                call = {'type': 'function_call', 'call_id': 'call-418', 'name': 'never_execute',
                        'arguments': '{malformed}', 'agent': {'agent_name': agent}}
                result = self.run_events([terminal([message('Answer'), call])])
                self.assertEqual(result['client']['final_text'], 'Answer')
                self.assertFalse(result['client']['answer_complete'])
                self.assertEqual(result['archive']['output_items'][1], call)

    def test_hosted_unknown_items_are_retained_and_never_dispatched(self):
        items = [message('Answer')] + [
            {'type': kind, 'opaque': {'bytes': [0, 1], 'text': '<script>internal</script>'},
             'name': 'do_not_execute', 'arguments': 'not JSON'}
            for kind in ['multi_agent_call', 'multi_agent_call_output', 'agent_message', 'future_hosted_item']]
        result = self.run_events([terminal(items)])
        self.assertEqual(result['archive']['output_items'], items)
        self.assertEqual(result['archive']['summary']['item_count'], len(items))
        self.assertTrue(result['client']['answer_complete'])
        self.assertNotIn('internal', json.dumps(result['client']))

    def test_html_escapes_final_and_partial_text(self):
        text = '<img src=x onerror="alert(1)"> & \'quoted\''
        for events in [[terminal([message(text)])], [delta(text, agent='/root')]]:
            with self.subTest(events=events):
                client = self.run_events(events)['client']
                parser = ArticleParser()
                parser.feed(client['html'])
                self.assertEqual(parser.tags, ['article'])
                self.assertEqual(''.join(parser.text), text)

    def test_terminal_errors_do_not_publish_or_replace(self):
        cases = [
            [{'type': 'response.completed', 'response': {'status': 'failed', 'output': []}}],
            [{'type': 'response.completed'}],
            [terminal([message('x')], error={'message': 'bad'})],
            [terminal([message('x')], incomplete_details={'reason': 'budget'})],
            [terminal([]), terminal([])],
            [terminal([]), delta('late', agent='/root')],
            [{'type': 'error', 'message': 'stream lost'}, terminal([message('x')])],
            [{'type': 'response.cancelled', 'response': {'status': 'completed', 'output': []}}],
        ]
        for events in cases:
            for previous in [None, 'previous artifact must survive']:
                with self.subTest(events=events, previous=previous):
                    self.run_events(events, error=True, previous=previous)

    def test_conflicting_attribution_is_capture_error(self):
        child = message('secret', '/root/worker')
        cases = [
            [added(0, child, agent={'agent_name': '/root'})],
            [added(0, child), delta('secret', 0, '/root')],
            [added(0, child), added(0, message('x'))],
            [added(0, child), terminal([message('x')])],
            [delta('x', 0, '/root'), terminal([child])],
        ]
        for events in cases:
            with self.subTest(events=events):
                self.run_events(events, error=True, previous='unchanged')

    def test_item_identity_conflicts_are_capture_errors(self):
        item = dict(message('x'), id='item-418')
        cases = [[added(0, item, item_id='another-item')],
                 [added(0, item), dict(delta('x', 0), item_id='another-item')],
                 [added(0, item), terminal([dict(message('x'), id='another-item')])]]
        for events in cases:
            with self.subTest(events=events):
                self.run_events(events, error=True, previous='unchanged')

    def test_single_mode_does_not_promote_attributed_workers(self):
        child = message('secret', '/root/worker')
        result = self.run_events([added(0, child), delta('secret', 0),
                                  terminal([message('secret', None, None)])], mode='single')
        self.assertNotIn('secret', json.dumps(result['client']))
        self.assertFalse(result['client']['answer_complete'])

    def test_malformed_payloads_are_cli_errors(self):
        captures = [None, [], {'events': {}}, {'mode': 'unknown', 'events': []},
                    {'events': [None]}, {'events': [{'type': 1}]},
                    {'events': [terminal([None])]},
                    {'events': [terminal([{'type': 'message', 'content': {}}])]},
                    {'events': [terminal([message(42, None)])]},
                    {'events': [dict(delta('x'), output_index=[])]},
                    {'events': [dict(delta('x'), agent='root')]},
                    {'events': [dict(delta('x'), delta=None)]}]
        for capture in captures:
            with self.subTest(capture=capture):
                self.invoke(copy.deepcopy(capture), error=True)


if __name__ == '__main__':
    unittest.main()
