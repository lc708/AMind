from html import escape

def render(text):
    return '<article>'+escape(text, quote=True)+'</article>'
