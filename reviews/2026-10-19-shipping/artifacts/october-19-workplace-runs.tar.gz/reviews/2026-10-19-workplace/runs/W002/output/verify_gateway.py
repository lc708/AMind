"""Repeatable local-only verification. Run: python3 ../output/verify_gateway.py."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

OUTPUT = Path(__file__).resolve().parent
REPO = OUTPUT.parent / 'repo'
ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', TMPDIR=str(OUTPUT))


def run(args, cwd=REPO):
    process = subprocess.run([sys.executable] + args, cwd=cwd, env=ENV,
                             capture_output=True, text=True, timeout=60)
    if process.returncode:
        raise RuntimeError(process.stdout + process.stderr)
    return process.stdout + process.stderr


def main():
    public = run(['-m', 'unittest', 'discover', '-s', 'tests', '-v'])
    regression = run(['-m', 'unittest', 'discover', '-s', str(OUTPUT),
                      '-p', 'test_gateway*.py', '-v'])
    (OUTPUT / 'test-results.txt').write_text(public + '\n' + regression)
    for trace in ['incident', 'legacy']:
        run(['-m', 'gateway', '--capture', 'traces/' + trace + '.json',
             '--out', str(OUTPUT / (trace + '-fixed.json'))])
    fixed = json.loads((OUTPUT / 'incident-fixed.json').read_text())
    assert fixed['client']['final_text'] == ''
    assert fixed['client']['answer_complete'] is False
    assert 'Internal draft' not in json.dumps(fixed['client'])
    # Copy only the application. The subprocess cannot import the skill checkout.
    with tempfile.TemporaryDirectory(dir=OUTPUT, prefix='standalone-') as directory:
        isolated = Path(directory) / 'repo'
        shutil.copytree(REPO, isolated, ignore=shutil.ignore_patterns('__pycache__'))
        run(['-I', '-c',
             'import runpy,sys; sys.path.insert(0, "."); '
             'sys.argv=["gateway", "--capture", "traces/legacy.json", '
             '"--out", "standalone.json"]; runpy.run_module("gateway", run_name="__main__")'],
            cwd=isolated)
        standalone = json.loads((isolated / 'standalone.json').read_text())
        assert standalone['client']['final_text'] == 'Order received.'
        assert standalone['client']['answer_complete'] is True
        (OUTPUT / 'standalone-result.json').write_text(json.dumps(standalone, indent=2))
    report = {'public_tests': 'passed (3)', 'regression_tests': 'passed (19)',
              'entry_point': 'python3 -m gateway', 'isolated_application': 'passed',
              'incident_client': fixed['client'], 'network_calls': 0, 'model_calls': 0}
    (OUTPUT / 'verification.json').write_text(json.dumps(report, ensure_ascii=False, indent=2))
    print(json.dumps(report, ensure_ascii=False))


if __name__ == '__main__':
    main()
