# Incident 418: response gateway repair

## Cause and reproduction

The replay gateway combined every output-text delta, regardless of worker owner.
Its final-answer pass checked phase but not owner, so a child `final_answer`
became the customer's answer. A completed transport then supplied a completed
badge despite root commentary being the only customer progress. The archive's
type allowlist discarded hosted items, and rendering inserted captured text
directly into HTML.

From `repo/`, reproduce the saved capture through the unchanged public CLI:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 -m gateway --capture traces/incident.json --out ../output/incident-fixed.json
```

Before the patch, `display_text` was `Internal draftChecking your request.`,
`final_text` was `Internal draft`, `answer_complete` was true, and the archive
lost the `agent_message` item. The retained pre-patch result is
`../output/baseline-incident.json`.

After the patch, display is `Checking your request.`, final text is empty,
and `answer_complete` is false. Transport status remains `completed`; that field
describes transport, while the badge must use `answer_complete`. All three
terminal output items and the original events remain in the operations archive.

## Changes

- `gateway/projection.py` resolves each delta's explicit owner or previously
  observed output-index owner. Multi-agent text without attribution stays in the
  archive; later attribution never retroactively publishes it. Only explicit
  root `final_answer` items contribute multi-agent final text. Single-agent
  messages without a phase or owner retain legacy final-answer behavior.
- Completed, failed, incomplete and cancelled events must match response status.
  Completed responses containing errors/incomplete details, completion after a
  stream error, repeated terminals, trailing events, conflicting owners and
  conflicting item identities raise capture errors. The CLI returns exit 2 and
  JSON `{error: ...}` before publishing; an existing output file survives.
- A missing terminal remains disconnected or stream_error. Any developer
  `function_call`, including a worker call, prevents answer completion. Hosted
  items never invoke tools. Commentary remains progress and cannot become final.
- `gateway/replay.py` retains complete output arrays, including unknown items;
  disconnected streams also retain observed item snapshots. Original snapshots
  remain in archive events. Archive summaries count all retained item types.
- `gateway/render.py` escapes visible text inside the article element.
  `gateway/validation.py` also validates direct callers' capture envelopes.

The implementation follows the assigned AMind Engineering response recipes and
the `response_contract.py` offline reference. Gateway code is implemented locally
using Python's standard library; no skill files, provider SDK, absolute paths,
credentials or model changes are required at runtime.

## Verification

From `repo/`, run all checks with fixtures and temporary files confined to this
workspace:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 ../output/verify_gateway.py
```

The unchanged public suite passes 3 tests. The separate regression suite in
`../output/test_gateway_regressions.py` passes 19 tests, with subcases covering
root/worker separation, explicit and missing attribution, phase handling, legacy
callers, all four terminals, disconnect/error, pending developer calls, opaque
hosted items, HTML escaping, malformed captures, owner/identity conflicts and
atomic preservation of existing artifacts on rejection. Tests invoke the actual
`python3 -m gateway` CLI rather than a replacement adapter.

`../output/test-results.txt` contains the run log; `verification.json`,
`incident-fixed.json`, `legacy-fixed.json` and `standalone-result.json` contain
the results. The verifier also copies only the application into a local temporary
directory and invokes it with isolated Python import settings, confirming that
the application runs without the skill checkout.

The assigned offline `response_contract.py` helper independently agrees with
both saved captures' status, display, final-text and completion projections;
the comparison is retained in `../output/response-contract-diagnostic.json`.

## Limits

Verification uses saved traffic and synthetic local fixtures only; it does not
establish live provider compatibility or customer-task quality. The gateway
replays and validates captures; it never executes or resolves developer tools,
and treats function calls in the terminal output as pending handoffs. Unknown
items remain opaque archival data. A complete badge establishes the documented
root-answer protocol conditions, not whether the answer solves a support issue.
The full archive deliberately contains internal data and must remain operations
only; browser integrations must continue to publish only `client`.
