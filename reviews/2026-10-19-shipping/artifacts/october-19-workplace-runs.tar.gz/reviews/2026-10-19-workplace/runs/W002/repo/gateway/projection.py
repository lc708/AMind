"""Customer projection guided by AMind Engineering's response/stream contracts.

This local implementation has no dependency on a skill, SDK, or hosted service.
"""
from .render import render

TERMINALS = {
    'response.completed': 'completed',
    'response.failed': 'failed',
    'response.incomplete': 'incomplete',
    'response.cancelled': 'cancelled',
}


def owner(value):
    agent = value.get('agent')
    if agent is None:
        return None
    if not isinstance(agent, dict):
        raise ValueError('agent attribution must be an object')
    name = agent.get('agent_name')
    if name is not None and (not isinstance(name, str) or not name):
        raise ValueError('agent name must be a nonempty string')
    return name


def item_text(item):
    if item.get('type') != 'message':
        return ''
    contents = item.get('content', [])
    if not isinstance(contents, list):
        raise ValueError('message content must be an array')
    text = []
    for content in contents:
        if not isinstance(content, dict):
            raise ValueError('message content item must be an object')
        if content.get('type') == 'output_text':
            value = content.get('text', '')
            if not isinstance(value, str):
                raise ValueError('output text must be a string')
            text.append(value)
    return ''.join(text)


def project(capture):
    multi = capture.get('mode', 'single') == 'multi_agent'
    owners = {}
    identities = {}
    streamed_items = {}
    unindexed_items = []
    display = []
    terminal = None
    status = 'disconnected'
    stream_error = False

    def associate(index, name, identity=None):
        if index is None:
            return
        if type(index) is not int or index < 0:
            raise ValueError('output_index must be a nonnegative integer')
        if name is not None:
            if index in owners and owners[index] != name:
                raise ValueError('output index changed agent attribution')
            owners[index] = name
        if identity is not None:
            if not isinstance(identity, str) or not identity:
                raise ValueError('item identity must be a nonempty string')
            if index in identities and identities[index] != identity:
                raise ValueError('output index changed item identity')
            identities[index] = identity

    def visible(name):
        return name == '/root' or (not multi and name is None)

    for event in capture['events']:
        if terminal is not None:
            raise ValueError('event after terminal outcome')
        kind = event['type']
        index = event.get('output_index')
        event_owner = owner(event)
        item = event.get('item')
        if item is not None and not isinstance(item, dict):
            raise ValueError('output item must be an object')
        item_owner = owner(item) if item is not None else None
        if event_owner is not None and item_owner is not None and event_owner != item_owner:
            raise ValueError('event and item disagree on agent attribution')
        name = event_owner or item_owner
        item_id = (item or {}).get('id')
        event_item_id = event.get('item_id')
        if item_id is not None and event_item_id is not None and item_id != event_item_id:
            raise ValueError('event and item disagree on item identity')
        associate(index, name, item_id if item_id is not None else event_item_id)
        name = name or owners.get(index)

        if kind in ('response.output_item.added', 'response.output_item.done'):
            if item is None:
                raise ValueError('output item event requires an item')
            item_text(item)  # Validate even hidden message content.
            if index is None:
                unindexed_items.append(item)
            else:
                streamed_items[index] = item
        elif kind == 'response.output_text.delta':
            delta = event.get('delta', '')
            if not isinstance(delta, str):
                raise ValueError('text delta must be a string')
            # Resolve now; a later item must not grant visibility retroactively.
            if visible(name):
                display.append(delta)
        elif kind in TERMINALS:
            terminal = event.get('response')
            status = TERMINALS[kind]
            if not isinstance(terminal, dict) or terminal.get('status') != status:
                raise ValueError('terminal event/status mismatch')
            if status == 'completed' and (
                stream_error or terminal.get('error') is not None
                or terminal.get('incomplete_details') is not None
            ):
                raise ValueError('completed response contains error or incomplete details')
        elif kind == 'error':
            status = 'stream_error'
            stream_error = True

    items = terminal.get('output', []) if terminal is not None else (
        [streamed_items[index] for index in sorted(streamed_items)] + unindexed_items
    )
    if not isinstance(items, list):
        raise ValueError('response output must be an array')
    final = []
    terminal_display = []
    pending_function = False
    for index, item in enumerate(items):
        if not isinstance(item, dict):
            raise ValueError('output item must be an object')
        name = owner(item)
        if terminal is not None:
            associate(index, name, item.get('id'))
            if not multi and name is None:
                # Missing terminal attribution cannot reclassify a known worker
                # as a healthy legacy single-agent message.
                name = owners.get(index)
        text = item_text(item)
        pending_function = pending_function or item.get('type') == 'function_call'
        # Final items need their own explicit attribution in multi-agent mode.
        if not visible(name) or item.get('type') != 'message':
            continue
        terminal_display.append(text)
        phase = item.get('phase')
        if phase == 'final_answer' or (not multi and phase is None):
            final.append(text)

    final_text = ''.join(final)
    display_text = ''.join(display)
    return {
        'status': status,
        'display_text': display_text,
        'final_text': final_text,
        'answer_complete': status == 'completed' and bool(final_text) and not pending_function,
        'html': render(final_text or display_text or ''.join(terminal_display)),
    }, items
