"""Offline contract checks: every review is obtained through the documented CLI."""
from copy import deepcopy
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT / 'repo'
ARTIFACTS = ROOT / 'output' / 'integration'
ARTIFACTS.mkdir(exist_ok=True)
RUNS = []


def row(i, human, decision, family=None, rep=0):
    return dict(id=str(i), rep=rep, family=family or 'family-' + str(i),
                split='holdout', human=human, decision=decision)


def job():
    return dict(positive_event='genuine_support_policy_issue', current=dict(
        identity=dict(dataset_version='data-1', judge='current', grader_version='g1', rubric='r1'),
        records=[row('tp', 1, 1), row('tn', 0, 0), row('fp', 0, 1), row('fn', 1, 0)]),
        required_workers=['support', 'security'], worker_reports=[
            dict(id='support', status='succeeded'), dict(id='security', status='succeeded')],
        deployment_prevalence=0.001, limits=dict(max_fpr_increase=0.03, min_labeled_families=2))


class Integration(unittest.TestCase):
    def run_job(self, data, code=0):
        name = f'{self._testMethodName}-{len(RUNS):03d}'
        path = ARTIFACTS / (name + '.input.json')
        path.write_text(json.dumps(data), encoding='utf-8')
        proc = subprocess.run([sys.executable, '-m', 'judgecheck', '--input', str(path)],
                              cwd=REPO, capture_output=True, text=True, timeout=10)
        RUNS.append(dict(name=name, code=proc.returncode))
        self.assertEqual(proc.returncode, code, proc.stderr + proc.stdout)
        self.assertEqual(proc.stderr, '')
        result = json.loads(proc.stdout)
        (ARTIFACTS / (name + '.output.json')).write_text(
            json.dumps(result, indent=2, allow_nan=False), encoding='utf-8')
        return result

    def invalid(self, data, issue):
        result = self.run_job(data)
        self.assertEqual(result['status'], 'hold')
        self.assertEqual(result['integrity']['status'], 'invalid')
        self.assertIn(issue, result['integrity']['issues'])
        return result

    def test_complete_calibration_and_scenario(self):
        result = self.run_job(job())
        self.assertEqual(result['status'], 'ready_for_review')
        c = result['calibration']
        self.assertEqual(c['confusion'], dict(tp=1, tn=1, fp=1, fn=1))
        self.assertEqual([c[k] for k in ('fpr', 'fnr', 'precision', 'recall')], [0.5]*4)
        self.assertEqual(c['denominators'], dict(adjudicated=4, human_positive=2, human_negative=2,
                         evaluated=4, evaluated_positive=2, evaluated_negative=2, abstained=0, unknown_human=0))
        self.assertAlmostEqual(result['deployment_precision']['value'], 0.001)

    def test_unknown_and_abstained_never_confusion(self):
        data = job()
        data['current']['records'] += [row('unknown', None, 1), row('unknown-abstain', None, None), row('abstain', 0, None)]
        result = self.run_job(data)
        c = result['calibration']
        self.assertEqual(c['confusion'], dict(tp=1, tn=1, fp=1, fn=1))
        self.assertEqual(c['denominators']['adjudicated'], 5)
        self.assertEqual(c['denominators']['evaluated'], 4)
        self.assertEqual(c['denominators']['abstained'], 2)
        self.assertEqual(c['denominators']['unknown_human'], 2)
        self.assertEqual(c['judgment_coverage'], 4/7)
        self.assertEqual(result['family_count'], 5)
        self.assertEqual(result['status'], 'hold')

    def test_missing_classes_and_empty(self):
        for rows, missing in [([row('p', 1, 1)], ['fpr']), ([row('n', 0, 0)], ['fnr', 'recall', 'precision']), ([], ['fpr', 'fnr', 'recall', 'precision'])]:
            data = job()
            data['current']['records'] = rows
            result = self.run_job(data)
            for metric in missing:
                self.assertIsNone(result['calibration'][metric])
                self.assertIn(metric, result['calibration']['unmeasured'])
            self.assertEqual(result['status'], 'hold')
            self.assertEqual(result['deployment_precision'], dict(status='unmeasured', value=None))

    def test_no_positive_predictions_preserves_class_evidence(self):
        data = job()
        for record in data['current']['records']:
            record['decision'] = 0
        result = self.run_job(data)
        self.assertIsNone(result['calibration']['precision'])
        self.assertEqual(result['status'], 'ready_for_review')

    def test_families_and_repeats(self):
        data = job()
        data['current']['records'] = [row('same', 1, 1, family='one', rep=i) for i in range(20)] + [row('neg', 0, 0, family='one')]
        result = self.run_job(data)
        self.assertEqual(result['family_count'], 1)
        self.assertEqual(result['status'], 'hold')
        data['current']['records'].append(deepcopy(data['current']['records'][0]))
        self.invalid(data, 'duplicate_or_invalid_example')
        data = job()
        data['current']['records'][1]['family'] = data['current']['records'][0]['family']
        data['current']['records'][1]['split'] = 'train'
        self.invalid(data, 'family_crosses_split')

    def test_pairing_requires_exact_populations(self):
        for field, value in [('id', 'different'), ('rep', 2), ('human', 0), ('family', 'different'), ('split', 'validation')]:
            data = job()
            data['baseline'] = deepcopy(data['current'])
            data['baseline']['records'][0][field] = value
            self.assertEqual(self.invalid(data, 'paired_population_mismatch')['paired']['status'], 'invalid')
        data = job()
        data['baseline'] = deepcopy(data['current'])
        data['baseline']['records'].pop()
        self.invalid(data, 'paired_population_mismatch')
        for field in ('dataset_version', 'rubric'):
            data = job()
            data['baseline'] = deepcopy(data['current'])
            data['baseline']['identity'][field] = 'different'
            self.invalid(data, 'paired_identity_mismatch')

    def test_paired_changes_partial_and_order(self):
        data = job()
        data['baseline'] = deepcopy(data['current'])
        data['baseline']['identity'].update(judge='old', grader_version='old')
        data['baseline']['records'][0]['decision'] = 0
        data['baseline']['records'][2]['decision'] = 0
        data['baseline']['records'][3]['decision'] = 1
        result = self.run_job(data)
        self.assertEqual(result['paired'], dict(status='complete', pairs=4, evaluated_pairs=4, improved=1, regressed=2, agreement_delta=-0.25))
        data['baseline']['records'].reverse()
        self.assertEqual(result, self.run_job(data))
        data['baseline']['records'][0]['decision'] = None
        result = self.run_job(data)
        self.assertEqual(result['paired']['status'], 'partial')
        self.assertEqual(result['paired']['pairs'], 4)
        self.assertEqual(result['paired']['evaluated_pairs'], 3)
        self.assertEqual(result['status'], 'hold')

    def test_drift_identity_margin_and_missing_negatives(self):
        data = job()
        data['drift_reference'] = deepcopy(data['current'])
        data['drift_reference']['identity']['dataset_version'] = 'older-data'
        data['drift_reference']['records'][2]['decision'] = 0
        data['limits']['max_fpr_increase'] = 0.5
        self.assertEqual(self.run_job(data)['drift']['status'], 'within_margin')
        data['limits']['max_fpr_increase'] = 0.499
        result = self.run_job(data)
        self.assertEqual(result['drift']['status'], 'alert')
        self.assertEqual(result['status'], 'hold')
        for field in ('judge', 'grader_version', 'rubric'):
            changed = deepcopy(data)
            changed['drift_reference']['identity'][field] = 'different'
            self.assertEqual(self.invalid(changed, 'drift_judge_mismatch')['drift']['status'], 'invalid')
        data['drift_reference']['records'] = [row('only-positive', 1, 1)]
        result = self.run_job(data)
        self.assertEqual(result['drift']['status'], 'unmeasured')
        self.assertIsNone(result['drift']['fpr_delta'])

    def test_drift_decimal_boundary(self):
        data = job()
        data['current']['records'] = [row(i, 0, int(i < 7)) for i in range(100)] + [row('positive', 1, 1)]
        data['drift_reference'] = deepcopy(data['current'])
        for i, record in enumerate(data['drift_reference']['records'][:100]):
            record['decision'] = int(i < 4)
        result = self.run_job(data)
        self.assertEqual(result['drift']['fpr_delta'], 0.03)
        self.assertEqual(result['drift']['status'], 'within_margin')
        self.assertEqual(result['status'], 'ready_for_review')
        data['limits']['max_fpr_increase'] = 0.029999999
        self.assertEqual(self.run_job(data)['drift']['status'], 'alert')

    def test_workers_cannot_be_substituted(self):
        for status in (None, 'unknown', 'failed', 'success', True):
            data = job()
            data['worker_reports'][1]['status'] = status
            result = self.run_job(data)
            self.assertEqual(result['workers']['completed'], 1)
            self.assertEqual(result['workers']['uncovered'], ['security'])
            self.assertEqual(result['status'], 'hold')
        data['worker_reports'].pop()
        self.assertEqual(self.run_job(data)['workers']['uncovered'], ['security'])
        data['worker_reports'].append(dict(id='unrelated', status='succeeded'))
        self.invalid(data, 'unexpected_worker')
        data = job()
        data['worker_reports'].append(deepcopy(data['worker_reports'][1]))
        self.assertEqual(self.invalid(data, 'duplicate_worker')['workers']['uncovered'], ['security'])
        data = job()
        data['required_workers'] = []
        data['worker_reports'] = []
        result = self.run_job(data)
        self.assertEqual(result['workers']['status'], 'unmeasured')
        self.assertEqual(result['status'], 'hold')

    def test_prevalence_boundaries(self):
        for value in (None, True, '0.1', -0.1, 1.1, float('nan'), float('inf'), 10**400):
            data = job()
            data['deployment_prevalence'] = value
            self.assertEqual(self.run_job(data)['deployment_precision'], dict(status='unmeasured', value=None))
        for value in (0, 1):
            data = job()
            data['deployment_prevalence'] = value
            self.assertEqual(self.run_job(data)['deployment_precision'], dict(status='scenario', value=value))

    def test_invalid_semantics_stay_json_holds(self):
        for field, value, issue in [('human', True, 'invalid_human_label'), ('decision', 0.0, 'invalid_judge_decision'), ('rep', True, 'duplicate_or_invalid_example'), ('id', [], 'duplicate_or_invalid_example'), ('split', {}, 'invalid_family_or_split')]:
            data = job()
            data['current']['records'][0][field] = value
            self.invalid(data, issue)
        for identity in (None, [], {}, dict(dataset_version='x')):
            data = job()
            data['current']['identity'] = identity
            self.invalid(data, 'invalid_evaluation_identity')

    def test_malformed_structure_returns_error(self):
        cases = [None, [], {}, job(), job(), job(), job(), job(), job()]
        cases[3]['current'] = []
        cases[4]['current']['records'] = [None]
        cases[5]['worker_reports'] = [None]
        cases[6]['limits']['max_fpr_increase'] = '0.1'
        cases[7]['limits']['min_labeled_families'] = True
        cases[8]['baseline'] = {}
        for data in cases:
            self.assertIn('error', self.run_job(data, code=2))

    def test_saved_incident(self):
        data = json.loads((REPO / 'examples/review.json').read_text())
        result = self.run_job(data)
        self.assertEqual(result['status'], 'hold')
        self.assertEqual(result['calibration']['confusion'], dict(tp=2, tn=1, fp=1, fn=1))
        self.assertEqual(result['workers']['uncovered'], ['security'])
        self.assertAlmostEqual(result['deployment_precision']['value'], 0.0013328890369876708)

    def test_invalid_json_and_encoding(self):
        for name, content in [('syntax', b'{"current":'), ('encoding', bytes([255, 254]))]:
            path = ARTIFACTS / (name + '.json')
            path.write_bytes(content)
            proc = subprocess.run([sys.executable, '-m', 'judgecheck', '--input', str(path)],
                                  cwd=REPO, capture_output=True, text=True, timeout=10)
            RUNS.append(dict(name=name, code=proc.returncode))
            self.assertEqual(proc.returncode, 2)
            self.assertEqual(proc.stderr, '')
            self.assertIn('error', json.loads(proc.stdout))

    def test_standalone_checkout(self):
        isolated = ROOT / 'output' / 'standalone-repo'
        shutil.copytree(REPO, isolated, dirs_exist_ok=True,
                        ignore=shutil.ignore_patterns('__pycache__', 'output'))
        env = dict(os.environ, PYTHONPATH='', PYTHONNOUSERSITE='1')
        proc = subprocess.run([sys.executable, '-m', 'judgecheck', '--input', 'examples/review.json'],
                              cwd=isolated, env=env, capture_output=True, text=True, timeout=10)
        RUNS.append(dict(name='standalone', code=proc.returncode))
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertEqual(proc.stderr, '')
        expected = self.run_job(json.loads((REPO / 'examples/review.json').read_text()))
        self.assertEqual(json.loads(proc.stdout), expected)


if __name__ == '__main__':
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(Integration)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    (ARTIFACTS / 'summary.json').write_text(json.dumps(dict(
        tests=result.testsRun, failures=len(result.failures), errors=len(result.errors),
        cli_invocations=len(RUNS), runs=RUNS), indent=2))
    sys.exit(not result.wasSuccessful())
