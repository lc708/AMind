# Support judge repair evidence

The public entry point is unchanged: `python3 -m judgecheck --input examples/review.json`.
The application uses only Python's standard library. It has no skill/helper imports,
absolute installation paths, network access or model calls.

## Changes

- Kept unresolved human labels and abstentions out of confusion cells, exposed all
  denominators and null/unmeasured rates, and counted distinct adjudicated families.
- Validated exact evaluation identities, unique ID/rep keys, consistent repeated-case
  metadata, family split isolation, binary label types and JSON container structure.
- Required explicit success from every required worker; missing, failed, unknown or
  duplicate reports cannot supply coverage, and extra reports invalidate integrity.
- Required complete matching paired populations and fixed dataset/rubric identity;
  kept partial comparisons visible and computed changes only over comparable pairs.
- Required a fixed judge/grader/rubric for drift and negative-control evidence;
  compared count ratios exactly at the declared margin to avoid rounding alerts.
- Corrected prevalence scenario precision and preserved unavailable values as null.
- Applied readiness gates separately from integrity and preserved semantic hold/exit 0
  versus malformed or unreadable input/JSON error/exit 2.

## Executed verification

- `cd repo && python3 -m unittest discover -s tests -v`: 3/3 public tests passed.
  Full log: `public-tests.txt`.
- `python3 output/check_integration.py`: 16/16 integration tests passed, with 70 real
  CLI subprocess invocations. Full log: `integration-tests.txt`; machine-readable
  summary and input/output fixtures: `integration/summary.json` and `integration/`.
- Copied the repository into `output/standalone-repo`, cleared PYTHONPATH and disabled
  user site packages, then ran the documented CLI on its local saved example. Its
  packet matched the original repository's packet.

## Incident result

`baseline-review.json` retains the original incorrect ready packet. The repaired
saved example is now hold, with TP=2, TN=1, FP=1, FN=1, 5/6 judgment coverage,
one abstention, and security uncovered. Scenario precision at prevalence 0.001
is 0.0013328890369876708 rather than the original 0.6666666666666666.
The fixture's integrity is verified; its missing judgments and worker evidence are
semantic holds, not fabricated invalidity. These are offline descriptive checks,
not evidence of deployment performance or deployment approval.
