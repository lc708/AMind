"""Validate JSON structure separately from semantic evidence holds."""
import math


def validate_job(job):
    if not isinstance(job, dict):
        raise ValueError('input must be an object')
    if not isinstance(job.get('positive_event'), str) or not job['positive_event'].strip():
        raise ValueError('positive_event must declare the event represented by label 1')
    for name in ('current', 'baseline', 'drift_reference'):
        cohort = job.get(name)
        if name != 'current' and cohort is None:
            continue
        if not isinstance(cohort, dict) or not isinstance(cohort.get('records'), list):
            raise ValueError(f'{name} must be an object with a records array')
        if not all(isinstance(row, dict) for row in cohort['records']):
            raise ValueError(f'{name}.records must contain objects')
    if not isinstance(job.get('required_workers'), list):
        raise ValueError('required_workers must be an array')
    reports = job.get('worker_reports', [])
    if not isinstance(reports, list) or not all(isinstance(row, dict) for row in reports):
        raise ValueError('worker_reports must be an array of objects')
    limits = job.get('limits')
    if not isinstance(limits, dict):
        raise ValueError('limits must be an object')
    margin = limits.get('max_fpr_increase')
    if type(margin) not in (int, float) or (type(margin) is float and not math.isfinite(margin)):
        raise ValueError('max_fpr_increase must be a finite number')
    families = limits.get('min_labeled_families')
    if type(families) is not int or families < 0:
        raise ValueError('min_labeled_families must be a nonnegative integer')
