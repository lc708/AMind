"""Offline behavioral checks through the documented CLI; all fixtures stay here."""
import copy
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import unittest

WORK = Path(__file__).resolve().parent.parent
REPO = WORK / 'repo'
OUT = WORK / 'output'
EXAMPLE = REPO / 'examples' / 'saved-run'
BASE_MANIFEST = json.loads((EXAMPLE / 'manifest.json').read_text())
BASE_RESULTS = [json.loads(x) for x in (EXAMPLE / 'results.jsonl').read_text().splitlines()]
BASE_EVENTS = [json.loads(x) for x in (EXAMPLE / 'attempts.jsonl').read_text().splitlines()]
BASE_RATES = json.loads((REPO / 'examples' / 'rates.json').read_text())
EVIDENCE = []


def complete():
    manifest, results, events, rates = map(copy.deepcopy,
        (BASE_MANIFEST, BASE_RESULTS, BASE_EVENTS, BASE_RATES))
    row = copy.deepcopy(results[0])
    row['case_id'] = row['result_identity']['case_id'] = 'account-recovery'
    results.append(row)
    return manifest, results, events, rates


def call_pair(attempt='retry', **fields):
    start = dict(event='started', attempt_id=attempt, case_id='order-return', rep=0)
    end = dict(start, event='finished', status='failed', **fields)
    return [start, end]


class CLIIntegration(unittest.TestCase):
    def invoke(self, data=None, variant='candidate', expected_code=0, malformed=None):
        data = complete() if data is None else data
        manifest, results, events, rates = data
        folder = OUT / 'fixtures' / f'{self._testMethodName}-{len(EVIDENCE)}'
        folder.mkdir(parents=True, exist_ok=True)
        (folder / 'manifest.json').write_text(json.dumps(manifest))
        for name, rows in [('results', results), ('attempts', events)]:
            (folder / f'{name}.jsonl').write_text(''.join(json.dumps(row) + '\n' for row in rows))
        (folder / 'rates.json').write_text(json.dumps(rates))
        if malformed:
            (folder / malformed[0]).write_text(malformed[1])
        process = subprocess.run([sys.executable, '-m', 'releaseboard', '--bundle', str(folder),
            '--rates', str(folder / 'rates.json'), '--variant', variant], cwd=REPO,
            capture_output=True, text=True)
        self.assertEqual(process.returncode, expected_code, process.stdout + process.stderr)
        self.assertFalse(process.stderr, process.stderr)
        packet = json.loads(process.stdout)
        EVIDENCE.append(dict(test=self._testMethodName, fixture=str(folder.relative_to(WORK)),
                             exit_code=process.returncode, report=packet))
        (folder / 'report.json').write_text(json.dumps(packet, indent=2) + '\n')
        if expected_code == 0:
            self.assertEqual(set(packet), {'release_id', 'variant', 'split', 'planned_observations',
                'scored_observations', 'missing', 'metrics', 'attempts', 'cost', 'coverage',
                'integrity', 'decision'})
        return packet

    def test_clean_release_ready(self):
        p = self.invoke()
        self.assertEqual(p['decision'], 'ready')
        self.assertEqual(p['scored_observations'], 3)
        self.assertEqual(p['coverage']['status'], 'complete')
        self.assertAlmostEqual(p['metrics']['quality']['mean'], 2.6 / 3)

    def test_saved_incident(self):
        p = self.invoke(copy.deepcopy((BASE_MANIFEST, BASE_RESULTS, BASE_EVENTS, BASE_RATES)))
        self.assertEqual(p['decision'], 'hold')
        self.assertEqual(p['planned_observations'], 3)
        self.assertEqual(p['missing'], [{'case_id': 'account-recovery', 'rep': 0}])
        self.assertAlmostEqual(p['cost']['known_usd'], .4)

    def test_missing_and_failed_repetitions(self):
        data = complete()
        data[0]['repetitions'] = 2
        failed = copy.deepcopy(data[1][0])
        failed['rep'] = failed['result_identity']['rep'] = 1
        failed['status'] = 'failed'
        data[1].append(failed)
        p = self.invoke(data)
        self.assertEqual(p['planned_observations'], 6)
        self.assertEqual(p['scored_observations'], 3)
        self.assertEqual(len(p['missing']), 3)
        self.assertEqual(p['decision'], 'hold')

    def test_identity_and_variant(self):
        for field in ('comparison_hash', 'treatment_hash', 'case_id', 'rep'):
            data = complete()
            data[1][0]['result_identity'][field] = 'foreign'
            p = self.invoke(data)
            self.assertIn('result_identity_mismatch', p['integrity']['issues'])
            self.assertEqual(p['scored_observations'], 2)
            self.assertEqual(p['decision'], 'hold')
        p = self.invoke(variant='other')
        self.assertIn('variant_mismatch', p['integrity']['issues'])
        self.assertEqual(p['decision'], 'hold')

    def test_served_scope(self):
        for field in ('provider', 'interface', 'model', 'service_tier', 'region'):
            data = complete()
            data[1][0]['billing_identity'][field] = 'foreign'
            p = self.invoke(data)
            self.assertIn('serving_identity_mismatch', p['integrity']['issues'])
            self.assertEqual(p['decision'], 'hold')

    def test_duplicate_and_unexpected_results(self):
        data = complete()
        data[1].append(copy.deepcopy(data[1][0]))
        p = self.invoke(data)
        self.assertIn('duplicate_result', p['integrity']['issues'])
        self.assertEqual(p['scored_observations'], 2)
        data = complete()
        extra = copy.deepcopy(data[1][0])
        extra['case_id'] = 'unplanned'
        data[1].append(extra)
        p = self.invoke(data)
        self.assertIn('unexpected_result', p['integrity']['issues'])
        self.assertEqual(p['decision'], 'hold')

    def test_invalid_grades_and_quality_gate(self):
        for value in (None, True, '1', float('nan'), float('inf'), -0.1, 1.1):
            data = complete()
            data[1][0]['grade']['quality'] = value
            p = self.invoke(data)
            self.assertEqual(p['scored_observations'], 2)
            self.assertIn('invalid_grade', p['integrity']['issues'])
        data = complete()
        for row in data[1]:
            row['grade']['quality'] = .1
        p = self.invoke(data)
        self.assertEqual(p['decision'], 'hold')
        self.assertEqual(p['integrity']['status'], 'verified')

    def test_no_scores_and_no_stage_contract(self):
        data = complete()
        data[1].clear()
        p = self.invoke(data)
        self.assertIsNone(p['metrics']['quality']['mean'])
        self.assertEqual(p['coverage']['status'], 'incomplete')
        data = complete()
        del data[0]['required_stages']
        p = self.invoke(data)
        self.assertEqual(p['coverage']['status'], 'unmeasured')
        self.assertEqual(p['decision'], 'hold')

    def test_stage_evidence(self):
        mutations = [lambda s: s.pop(), lambda s: s.append(copy.deepcopy(s[0])),
            lambda s: s[0].update(total=2), lambda s: s[0].update(coverage=.99),
            lambda s: s[0].update(uncovered=['worker']),
            lambda s: s[0].update(counts={'succeeded': 2, 'failed': 1}),
            lambda s: s[0].update(counts={'succeeded': 3, 'failed': 1}),
            lambda s: s[0].update(counts={'succeeded': True}),
            lambda s: s[0].update(coverage=True)]
        for mutate in mutations:
            data = complete()
            mutate(data[1][0]['coverage']['stages'])
            p = self.invoke(data)
            self.assertEqual(p['coverage']['status'], 'incomplete')
            self.assertEqual(p['decision'], 'hold')

    def test_failed_retry_spend_and_explicit_zero(self):
        data = complete()
        data[2].extend(call_pair(cost_usd=.15))
        p = self.invoke(data)
        self.assertAlmostEqual(p['cost']['total_usd'], .55)
        self.assertEqual(p['attempts']['failed'], 1)
        data = complete()
        data[2].extend(call_pair(cost_usd=0))
        p = self.invoke(data)
        self.assertEqual(p['cost']['unknown_attempts'], 0)
        self.assertAlmostEqual(p['cost']['total_usd'], .4)

    def test_unknown_costs_and_interrupted_judge(self):
        for value in (None, True, -1, '0.1', float('nan'), float('inf')):
            data = complete()
            data[2].extend(call_pair(cost_usd=value))
            p = self.invoke(data)
            self.assertIsNone(p['cost']['total_usd'])
            self.assertEqual(p['cost']['unknown_attempts'], 1)
            self.assertAlmostEqual(p['cost']['known_usd'], .4)
        data = complete()
        data[2].append(call_pair()[0])
        p = self.invoke(data)
        self.assertEqual(p['attempts']['interrupted'], 1)
        self.assertEqual(p['cost']['unknown_attempts'], 1)
        self.assertIsNone(p['cost']['total_usd'])

    def test_duplicate_ledger_and_unmatched_finish(self):
        for index, issue in [(0, 'duplicate_started'), (1, 'duplicate_finished')]:
            data = complete()
            data[2].append(copy.deepcopy(data[2][index]))
            p = self.invoke(data)
            self.assertIn(issue, p['integrity']['issues'])
            self.assertEqual(p['attempts']['started'], 2)
            self.assertEqual(p['attempts']['finished'], 2)
            self.assertAlmostEqual(p['cost']['known_usd'], .4)
        data = complete()
        data[2].extend(call_pair(cost_usd=.1)[1:])
        p = self.invoke(data)
        self.assertIn('unmatched_finished', p['integrity']['issues'])
        self.assertAlmostEqual(p['cost']['known_usd'], .5)

    def test_mismatched_attempt_stays_unknown_once(self):
        data = complete()
        pair = call_pair()
        pair[1]['case_id'] = 'invoice-correction'
        data[2].extend(pair)
        p = self.invoke(data)
        self.assertIn('unmatched_finished', p['integrity']['issues'])
        self.assertEqual(p['attempts']['interrupted'], 1)
        self.assertEqual(p['cost']['unknown_attempts'], 1)
        self.assertIsNone(p['cost']['total_usd'])

    def test_multiple_metrics_are_joint_gates(self):
        data = complete()
        data[0]['metrics'].append(dict(id='safety', min=0, max=1, min_mean=1))
        for row in data[1]:
            row['grade']['safety'] = 1
        self.assertEqual(self.invoke(data)['decision'], 'ready')
        data[1][0]['grade']['safety'] = 0
        self.assertEqual(self.invoke(data)['decision'], 'hold')
        del data[1][0]['grade']['safety']
        p = self.invoke(data)
        self.assertIn('invalid_grade', p['integrity']['issues'])
        self.assertEqual(p['metrics']['quality']['scored'], 2)
        self.assertEqual(p['metrics']['safety']['scored'], 2)

    def estimated(self, interface='responses', usage=None, **extra):
        data = complete()
        scope = dict(data[0]['expected_billing_identity'], interface=interface)
        fields = dict(billing_identity=scope, all_billable_usage_included=True,
                      usage=usage or {'input_tokens': 1000, 'cached_input_tokens': 200,
                                      'output_tokens': 100, 'reasoning_tokens': 30})
        fields.update(extra)
        data[2].extend(call_pair(**fields))
        return data

    def test_exact_scope_estimation_and_token_subsets(self):
        p = self.invoke(self.estimated())
        self.assertAlmostEqual(p['cost']['total_usd'], .4102)
        p = self.invoke(self.estimated('decisions', {'input_tokens': 1000}))
        self.assertAlmostEqual(p['cost']['total_usd'], .402)
        for field in ('provider', 'interface', 'model', 'service_tier', 'region'):
            data = self.estimated()
            data[2][-1]['billing_identity'][field] = 'unpriced'
            p = self.invoke(data)
            self.assertEqual(p['cost']['unknown_attempts'], 1)
            self.assertIsNone(p['cost']['total_usd'])

    def test_partial_estimate_retains_subtotal(self):
        p = self.invoke(self.estimated(all_billable_usage_included=False))
        self.assertAlmostEqual(p['cost']['known_usd'], .4102)
        self.assertEqual(p['cost']['unknown_attempts'], 1)
        self.assertIsNone(p['cost']['total_usd'])
        self.assertEqual(p['decision'], 'hold')

    def test_unsupported_or_invalid_usage(self):
        usage_cases = [dict(input_tokens=True), dict(input_tokens=1.5),
            dict(input_tokens=1000, cached_input_tokens=1001, output_tokens=1),
            dict(input_tokens=1000, cached_input_tokens=0, output_tokens=1, reasoning_tokens=2),
            dict(input_tokens=1000, cached_input_tokens=0, output_tokens=1, native={'audio': 2})]
        for usage in usage_cases:
            p = self.invoke(self.estimated(usage=usage))
            self.assertIsNone(p['cost']['total_usd'])
        for usage in ({'input_tokens': 1.5}, {'input_tokens': True},
                      {'input_tokens': 100, 'output_tokens': 1}):
            p = self.invoke(self.estimated('decisions', usage))
            self.assertIsNone(p['cost']['total_usd'])

    def test_ambiguous_rate_unknown(self):
        data = self.estimated()
        data[3]['rates'].append(copy.deepcopy(data[3]['rates'][0]))
        p = self.invoke(data)
        self.assertIsNone(p['cost']['total_usd'])

    def test_malformed_inputs_are_json_exit_two(self):
        for filename, content in [('manifest.json', '{'), ('manifest.json', '[]'),
                ('results.jsonl', '[]\n'), ('attempts.jsonl', 'null\n'),
                ('rates.json', '[]'), ('rates.json', '{"rates":[null]}')]:
            p = self.invoke(expected_code=2, malformed=(filename, content))
            self.assertIn('error', p)
        data = complete()
        data[0]['repetitions'] = True
        self.assertIn('error', self.invoke(data, expected_code=2))

    def test_product_runs_from_relocated_source(self):
        target = OUT / 'standalone'
        shutil.copytree(REPO / 'releaseboard', target / 'releaseboard', dirs_exist_ok=True,
                        ignore=shutil.ignore_patterns('__pycache__'))
        shutil.copytree(REPO / 'examples', target / 'examples', dirs_exist_ok=True)
        env = dict(os.environ)
        env.pop('PYTHONPATH', None)
        p = subprocess.run([sys.executable, '-m', 'releaseboard', '--bundle', 'examples/saved-run',
            '--rates', 'examples/rates.json', '--variant', 'candidate'], cwd=target,
            env=env, capture_output=True, text=True)
        self.assertEqual(p.returncode, 0, p.stdout + p.stderr)
        self.assertEqual(json.loads(p.stdout)['decision'], 'hold')


if __name__ == '__main__':
    try:
        unittest.main(verbosity=2)
    finally:
        (OUT / 'integration-results.json').write_text(json.dumps(EVIDENCE, indent=2) + '\n')
