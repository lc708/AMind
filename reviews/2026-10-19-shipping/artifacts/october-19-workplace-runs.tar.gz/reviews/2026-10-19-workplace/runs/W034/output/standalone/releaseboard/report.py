"""Join the declared population to unique, compatible scoring evidence."""
from collections import Counter
import math
from .accounting import account, exact_scope


def finite(value):
    try:
        return type(value) in (int, float) and math.isfinite(value)
    except OverflowError:
        return False


def nonempty(value):
    return isinstance(value, str) and bool(value.strip())


def validate_manifest(manifest):
    if not isinstance(manifest, dict):
        raise ValueError('manifest must be an object')
    for field in ('release_id', 'variant', 'split', 'comparison_hash', 'treatment_hash'):
        if not nonempty(manifest.get(field)):
            raise ValueError('invalid manifest ' + field)
    ids, reps = manifest.get('case_ids'), manifest.get('repetitions')
    if (not isinstance(ids, list) or any(not nonempty(cid) for cid in ids)
            or len(set(ids)) != len(ids) or type(reps) is not int or reps < 1):
        raise ValueError('invalid planned population')
    metrics = manifest.get('metrics')
    if not isinstance(metrics, list) or not metrics:
        raise ValueError('metrics must be a nonempty array')
    names = set()
    for metric in metrics:
        if (not isinstance(metric, dict) or not nonempty(metric.get('id'))
                or metric['id'] in names
                or any(not finite(metric.get(k)) for k in ('min', 'max', 'min_mean'))
                or metric['min'] > metric['max']):
            raise ValueError('invalid metric contract')
        names.add(metric['id'])
    if ('expected_billing_identity' in manifest
            and not exact_scope(manifest['expected_billing_identity'])):
        raise ValueError('invalid expected_billing_identity')
    stages = manifest.get('required_stages', {})
    if (not isinstance(stages, dict)
            or any(not nonempty(k) or type(v) is not int or v < 0 for k, v in stages.items())):
        raise ValueError('invalid required_stages')


def stage_ok(report, contract):
    if not contract:
        return None
    if not isinstance(report, dict) or not isinstance(report.get('stages'), list):
        return False
    stages, by_id = report['stages'], {}
    for stage in stages:
        if (not isinstance(stage, dict) or not nonempty(stage.get('id'))
                or stage['id'] in by_id):
            return False
        by_id[stage['id']] = stage
    if set(by_id) != set(contract):
        return False
    for key, total in contract.items():
        row = by_id[key]
        counts = row.get('counts')
        if (type(row.get('total')) is not int or row['total'] != total
                or not finite(row.get('coverage')) or row['coverage'] != 1
                or row.get('uncovered') != [] or not isinstance(counts, dict)
                or counts.get('succeeded') != total
                or any(type(v) is not int or v < 0 for v in counts.values())
                or any(v != 0 for k, v in counts.items() if k != 'succeeded')):
            return False
    return True


def result_key(row):
    if not isinstance(row, dict):
        raise ValueError('results must be objects')
    if not nonempty(row.get('case_id')) or type(row.get('rep')) is not int:
        return None
    return row['case_id'], row['rep']


def build(manifest, results, events, rates, requested_variant):
    validate_manifest(manifest)
    if not isinstance(results, list):
        raise ValueError('results must be an array')
    issues = []
    if requested_variant != manifest['variant']:
        issues.append('variant_mismatch')
    ids, reps = manifest['case_ids'], manifest['repetitions']
    planned = [(cid, rep) for cid in ids for rep in range(reps)]
    population = set(planned)
    keys = [result_key(row) for row in results]
    counts = Counter(key for key in keys if key is not None)
    accepted = {}
    for row, key in zip(results, keys):
        if key not in population:
            issues.append('unexpected_result')
            continue
        if counts[key] != 1:
            issues.append('duplicate_result')
            continue
        identity = {'comparison_hash': manifest['comparison_hash'],
                    'treatment_hash': manifest['treatment_hash'],
                    'case_id': key[0], 'rep': key[1]}
        supplied = row.get('result_identity')
        if (not isinstance(supplied, dict) or supplied != identity
                or type(supplied.get('rep')) is not int):
            issues.append('result_identity_mismatch')
            continue
        pin = manifest.get('expected_billing_identity')
        if pin is not None and (not exact_scope(row.get('billing_identity'))
                                or row['billing_identity'] != pin):
            issues.append('serving_identity_mismatch')
            continue
        if row.get('status') != 'ok':
            continue
        grade = row.get('grade')
        valid = isinstance(grade, dict) and set(grade) == {m['id'] for m in manifest['metrics']}
        if valid:
            valid = all(finite(grade[m['id']]) and m['min'] <= grade[m['id']] <= m['max']
                        for m in manifest['metrics'])
        if not valid:
            issues.append('invalid_grade')
            continue
        accepted[key] = row
    missing = [{'case_id': cid, 'rep': rep} for cid, rep in planned if (cid, rep) not in accepted]
    metrics = {}
    for metric in manifest['metrics']:
        values = [row['grade'][metric['id']] for row in accepted.values()]
        # Divide first so a finite mean cannot overflow its intermediate sum.
        mean = math.fsum(v / len(values) for v in values) if values else None
        metrics[metric['id']] = {'mean': mean, 'scored': len(values)}
    attempts, cost, ledger_issues = account(events, rates)
    issues.extend(ledger_issues)
    contract = manifest.get('required_stages', {})
    coverage = 'unmeasured'
    if contract:
        coverage = ('complete' if not missing and accepted
                    and all(stage_ok(row.get('coverage'), contract) for row in accepted.values())
                    else 'incomplete')
    quality = all(metrics[m['id']]['mean'] is not None
                  and metrics[m['id']]['mean'] >= m['min_mean'] for m in manifest['metrics'])
    ready = (not issues and not missing and quality and cost['total_usd'] is not None
             and coverage == 'complete')
    return {'release_id': manifest['release_id'], 'variant': requested_variant, 'split': manifest['split'],
            'planned_observations': len(planned), 'scored_observations': len(accepted), 'missing': missing,
            'metrics': metrics, 'attempts': attempts, 'cost': cost, 'coverage': {'status': coverage},
            'integrity': {'status': 'invalid' if issues else 'verified', 'issues': sorted(set(issues))},
            'decision': 'ready' if ready else 'hold'}
