# Releaseboard: repair the rollout evidence dashboard

The support automation team uses this standard-library CLI to turn saved evaluation exports into a release review packet. After a provider outage, the dashboard remained green even though a planned case never produced a score. Finance found failed retries outside the displayed spend, and a copied export from another treatment reached the review page. Fix the existing pipeline across its modules. Keep the CLI stable and leave a maintainable implementation.

Run `python3 -m releaseboard --bundle examples/saved-run --rates examples/rates.json --variant candidate`. It prints one JSON object. Run public tests with `python3 -m unittest discover -s tests -v`. No network, model API or AMind helper dependency is required.

## Saved export contract

`manifest.json` declares `release_id`, `variant`, `split`, unique `case_ids`, positive integer `repetitions`, `comparison_hash`, `treatment_hash`, `metrics` (each `id,min,max,min_mean`), optional exact `expected_billing_identity`, and optional `required_stages:{stage_id:total}`. All case/repetition pairs are planned, including failed or absent results. A result has `case_id,rep,status,grade,result_identity`, optional `billing_identity` and `coverage`. Its identity must exactly bind the manifest comparison/treatment plus its case and repetition. Only unique, planned, identity-compatible successful rows with all finite declared grades count toward scores. Wrong treatment, served scope, duplicate results or unexpected rows invalidate integrity and hold the release.

`attempts.jsonl` is an append-only sequence of `started` and `finished` events with a nonempty string `attempt_id`, `case_id` and integer `rep`. Finished calls also have `status` and optional `cost_usd`, `billing_identity`, normalized `usage`, and `all_billable_usage_included`. Account every finished application/judge/retry, including failed calls, once. Started without finished remains interrupted with unknown spend. An explicit finite nonnegative cost, including zero, is known; null, booleans, negative and nonnumeric costs are unknown. Duplicate starts/finishes or an unmatched finished event invalidate integrity; do not inflate cost or counts.

If reported cost is absent, the dated rate card can estimate only exact `provider/interface/model/service_tier/region` scopes. `mode:text` uses integer `input_tokens,cached_input_tokens,output_tokens` and optional `reasoning_tokens`; input includes cache and output includes reasoning. The `input_per_million,cached_per_million,output_per_million` rates price those subsets once. `mode:input_only` accepts only `input_tokens` at `input_per_million`. Unsupported/native usage or absent scope/rate remains unknown. An estimate is complete only with `all_billable_usage_included:true`. These are synthetic exercise prices, not live provider rates.

Required coverage is reported per accepted result as `coverage.stages:[{id,total,counts,coverage,uncovered}]`. Require the manifest's full stage population, unique stage IDs, `succeeded==total`, no other nonzero counts, coverage 1 and empty uncovered. No declared stage contract means **unmeasured**, never complete.

## JSON review packet

Preserve the existing keys: `release_id,variant,split,planned_observations,scored_observations,missing,metrics,attempts,cost,coverage,integrity,decision`. `missing` lists unscored `{case_id,rep}` pairs. Each metric has `mean` (null if none) and `scored`. Attempts expose `started,finished,interrupted,failed`. Cost exposes `known_usd,total_usd,unknown_attempts`; any unknown attempt makes total null while retaining the known subtotal. Coverage status is `complete`, `incomplete` or `unmeasured`. Integrity is `{status:verified|invalid,issues:[...]}`. Ready requires verified integrity, complete planned scores/stages, all `min_mean` gates and known complete cost; otherwise `decision:hold`. Unknown evidence must survive reporting. Semantic holds still exit 0 with a review packet; unreadable/malformed input exits 2 with JSON error.

Implementation notes: `report.py` validates the manifest, joins against its ordered
case/repetition population, and applies identity, grade and coverage gates.
Duplicated result pairs are excluded from scoring entirely. `accounting.py`
reconciles ledger events in append order, retains the first event of each kind
per attempt, and flags duplicates rather than counting them again. A finish must
match an earlier start's case and repetition to resolve it. Every finished call
contributes spend, including failed retries and judges. A priceable estimate
without the completeness flag contributes to `known_usd` but also leaves that
attempt unknown and `total_usd` null. Pricing never falls back to a model-only
match. The CLI uses only Python's standard library and saved local files.
