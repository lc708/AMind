"""Reconcile the append-only call ledger without losing unknown spend."""
import math

SCOPE = {'provider', 'interface', 'model', 'service_tier', 'region'}


def number(value):
    try:
        return type(value) in (int, float) and math.isfinite(value) and value >= 0
    except OverflowError:
        return False


def exact_scope(value):
    return (isinstance(value, dict) and set(value) == SCOPE
            and all(isinstance(v, str) and v.strip() for v in value.values()))


def price(event, rates):
    """Return the priced subtotal, or None; explicit zero is authoritative.

    Completeness of estimated spend is checked separately by ``account``.
    """
    if 'cost_usd' in event:
        value = event['cost_usd']
        return value if number(value) else None
    scope = event.get('billing_identity')
    if not exact_scope(scope):
        return None
    matches = [r for r in rates.get('rates', [])
               if exact_scope(r.get('identity')) and r['identity'] == scope]
    # Ambiguous rates are not a license to choose the cheapest/first entry.
    if len(matches) != 1:
        return None
    rate, usage = matches[0], event.get('usage')
    if not isinstance(usage, dict):
        return None
    if rate.get('mode') == 'input_only':
        if (set(usage) != {'input_tokens'} or type(usage['input_tokens']) is not int
                or usage['input_tokens'] < 0 or not number(rate.get('input_per_million'))):
            return None
        try:
            cost = usage['input_tokens'] * rate['input_per_million'] / 1e6
        except OverflowError:
            return None
        return cost if number(cost) else None
    if rate.get('mode') != 'text':
        return None
    required = {'input_tokens', 'cached_input_tokens', 'output_tokens'}
    if not required <= set(usage) <= required | {'reasoning_tokens'}:
        return None
    if any(type(usage[k]) is not int or usage[k] < 0 for k in required):
        return None
    incoming, cached, outgoing = (usage[k] for k in
                                 ('input_tokens', 'cached_input_tokens', 'output_tokens'))
    reasoning = usage.get('reasoning_tokens', 0)
    if type(reasoning) is not int or not 0 <= reasoning <= outgoing or cached > incoming:
        return None
    if not all(number(rate.get(k)) for k in
               ('input_per_million', 'cached_per_million', 'output_per_million')):
        return None
    try:
        cost = ((incoming - cached) * rate['input_per_million']
                + cached * rate['cached_per_million']
                + outgoing * rate['output_per_million']) / 1e6
    except OverflowError:
        return None
    return cost if number(cost) else None


def account(events, rates):
    if not isinstance(events, list):
        raise ValueError('attempts must be a sequence of objects')
    if (not isinstance(rates, dict) or not isinstance(rates.get('rates'), list)
            or any(not isinstance(r, dict) for r in rates['rates'])):
        raise ValueError('rate card must contain a rates array of objects')
    starts, finishes, matched, issues = {}, {}, set(), []
    for event in events:
        if not isinstance(event, dict):
            raise ValueError('attempt events must be objects')
        kind, key = event.get('event'), event.get('attempt_id')
        if (kind not in ('started', 'finished') or not isinstance(key, str) or not key.strip()
                or not isinstance(event.get('case_id'), str) or not event['case_id'].strip()
                or type(event.get('rep')) is not int or event['rep'] < 0
                or (kind == 'finished' and (not isinstance(event.get('status'), str)
                                           or not event['status'].strip()))):
            issues.append('invalid_attempt_event')
            continue
        bucket = starts if kind == 'started' else finishes
        if key in bucket:
            issues.append('duplicate_' + kind)
            continue
        if kind == 'finished':
            prior = starts.get(key)
            if prior is None or any(prior[k] != event[k] for k in ('case_id', 'rep')):
                issues.append('unmatched_finished')
            else:
                matched.add(key)
        bucket[key] = event
    unresolved = set(starts) - matched
    interrupted = len(unresolved)
    known, unknown = 0.0, set(unresolved)
    for attempt_id, event in finishes.items():
        cost = price(event, rates)
        if cost is None:
            unknown.add(attempt_id)
        else:
            subtotal = known + cost
            if number(subtotal):
                known = subtotal
            else:
                unknown.add(attempt_id)
                continue
            if 'cost_usd' not in event and event.get('all_billable_usage_included') is not True:
                unknown.add(attempt_id)
    attempts = {'started': len(starts), 'finished': len(finishes),
                'interrupted': interrupted,
                'failed': sum(e['status'] != 'ok' for e in finishes.values())}
    costs = {'known_usd': known, 'total_usd': None if unknown else known,
             'unknown_attempts': len(unknown)}
    return attempts, costs, issues
