"""Offline public-CLI regressions. Run from repo; every fixture stays in output/."""
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT / 'repo'


class IntakeRegressions(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=ROOT / 'output')
        self.path = Path(self.temp.name)
        self.db = self.path / 'jobs.sqlite'
        self.receipts = self.path / 'receipts.jsonl'

    def tearDown(self):
        self.temp.cleanup()

    def call(self, op, tenant='acme', job='J1', expected=0, **extra):
        request = self.path / 'request.json'
        request.write_text(json.dumps(dict(op=op, tenant=tenant, job=job, **extra)))
        result = subprocess.run([sys.executable, '-m', 'intake', '--db', str(self.db),
                                 '--request', str(request), '--receipts', str(self.receipts)],
                                cwd=REPO, capture_output=True, text=True)
        self.assertEqual(result.returncode, expected, result.stderr + result.stdout)
        return json.loads(result.stdout) if result.stdout else None

    def submit(self, items=None, budget=8, **scope):
        return self.call('submit', spec={'items': items or [{'id': 'a'}], 'max_attempts': budget}, **scope)

    def effects(self):
        return [json.loads(line) for line in self.receipts.read_text().splitlines()] if self.receipts.exists() else []

    def states(self, report):
        return {(r['stage'], r['item']): r['state'] for r in report['rows']}

    def test_healthy_repeated_work_and_submit_are_noops(self):
        spec = {'items': [{'id': 'a'}, {'id': 'b'}], 'max_attempts': 8}
        self.call('submit', spec=spec)
        result = self.call('work')
        self.assertEqual((result['coverage'], result['status'], result['attempts']), (1, 'completed', 5))
        self.assertEqual(self.call('work'), result)
        self.assertEqual(self.call('submit', spec=spec), result)
        self.assertEqual(len(self.effects()), 5)
        for receipt in self.effects():
            self.assertTrue(receipt['operation_key'])
            self.assertIn('coverage', receipt)
        self.assertEqual(self.effects()[-1]['coverage']['coverage'], 1)

    def test_saved_gap_request_preserves_population_and_skips_review(self):
        request = json.loads((REPO / 'traces/new-job.json').read_text())
        self.call('submit', job=request['job'], spec=request['spec'])
        result = self.call('work', job=request['job'])
        self.assertEqual((result['coverage'], result['status'], result['attempts']), (.5, 'incomplete', 4))
        self.assertEqual(result['covered_ids'], ['invoice-A'])
        self.assertEqual(result['uncovered_ids'], ['invoice-B'])
        self.assertEqual(self.states(result)[('review', 'invoice-B')], 'skipped')
        self.assertEqual(self.effects()[-1]['stage'], 'summary')
        self.assertEqual(self.effects()[-1]['coverage']['coverage'], .5)
        self.call('work', job=request['job'])
        self.assertEqual(len(self.effects()), 4)

    def test_review_failure_is_a_terminal_gap(self):
        self.submit([{'id': 'a', 'payload': {'review': 'fail'}}])
        result = self.call('work')
        self.assertEqual((result['coverage'], result['status']), (0, 'incomplete'))
        self.assertEqual(self.effects()[-1]['coverage']['uncovered_ids'], ['a'])
        self.call('work')
        self.assertEqual(len(self.effects()), 3)

    def test_crash_inspect_never_replays_and_blocks_dependents(self):
        request = json.loads((REPO / 'traces/crash-job.json').read_text())
        self.call('submit', job=request['job'], spec=request['spec'])
        self.call('work', job=request['job'], expected=17)
        initial = self.call('report', job=request['job'])
        self.assertEqual((initial['status'], initial['attempts']), ('unknown', 1))
        for _ in range(2):
            self.assertEqual(self.call('work', job=request['job']), initial)
        self.assertEqual(len(self.effects()), 1)
        self.assertEqual(self.effects()[0]['operation_key'], initial['rows'][0]['operation_key'])
        self.call('reconcile', job=request['job'], stage='inspect', item='delivery-A',
                  state='succeeded', result={'receipt': 'confirmed'}, evidence='local receiver line 1')
        result = self.call('work', job=request['job'])
        self.assertEqual((result['status'], result['attempts']), ('completed', 3))
        self.assertEqual(len(self.effects()), 3)
        with sqlite3.connect(self.db) as db:
            self.assertEqual(db.execute('SELECT evidence FROM reconciliations').fetchone()[0], 'local receiver line 1')

    def test_crash_review_does_not_dispatch_summary_until_reconciled(self):
        self.submit([{'id': 'a', 'payload': {'crash_after_effect': 'review'}}])
        self.call('work', expected=17)
        result = self.call('work')
        self.assertEqual((result['status'], result['attempts'], result['coverage']), ('unknown', 2, 0))
        self.assertEqual(len(self.effects()), 2)
        self.call('reconcile', stage='review', item='a', state='failed', evidence='receiver failure record')
        result = self.call('work')
        self.assertEqual((result['status'], result['attempts']), ('incomplete', 3))
        self.assertEqual(self.effects()[-1]['coverage']['coverage'], 0)

    def test_summary_crash_is_unknown_even_with_full_item_coverage(self):
        self.submit([{'id': 'a', 'payload': {'crash_after_effect': 'summary'}}])
        self.call('work', expected=17)
        report = self.call('work')
        self.assertEqual((report['status'], report['coverage'], report['attempts']), ('unknown', 1, 3))
        self.assertEqual(len(self.effects()), 3)
        self.call('reconcile', stage='summary', item='__all__', state='succeeded', evidence='summary receiver line 3')
        self.assertEqual(self.call('work')['status'], 'completed')
        self.assertEqual(len(self.effects()), 3)

    def test_failed_summary_is_not_completed(self):
        self.submit([{'id': 'a', 'payload': {'crash_after_effect': 'summary'}}])
        self.call('work', expected=17)
        self.call('reconcile', stage='summary', item='__all__', state='failed', evidence='summary rejected externally')
        result = self.call('work')
        self.assertEqual((result['status'], result['coverage']), ('incomplete', 1))
        self.assertEqual(len(self.effects()), 3)

    def test_unknown_item_does_not_block_unrelated_item_work(self):
        self.submit([{'id': 'a', 'payload': {'crash_after_effect': 'inspect'}}, {'id': 'b'}])
        self.call('work', expected=17)
        result = self.call('work')
        self.assertEqual(result['covered_ids'], ['b'])
        self.assertEqual(result['status'], 'unknown')
        self.assertEqual([r['stage'] for r in self.effects()], ['inspect', 'inspect', 'review'])

    def test_cancel_is_durable_resume_preserves_budget(self):
        self.submit(budget=2)
        self.call('cancel')
        self.assertEqual(self.call('work')['status'], 'cancelled')
        self.assertEqual(self.submit(budget=2)['status'], 'cancelled')
        self.assertEqual(self.effects(), [])
        self.call('resume')
        result = self.call('work')
        self.assertEqual((result['attempts'], result['remaining_attempts'], result['status']), (2, 0, 'pending'))
        self.call('cancel'); self.call('resume')
        self.call('work'); self.submit(budget=2)
        self.assertEqual(len(self.effects()), 2)
        self.assertEqual(self.call('report')['attempts'], 2)

    def test_crash_consumes_last_attempt(self):
        self.submit([{'id': 'a', 'payload': {'crash_after_effect': 'inspect'}}], budget=1)
        self.call('work', expected=17)
        self.call('reconcile', stage='inspect', item='a', state='succeeded', evidence='receiver line 1')
        result = self.call('work')
        self.assertEqual((result['attempts'], result['remaining_attempts']), (1, 0))
        self.assertEqual(len(self.effects()), 1)

    def test_tenant_scoping_for_identity_keys_and_reconciliation(self):
        a = self.submit([{'id': 'a', 'payload': {'crash_after_effect': 'inspect'}}])
        b = self.submit(tenant='beta')
        self.assertNotEqual(a['rows'][0]['operation_key'], b['rows'][0]['operation_key'])
        self.call('work', expected=17)
        self.call('reconcile', tenant='beta', stage='inspect', item='a', state='succeeded', evidence='wrong tenant', expected=2)
        self.assertEqual(self.call('report')['status'], 'unknown')
        self.assertEqual(self.call('work', tenant='beta')['status'], 'completed')
        self.call('cancel')
        self.assertFalse(self.call('report', tenant='beta')['cancelled'])
        self.call('report', tenant='missing', expected=2)
        self.call('reconcile', tenant='missing', stage='inspect', item='a', state='failed', evidence='x', expected=2)
        self.assertEqual(len({r['operation_key'] for r in self.effects()}), 4)

    def test_reconciliation_requires_unknown_target_and_nonblank_evidence(self):
        self.submit([{'id': 'a', 'payload': {'crash_after_effect': 'inspect'}}])
        self.call('reconcile', stage='inspect', item='a', state='succeeded', evidence='pending is not unknown', expected=2)
        self.call('work', expected=17)
        before = self.call('report')
        for evidence in (None, '', '  ', 9, {}):
            self.call('reconcile', stage='inspect', item='a', state='succeeded', evidence=evidence, expected=2)
        self.call('reconcile', stage='inspect', item='missing', state='succeeded', evidence='x', expected=2)
        self.call('reconcile', stage='inspect', item='a', state='pending', evidence='x', expected=2)
        self.assertEqual(self.call('report'), before)
        self.call('reconcile', stage='inspect', item='a', state='failed', result={'observed': True}, evidence='receiver evidence')
        settled = self.call('report')
        self.call('reconcile', stage='inspect', item='a', state='succeeded', evidence='overwrite', expected=2)
        self.assertEqual(self.call('report'), settled)
        self.assertEqual(self.call('work')['attempts'], 2)  # skipped review costs no dispatch

    def test_changed_spec_is_rejected_without_reset(self):
        self.submit()
        self.call('cancel')
        before = self.call('report')
        for spec in ({'items': [{'id': 'b'}], 'max_attempts': 8},
                     {'items': [{'id': 'a'}], 'max_attempts': 9},
                     {'items': [{'id': 'a', 'payload': {'inspect': 'fail'}}], 'max_attempts': 8}):
            self.call('submit', spec=spec, expected=2)
        self.assertEqual(self.call('report'), before)

    def test_legacy_running_key_is_preserved(self):
        self.submit()
        with sqlite3.connect(self.db) as db:
            db.execute("UPDATE work SET state='running',operation_key='legacy-key' WHERE stage='inspect'")
            db.execute('UPDATE jobs SET attempts=1')
            db.execute('DROP TABLE reconciliations')
        report = self.call('work')
        self.assertEqual(report['rows'][0]['operation_key'], 'legacy-key')
        self.assertEqual(self.effects(), [])
        self.call('reconcile', stage='inspect', item='a', state='succeeded', evidence='legacy receiver')
        self.assertEqual(self.call('work')['status'], 'completed')
        with sqlite3.connect(self.db) as db:
            self.assertEqual(db.execute('SELECT operation_key FROM reconciliations').fetchone()[0], 'legacy-key')

    def test_receiver_io_failure_is_unknown_and_cli_json_error(self):
        self.submit()
        self.receipts.mkdir()
        self.call('work', expected=2)
        report = self.call('work')
        self.assertEqual((report['status'], report['attempts']), ('unknown', 1))

    def test_invalid_inputs_have_no_effect(self):
        for spec in (None, [], {}, {'items': [{'id': 'a'}, {'id': 'a'}], 'max_attempts': 8},
                     {'items': [{'id': '__all__'}], 'max_attempts': 8},
                     {'items': [{'id': 'a', 'payload': 'bad'}], 'max_attempts': 8},
                     {'items': [{'id': 'a'}], 'max_attempts': True}):
            self.call('submit', spec=spec, expected=2)
        self.assertEqual(self.effects(), [])


if __name__ == '__main__':
    unittest.main(verbosity=2)
