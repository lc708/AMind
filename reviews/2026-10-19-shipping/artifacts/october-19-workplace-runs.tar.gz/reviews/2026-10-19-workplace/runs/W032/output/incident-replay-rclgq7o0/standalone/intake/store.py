"""Durable intake state (SQLite, one local coordinator).

Dispatch/reconciliation ordering follows the Apache-2.0 AMind Engineering
scripts/tool_loop.py reference, adapted to the intake application's schema.
"""
import hashlib
import json
import sqlite3


def packed(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def operation_key(tenant, job, stage, item):
    return hashlib.sha256(packed(['intake-v2', tenant, job, stage, item]).encode()).hexdigest()


class Store:
    def __init__(self, path):
        self.db = sqlite3.connect(str(path), isolation_level=None)
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('CREATE TABLE IF NOT EXISTS jobs(tenant TEXT,job TEXT,spec TEXT,cancelled INTEGER,attempts INTEGER,PRIMARY KEY(tenant,job))')
        self.db.execute('CREATE TABLE IF NOT EXISTS work(tenant TEXT,job TEXT,stage TEXT,item TEXT,state TEXT,result TEXT,operation_key TEXT,PRIMARY KEY(tenant,job,stage,item))')
        self.db.execute('CREATE TABLE IF NOT EXISTS reconciliations(tenant TEXT,job TEXT,stage TEXT,item TEXT,operation_key TEXT,state TEXT,result TEXT,evidence TEXT)')
        # Existing operation keys, including unresolved legacy keys, are immutable.

    def close(self):
        self.db.close()

    def job(self, tenant, job):
        row = self.db.execute('SELECT spec,cancelled,attempts FROM jobs WHERE tenant=? AND job=?', (tenant, job)).fetchone()
        if row is None:
            raise ValueError('job not found for tenant')
        return {'spec': json.loads(row[0]), 'cancelled': bool(row[1]), 'attempts': row[2]}

    def rows(self, tenant, job):
        return [dict(zip(('stage', 'item', 'state', 'result', 'operation_key'), r)) for r in self.db.execute('SELECT stage,item,state,result,operation_key FROM work WHERE tenant=? AND job=? ORDER BY rowid', (tenant, job))]

    def update(self, tenant, job, stage, item, state, result=None):
        self.db.execute('UPDATE work SET state=?,result=? WHERE tenant=? AND job=? AND stage=? AND item=?', (state, packed(result), tenant, job, stage, item))

    def claim(self, tenant, job, stage, item):
        """Commit dispatch and budget before crossing the receiver boundary."""
        self.db.execute('BEGIN IMMEDIATE')
        try:
            entry = self.job(tenant, job)
            claimed = False
            if not entry['cancelled'] and entry['attempts'] < entry['spec']['max_attempts']:
                claimed = self.db.execute("UPDATE work SET state='running',result=NULL WHERE tenant=? AND job=? AND stage=? AND item=? AND state='pending'", (tenant, job, stage, item)).rowcount == 1
                if claimed:
                    self.db.execute('UPDATE jobs SET attempts=attempts+1 WHERE tenant=? AND job=?', (tenant, job))
            self.db.execute('COMMIT')
            return claimed
        except BaseException:
            self.db.execute('ROLLBACK')
            raise

    def reconcile(self, tenant, job, stage, item, state, result, evidence):
        if state not in ('succeeded', 'failed') or not isinstance(evidence, str) or not evidence.strip():
            raise ValueError('external outcome and nonempty evidence required')
        encoded = packed(result)
        self.db.execute('BEGIN IMMEDIATE')
        try:
            row = self.db.execute("SELECT operation_key FROM work WHERE tenant=? AND job=? AND stage=? AND item=? AND state='running'", (tenant, job, stage, item)).fetchone()
            if row is None:
                raise ValueError('exactly one unknown operation required')
            self.update(tenant, job, stage, item, state, result)
            self.db.execute('INSERT INTO reconciliations VALUES(?,?,?,?,?,?,?,?)', (tenant, job, stage, item, row[0], state, encoded, evidence))
            self.db.execute('COMMIT')
        except BaseException:
            self.db.execute('ROLLBACK')
            raise
