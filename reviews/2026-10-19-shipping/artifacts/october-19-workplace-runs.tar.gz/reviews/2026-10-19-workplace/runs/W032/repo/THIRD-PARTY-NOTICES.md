The durable dispatch and evidence-backed reconciliation implementation in
`intake/store.py` adapts the algorithm from AMind Engineering 0.2.1,
`scripts/tool_loop.py` (the locally supplied reference). It was changed to use
intake's tenant/job/stage/item schema, cumulative budgets and cancellation state.
The app uses only Python's standard library; the skill is not a runtime dependency.

The upstream attribution notice and Apache-2.0 license are retained in
`licenses/AMind-NOTICE.txt` and `licenses/AMind-Apache-2.0.txt`.
