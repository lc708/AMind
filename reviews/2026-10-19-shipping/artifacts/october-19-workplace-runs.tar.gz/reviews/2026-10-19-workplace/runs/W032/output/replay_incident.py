"""Retain public-entry-point incident evidence; no imports from intake or skills."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT / 'repo'
OUT = ROOT / 'output'
RUN = Path(tempfile.mkdtemp(prefix='incident-replay-', dir=OUT))
DB = RUN / 'jobs.sqlite'
RECEIPTS = RUN / 'receipts.jsonl'
steps = []
events = []


def event(tenant, job, kind, key=None):
    value = dict(id=f'event-{len(events) + 1}', tenant_id=tenant, task_id=job, kind=kind)
    if key is not None:
        value['idempotency_key'] = key
    events.append(value)


def effects():
    return [json.loads(line) for line in RECEIPTS.read_text().splitlines()] if RECEIPTS.exists() else []


def call(request, expected=0):
    index = len(steps)
    request_file = RUN / f'{index:02d}-request.json'
    request_file.write_text(json.dumps(request, indent=2) + '\n')
    before = len(effects())
    result = subprocess.run([sys.executable, '-m', 'intake', '--db', str(DB),
                             '--request', str(request_file), '--receipts', str(RECEIPTS)],
                            cwd=REPO, capture_output=True, text=True)
    (RUN / f'{index:02d}-stdout.txt').write_text(result.stdout)
    (RUN / f'{index:02d}-stderr.txt').write_text(result.stderr)
    assert result.returncode == expected, (request, result.returncode, result.stderr)
    report = json.loads(result.stdout) if result.stdout else None
    steps.append(dict(request=request, exit_code=result.returncode, report=report))
    tenant, job, op = request['tenant'], request['job'], request['op']
    if op == 'submit':
        event(tenant, job, 'task_started')
    if op == 'work':
        if report is None:
            report = call(dict(op='report', tenant=tenant, job=job))
        rows = {r['operation_key']: r for r in report['rows']}
        for receipt in effects()[before:]:
            key = receipt['operation_key']
            event(tenant, job, 'effect_started', key)
            state = rows[key]['state']
            if state in ('succeeded', 'failed'):
                event(tenant, job, 'effect_' + state, key)
        if report['status'] in ('completed', 'incomplete'):
            event(tenant, job, 'task_completed' if report['status'] == 'completed' else 'task_failed')
    if op == 'reconcile':
        key = next(r['operation_key'] for r in report['rows'] if r['stage'] == request['stage'] and r['item'] == request['item'])
        event(tenant, job, 'effect_reconciled', key)
    return report


# Saved failing-item request: inspect B fails, its review is skipped, summary keeps gap.
gap_request = json.loads((REPO / 'traces/new-job.json').read_text())
call(gap_request)
gap = call(dict(op='work', tenant='acme', job='INC-73'))
assert gap['coverage'] == .5 and gap['status'] == 'incomplete'
assert gap['uncovered_ids'] == ['invoice-B']

# Saved crash request: receiver line exists, local state is unknown, restart cannot replay.
crash_request = json.loads((REPO / 'traces/crash-job.json').read_text())
call(crash_request)
unknown = call(dict(op='work', tenant='acme', job='INC-74'), expected=17)
count_after_crash = len(effects())
restart = call(dict(op='work', tenant='acme', job='INC-74'))
assert restart['status'] == 'unknown' and restart['attempts'] == 1
assert len(effects()) == count_after_crash

# The same job number for another tenant has independent state and receiver keys.
call(dict(op='submit', tenant='beta', job='INC-74',
          spec=dict(items=[dict(id='delivery-A')], max_attempts=8)))
beta = call(dict(op='work', tenant='beta', job='INC-74'))
assert beta['status'] == 'completed'
assert beta['rows'][0]['operation_key'] != restart['rows'][0]['operation_key']

# External evidence comes from the locally observed receiver line, not process exit.
receipt_index = next(i for i, r in enumerate(effects(), 1) if r['tenant'] == 'acme' and r['job'] == 'INC-74')
call(dict(op='reconcile', tenant='acme', job='INC-74', stage='inspect', item='delivery-A',
          state='succeeded', result=dict(receiver_line=receipt_index),
          evidence=f'local receipts.jsonl line {receipt_index}; tenant/job/operation_key matched'))
recovered = call(dict(op='work', tenant='acme', job='INC-74'))
assert recovered['status'] == 'completed' and recovered['attempts'] == 3
keys = [r['operation_key'] for r in effects()]
assert len(keys) == len(set(keys))

(RUN / 'steps.json').write_text(json.dumps(steps, indent=2) + '\n')
(RUN / 'events.jsonl').write_text(''.join(json.dumps(e) + '\n' for e in events))

# Prove runtime independence by running a copied package with no skills alongside it.
standalone = RUN / 'standalone'
standalone.mkdir()
shutil.copytree(REPO / 'intake', standalone / 'intake', ignore=shutil.ignore_patterns('__pycache__'))
request = standalone / 'request.json'
env = dict(os.environ)
env.pop('PYTHONPATH', None)
for op in ('submit', 'work'):
    value = dict(op=op, tenant='isolated', job='smoke')
    if op == 'submit':
        value['spec'] = dict(items=[dict(id='a')], max_attempts=3)
    request.write_text(json.dumps(value))
    result = subprocess.run([sys.executable, '-m', 'intake', '--db', 'jobs.sqlite',
                             '--request', 'request.json', '--receipts', 'receipts.jsonl'],
                            cwd=standalone, env=env, capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
standalone_report = json.loads(result.stdout)
assert standalone_report['status'] == 'completed'
(standalone / 'report.json').write_text(json.dumps(standalone_report, indent=2) + '\n')
summary = dict(fixture_dir=str(RUN.relative_to(ROOT)), gap_coverage=gap['coverage'],
               crash_exit_code=17, crash_attempts=restart['attempts'],
               duplicate_receipts=len(keys) - len(set(keys)), tenant_beta_status=beta['status'],
               recovered_status=recovered['status'], receipts=len(keys),
               standalone_status=standalone_report['status'])
(OUT / 'replay-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
