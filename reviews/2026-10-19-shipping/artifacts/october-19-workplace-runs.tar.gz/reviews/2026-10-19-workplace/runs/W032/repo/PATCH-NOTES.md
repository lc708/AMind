# Incident 73 repair

## Cause and behavior

The receiver ran before the dispatch journal and attempt increment committed. A
process exit after writing a receipt therefore left a pending operation eligible
for another delivery. `work` also reset attempts and cancellation on every run.
The job lookup omitted tenant identity, and receiver keys omitted tenant identity.
Dependency checks used `pass`, so reviews and summary could dispatch despite
failed, pending or unknown inspections. Coverage counted inspection alone.
Reconciliation accepted pending or settled rows and ignored evidence.

The repaired path commits `pending -> running` and the cumulative attempt charge
in one SQLite transaction before calling the receiver. A crash or receiver I/O
error leaves running work as unknown; subsequent workers skip it. Persisted keys
are reused. New keys hash tenant, job, stage and item with an explicit version.
All job access and reconciliation use tenant plus job. Cancel is durable until
explicit resume, which retains the original budget; reporting and identical
submission do not mutate either fact. Changed specifications are rejected.

Review requires that item's successful inspection. A failed inspection leaves a
terminal skipped review with an explanation and no attempt charge. Pending or
unknown dependencies block their review and the aggregate summary; independent
items can still proceed. Failed outcomes are never automatically retried.
Coverage requires both item stages to succeed and always lists the full submitted
population, covered IDs and uncovered IDs. Summary may describe settled gaps but
cannot turn them into coverage. Completion also requires successful summary.
The aggregate receiver honors a selected item's `crash_after_effect: "summary"`
marker, allowing all three stages to be exercised through the CLI.

Reconcile accepts only an existing running operation, a terminal external state
and nonblank string evidence. Its state/result update and evidence journal commit
together, without another attempt or receiver call. Pending and settled targets,
missing tenants, empty evidence and repeated reconciliation are rejected.
Existing CLI flags and JSON result fields remain available; `population_ids` is
additive. Receipt I/O errors return the normal JSON error envelope and exit 2.

## Reproduction and verification

From `repo/`, with Python 3 and no installed dependencies:

```sh
TMPDIR="$PWD/../output" PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests
PYTHONDONTWRITEBYTECODE=1 python3 ../output/test_regressions.py
PYTHONDONTWRITEBYTECODE=1 python3 ../output/replay_incident.py
```

The regression harness calls `python -m intake` in a fresh process for every
request. Existing tests are unchanged. All fixture databases, requests and
receiver files are created under `output/`.

Verified: **3 public tests and 16 additional CLI regressions pass**. Regressions
cover immutable resubmission, healthy replays, inspect and review gaps, crash
recovery at all three stages, summary failure, independent item progress,
exhausted budgets including crashes, durable cancel/resume, tenant isolation,
invalid reconciliation and inputs, legacy key retention and receiver I/O failure.

The saved `traces/new-job.json` replay delivers four receipts, retains invoice-B
as uncovered, and reports coverage 0.5/incomplete. `traces/crash-job.json` exits
17 after its first receipt; another work request leaves attempts at 1 and adds no
receipt. An independent beta tenant with that same job number completes normally.
Matching the original receipt's tenant/job/key supplies reconciliation evidence;
acme then finishes with three total attempts and no repeated operation key.

Recorded evidence: `../output/public-test-results.txt`,
`../output/regression-results.txt`, `../output/replay-summary.json`, and its named
fixture directory containing per-request input/stdout/stderr, SQLite state,
receiver JSONL, `steps.json` and normalized lifecycle events. The assigned skill's
lifecycle auditor checked 26 observed events over three jobs: no findings and no
unresolved effects after reconciliation (`../output/lifecycle-audit.json`). This
is a secondary audit of the CLI replay, not a replacement for execution tests.
A copied application package without skills or a PYTHONPATH override also
completed a healthy job (`standalone/report.json` inside the replay fixture).

## Limits and recovery

This remains a synchronous, single-coordinator local application. There is no
network, model call, distributed worker coordination or provider compatibility
claim. The receiver appends on every invocation; it does not implement remote
idempotency. Durable local suppression prevents blind replay but does not prove
exactly-once delivery. A crash between dispatch commit and actual delivery is
also unknown and consumes an attempt; trusted external evidence is required.
Cancellation stops future dispatch; it cannot undo an effect already dispatched.

Existing databases are opened in place and gain only an additive reconciliation
table. Stored keys are never rewritten, including legacy keys that omitted the
tenant; historical collisions require external investigation. The old worker
could deliver without recording a dispatch. Such historical unjournaled effects
cannot be inferred from a pending row, nor can previously erased attempt history
be reconstructed automatically. Check those against receiver records before
resuming an old incident. The repair guarantees the new dispatch ordering going
forward and safe handling of existing recorded unknown operations.

Implementation provenance and the retained Apache license/notice are documented
in `THIRD-PARTY-NOTICES.md`; no skill code or absolute development path is required
at runtime.
