"""Offline public-CLI regressions. All fixtures remain beneath output/."""
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'repo'
OUTPUT = ROOT / 'output'
FIXTURES = OUTPUT / 'verification-fixtures'
FIXTURES.mkdir(exist_ok=True)
sys.path.insert(0, str(REPO))


class Incident73Tests(unittest.TestCase):
    def setUp(self):
        self.p = Path(tempfile.mkdtemp(prefix=self._testMethodName + '-', dir=FIXTURES))
        self.n = 0

    def call(self, op, tenant='acme', job='J1', rc=0, **extra):
        self.n += 1
        request = {'op': op, 'tenant': tenant, 'job': job, **extra}
        path = self.p / ('request-%02d.json' % self.n)
        path.write_text(json.dumps(request))
        proc = subprocess.run([sys.executable, '-m', 'intake', '--db', str(self.p / 'jobs.sqlite'),
                               '--request', str(path), '--receipts', str(self.p / 'receipts.jsonl')],
                              cwd=REPO, capture_output=True, text=True, timeout=10)
        (self.p / ('response-%02d.json' % self.n)).write_text(json.dumps(
            {'exit': proc.returncode, 'stdout': proc.stdout, 'stderr': proc.stderr}, indent=2))
        self.assertEqual(proc.returncode, rc, proc.stderr + proc.stdout)
        if rc == 17:
            self.assertEqual(proc.stdout, '')
            return None
        answer = json.loads(proc.stdout)
        if rc == 2:
            self.assertIn('error', answer)
        return answer

    def submit(self, items=None, limit=8, **identity):
        return self.call('submit', spec={'items': items or [{'id': 'a'}], 'max_attempts': limit}, **identity)

    def receipts(self):
        path = self.p / 'receipts.jsonl'
        return [json.loads(line) for line in path.read_text().splitlines()] if path.exists() else []

    def row(self, report, stage, item='a'):
        return next(r for r in report['rows'] if r['stage'] == stage and r['item'] == item)

    def crash(self, stage='inspect', tenant='acme', job='J1', limit=8):
        self.submit([{'id': 'a', 'payload': {'crash_after_effect': stage}}], limit, tenant=tenant, job=job)
        self.call('work', tenant=tenant, job=job, rc=17)

    def reconcile(self, stage='inspect', state='succeeded', tenant='acme', job='J1', **extra):
        return self.call('reconcile', tenant=tenant, job=job, stage=stage, item='a', state=state,
                         evidence='local receiver receipt: ' + self.receipts()[-1]['operation_key'],
                         result={'verified': True}, **extra)

    def test_saved_inspection_gap_and_summary_population(self):
        req = json.loads((REPO / 'traces/new-job.json').read_text())
        self.call(**req)
        r = self.call('work', job=req['job'])
        self.assertEqual((r['status'], r['coverage'], r['attempts']), ('incomplete', .5, 4))
        self.assertEqual(r['uncovered_ids'], ['invoice-B'])
        self.assertEqual(self.row(r, 'review', 'invoice-B')['state'], 'not_covered')
        self.assertEqual(len(r['rows']), 5)
        receipts = self.receipts()
        self.assertNotIn(('review', 'invoice-B'), [(x['stage'], x['item']) for x in receipts])
        context = receipts[-1]['coverage']
        self.assertEqual(receipts[-1]['stage'], 'summary')
        self.assertEqual(context['coverage'], .5)
        self.assertEqual(context['uncovered_ids'], ['invoice-B'])
        self.assertEqual(len(context['rows']), 5)
        self.assertEqual(self.call('work', job=req['job']), r)
        self.assertEqual(len(self.receipts()), 4)

    def test_review_failure_cannot_be_hidden_by_summary(self):
        self.submit([{'id': 'a'}, {'id': 'b', 'payload': {'review': 'fail'}}])
        r = self.call('work')
        self.assertEqual((r['status'], r['coverage']), ('incomplete', .5))
        self.assertEqual(r['uncovered_ids'], ['b'])
        self.assertEqual(self.receipts()[-1]['coverage']['coverage'], .5)
        self.assertEqual(self.row(r, 'summary', '__all__')['state'], 'succeeded')
        self.call('work')
        self.assertEqual(len(self.receipts()), 5)

    def test_healthy_reentry_spec_and_keys(self):
        original = self.submit()
        r = self.call('work')
        self.assertEqual((r['status'], r['coverage'], r['attempts']), ('completed', 1, 3))
        self.assertEqual(self.call('work'), r)
        self.assertEqual(self.submit(), r)
        self.assertEqual(self.call('report'), r)
        self.assertEqual([x['operation_key'] for x in original['rows']], [x['operation_key'] for x in r['rows']])
        self.assertEqual(len(self.receipts()), 3)

    def test_saved_crash_recovery_never_replays(self):
        req = json.loads((REPO / 'traces/crash-job.json').read_text())
        self.call(**req)
        job = req['job']
        self.call('work', job=job, rc=17)
        r = self.call('report', job=job)
        self.assertEqual((r['status'], r['attempts']), ('unknown', 1))
        key = self.row(r, 'inspect', 'delivery-A')['operation_key']
        self.assertEqual(self.receipts()[0]['operation_key'], key)
        self.assertEqual(self.call('work', job=job), r)
        self.assertEqual(len(self.receipts()), 1)
        fixed = self.call('reconcile', job=job, stage='inspect', item='delivery-A', state='succeeded',
                          result={'receipt_key': key}, evidence='receipt line 1: ' + key)
        self.assertEqual(fixed['attempts'], 1)
        self.assertEqual(fixed['reconciliations'][0]['evidence'], 'receipt line 1: ' + key)
        final = self.call('work', job=job)
        self.assertEqual((final['status'], final['attempts']), ('completed', 3))
        self.assertEqual([r['stage'] for r in self.receipts()], ['inspect', 'review', 'summary'])
        self.assertEqual(self.call('report', job=job)['reconciliations'], fixed['reconciliations'])

    def test_unknown_review_blocks_summary_and_reconciles_failure(self):
        self.crash('review')
        r = self.call('work')
        self.assertEqual((r['status'], r['attempts'], r['coverage']), ('unknown', 2, 0))
        self.assertEqual(len(self.receipts()), 2)
        self.reconcile('review', 'failed')
        final = self.call('work')
        self.assertEqual((final['status'], final['attempts'], final['coverage']), ('incomplete', 3, 0))
        self.assertEqual([r['stage'] for r in self.receipts()], ['inspect', 'review', 'summary'])

    def test_unknown_inspect_reconciled_failed_skips_review(self):
        self.crash()
        self.reconcile(state='failed')
        r = self.call('work')
        self.assertEqual((r['status'], r['attempts'], r['coverage']), ('incomplete', 2, 0))
        self.assertEqual(self.row(r, 'review')['state'], 'not_covered')
        self.assertEqual([r['stage'] for r in self.receipts()], ['inspect', 'summary'])

    def test_unknown_summary_is_not_completed_or_replayed(self):
        # The real receiver has no aggregate payload; emulate a process exit at
        # summary via the persisted pre-dispatch boundary, then use public CLI.
        self.submit(limit=2)
        r = self.call('work')
        self.assertEqual((r['coverage'], r['status']), (1, 'pending'))
        with sqlite3.connect(self.p / 'jobs.sqlite') as db:
            db.execute("UPDATE work SET state='running' WHERE stage='summary'")
        r = self.call('work')
        self.assertEqual(r['status'], 'unknown')
        self.assertEqual(len(self.receipts()), 2)
        self.call('reconcile', stage='summary', item='__all__', state='failed', result='delivery failed', evidence='local fixture')
        self.assertEqual(self.call('report')['status'], 'incomplete')

    def test_cumulative_budget_survives_work_report_resubmit_resume(self):
        self.submit([{'id': 'a'}, {'id': 'b'}], limit=1)
        r = self.call('work')
        self.assertEqual((r['attempts'], r['remaining_attempts'], r['status']), (1, 0, 'pending'))
        self.assertEqual(self.call('work'), r)
        self.assertEqual(self.submit([{'id': 'a'}, {'id': 'b'}], limit=1), r)
        self.call('cancel')
        self.call('resume')
        self.assertEqual(self.call('work'), r)
        self.assertEqual(len(self.receipts()), 1)

    def test_crash_consumes_original_budget(self):
        self.crash(limit=1)
        self.reconcile()
        r = self.call('work')
        self.assertEqual((r['attempts'], r['remaining_attempts']), (1, 0))
        self.assertEqual(self.row(r, 'review')['state'], 'pending')
        self.assertEqual(len(self.receipts()), 1)

    def test_cancel_is_durable_until_explicit_resume(self):
        self.submit()
        r = self.call('cancel')
        self.assertEqual(r['status'], 'cancelled')
        self.assertEqual(self.submit(), r)
        self.assertEqual(self.call('work'), r)
        self.assertEqual(len(self.receipts()), 0)
        self.call('resume')
        r = self.call('work')
        self.assertEqual((r['status'], r['attempts']), ('completed', 3))

    def test_reconcile_does_not_resume_cancelled_worker(self):
        self.crash()
        self.call('cancel')
        r = self.reconcile()
        self.assertTrue(r['cancelled'])
        self.assertEqual(self.call('work')['attempts'], 1)
        self.assertEqual(len(self.receipts()), 1)
        self.call('resume')
        self.assertEqual(self.call('work')['status'], 'completed')

    def test_tenant_scoped_spec_budget_cancel_and_receipt_keys(self):
        a = self.submit(limit=1)
        b = self.submit([{'id': 'b'}], limit=6, tenant='beta')
        self.assertTrue(set(r['operation_key'] for r in a['rows']).isdisjoint(r['operation_key'] for r in b['rows']))
        self.call('cancel')
        r = self.call('work', tenant='beta')
        self.assertEqual((r['status'], r['attempts'], r['remaining_attempts'], r['covered_ids']), ('completed', 3, 3, ['b']))
        self.assertEqual(self.call('report')['status'], 'cancelled')
        self.call('report', tenant='stranger', rc=2)
        self.call('work', tenant='stranger', rc=2)
        self.assertEqual(len(self.receipts()), 3)

    def test_same_job_unknown_reconciliation_is_tenant_scoped(self):
        self.crash(tenant='acme')
        self.crash(tenant='beta')
        akey, bkey = [x['operation_key'] for x in self.receipts()]
        self.assertNotEqual(akey, bkey)
        self.reconcile(tenant='beta')
        self.assertEqual(self.call('report')['status'], 'unknown')
        self.assertEqual(self.row(self.call('report', tenant='beta'), 'inspect')['state'], 'succeeded')
        self.assertEqual(self.call('report')['reconciliations'], [])
        self.call('reconcile', tenant='stranger', stage='inspect', item='a', state='failed', evidence='fixture', rc=2)
        self.assertEqual(self.call('report')['attempts'], 1)

    def test_reconcile_requires_evidence_and_unknown_target(self):
        self.crash()
        before = self.call('report')
        for evidence in (None, '', '  ', {}, 5):
            with self.subTest(evidence=evidence):
                self.call('reconcile', stage='inspect', item='a', state='succeeded', evidence=evidence, rc=2)
                self.assertEqual(self.call('report'), before)
        for stage, item, state in [('review', 'a', 'succeeded'), ('inspect', 'missing', 'failed'),
                                   ('missing', 'a', 'failed'), ('inspect', 'a', 'pending')]:
            self.call('reconcile', stage=stage, item=item, state=state, evidence='fixture', rc=2)
        self.reconcile()
        settled = self.call('report')
        self.call('reconcile', stage='inspect', item='a', state='failed', evidence='replacement', rc=2)
        self.assertEqual(self.call('report'), settled)

    def test_immutable_population_payload_and_budget(self):
        self.submit()
        for spec in ({'items': [{'id': 'b'}], 'max_attempts': 8},
                     {'items': [{'id': 'a'}], 'max_attempts': 9},
                     {'items': [{'id': 'a', 'payload': {'inspect': 'fail'}}], 'max_attempts': 8}):
            self.call('submit', spec=spec, rc=2)
        self.assertEqual(self.call('report')['attempts'], 0)
        self.assertEqual(len(self.receipts()), 0)

    def test_canonical_spec_comparison(self):
        self.submit([{'id': 'a', 'payload': {'flag': True, 'z': 3}}])
        self.call('submit', spec={'max_attempts': 8, 'items': [{'payload': {'z': 3, 'flag': True}, 'id': 'a'}]})
        self.call('submit', spec={'max_attempts': 8, 'items': [{'id': 'a', 'payload': {'flag': 1, 'z': 3}}]}, rc=2)

    def test_malformed_requests_return_json_errors(self):
        for spec in (None, [], {}, {'items': [], 'max_attempts': 8},
                     {'items': [{'id': 'a'}, {'id': 'a'}], 'max_attempts': 8},
                     {'items': [{'id': '__all__'}], 'max_attempts': 8},
                     {'items': [{'id': 'a', 'payload': 'bad'}], 'max_attempts': 8},
                     {'items': [{'id': 'a'}], 'max_attempts': True}):
            with self.subTest(spec=spec):
                self.call('submit', spec=spec, rc=2)
        self.call('submit', tenant='', spec={'items': [{'id': 'a'}], 'max_attempts': 8}, rc=2)

    def test_exception_and_malformed_outcome_remain_unknown(self):
        from intake.store import Store
        from intake.service import handle
        for index, failure in enumerate((OSError('receiver failed after effect'), None,
                                         {'status': 'pending', 'output': {}}, {'status': 'succeeded'},
                                         {'status': 'succeeded', 'output': float('nan')})):
            store = Store(self.p / ('direct-%d.sqlite' % index))
            req = {'tenant': 'acme', 'job': 'J1'}
            try:
                handle(store, {**req, 'op': 'submit', 'spec': {'items': [{'id': 'a'}], 'max_attempts': 8}}, self.p / 'direct.jsonl')
                def receiver(context, path):
                    # Independently reopen SQLite to prove the pre-dispatch
                    # transaction is visible to another connection.
                    with sqlite3.connect(self.p / ('direct-%d.sqlite' % index)) as db:
                        self.assertEqual(db.execute('SELECT attempts FROM jobs').fetchone()[0], 1)
                        self.assertEqual(db.execute("SELECT state FROM work WHERE stage='inspect'").fetchone()[0], 'running')
                    if isinstance(failure, Exception):
                        raise failure
                    return failure
                with patch('intake.service.perform', side_effect=receiver) as mocked:
                    with self.assertRaises((OSError, ValueError)):
                        handle(store, {**req, 'op': 'work'}, self.p / 'direct.jsonl')
                    r = handle(store, {**req, 'op': 'work'}, self.p / 'direct.jsonl')
                    self.assertEqual(mocked.call_count, 1)
                    self.assertEqual((r['status'], r['attempts']), ('unknown', 1))
            finally:
                store.close()

    def test_receiver_io_error_uses_public_error_contract(self):
        self.submit()
        # Directory in place of receipt file: no real external dependency.
        (self.p / 'receipts.jsonl').mkdir()
        self.call('work', rc=2)
        r = self.call('report')
        self.assertEqual((r['status'], r['attempts']), ('unknown', 1))
        self.assertEqual(self.call('work'), r)


if __name__ == '__main__':
    result = unittest.main(verbosity=2, exit=False).result
    (OUTPUT / 'verification.json').write_text(json.dumps({
        'tests_run': result.testsRun, 'failures': len(result.failures),
        'errors': len(result.errors), 'successful': result.wasSuccessful(),
        'scope': 'offline public CLI, SQLite and local receiver; no model/network',
        'fixtures': str(FIXTURES.relative_to(ROOT))}, indent=2))
    sys.exit(not result.wasSuccessful())
