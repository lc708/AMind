# Incident 73 repair

The CLI arguments and simulated receiver are unchanged. The intake worker now commits an
unknown operation and its attempt before dispatch, requires inspection success
before review, and delays summary until every item dependency has a known
outcome. Failed inspections produce `not_covered` reviews without receiver calls.
Summary can describe known failures; overall coverage requires **both** inspection
and review success for every item. A successful summary cannot close an item gap.

## Cause

- Dispatch preceded the SQLite running/attempt transaction. Exit 17 left a pending
  operation that another process delivered again.
- Each work invocation reset attempts and cleared durable cancellation.
- Review dependency checks used `pass`, and summary had no dependency gate.
- Coverage counted only inspections. Successful inspections with failed reviews
  could appear fully covered.
- Job lookup omitted tenant, and operation-key hashes omitted tenant.
- Reconciliation accepted pending/settled rows and did not require or retain
  external evidence.

## Persistence and recovery

New dispatches atomically change pending to running and increment cumulative
attempts. Exceptions, malformed receiver responses and process exits retain that
running/unknown state. Restart skips it; absence of a local result is not failure.
Only explicit resume clears cancellation, without replenishing the original
budget. Reporting and identical resubmission are read-only with respect to both.

Reconcile requires tenant, job, stage, item, a terminal state, and a nonblank
string containing external evidence. A conditional update accepts exactly one
running row; result, state and evidence commit in the same transaction. Evidence
is retained in an additive `reconciliations` table and returned by reports.
Pending or already settled rows cannot be rewritten, even by repeating reconcile.
Existing report fields and serialized row results are preserved; per-stage counts
and reconciliation records are additive. Immutable specifications are compared
as canonical JSON, including payloads, population order and attempt limit.

Job reads and writes include tenant and job. New operation keys hash the canonical
JSON tuple `[tenant, job, stage, item]`, persist with the plan, and survive restart.
The database can be reopened with its existing jobs/work schema; adding the
evidence table does not reset existing rows, attempts or cancellation.

## Reproduction and verification

Use Python 3 (this environment provides `python3`, without a `python` alias).
From `repo/`, run the existing public checks with local temporary storage:

```sh
mkdir -p ../output/tmp
TMPDIR="$PWD/../output/tmp" python3 -m unittest discover -s tests
```

From the workspace root, run the added public-entry regressions:

```sh
python3 output/test_incident73.py
```

These tests invoke `python3 -m intake --db ... --request ... --receipts ...` in
fresh subprocesses using local fixtures. Requests, responses, SQLite journals and
receiver JSONL files remain in `output/verification-fixtures/`. The focused
receiver-exception checks additionally observe committed state from a separate
SQLite connection before returning/raising. One aggregate-unknown check seeds
that boundary in SQLite because the normal receiver has no aggregate crash
payload; inspection and review crashes execute the actual exit-17 receiver path.

The saved `traces/crash-job.json` reproduced two identical inspection deliveries
on two old worker starts (both exited 17). After the fix, the first start exits 17,
report shows attempts=1 and unknown, and further work emits no receipt. With the
actual receipt's key supplied as evidence, reconciliation permits review and
summary; there are exactly three receipts and three attempts overall.

The saved `traces/new-job.json` previously dispatched review for the failed
inspection. It now emits four receipts (two inspections, one review, one
summary), retains all five planned rows, and reports coverage=0.5/incomplete.
The summary's context retains invoice-B as uncovered. A separate failed-review
case also remains incomplete at coverage=0.5 despite successful summary delivery.

Verified results: 3 original public tests and 19 added regression tests passed.
An isolated copy containing only the repository also passed submit/work/report
with three receipts and completed status; see `output/standalone-verification.json`.
The added suite covers crash/restart, receiver exceptions and malformed outcomes,
reconciliation evidence and terminal-state protection, tenant isolation and keys,
cancellation/resume, original attempt budgets, immutable specs, complete population
reporting, dependency gates, healthy repeated work and JSON error responses.
`output/baseline.json`, `output/regression-results.txt` and
`output/verification.json` retain the observations and measured test results.

## Limits and provenance

This is a single local coordinator and SQLite journal, as specified in README;
there is no distributed lease, remote cancellation, timeout or receiver-side
idempotency service. Reconciliation trusts the operator's supplied external
receipt; it cannot authenticate that evidence or reverse a delivered effect.
There is no automatic retry of known failures or unknown outcomes.

Historical effects and counters lost by the old code cannot be reconstructed
from an old pending row alone. Existing operation keys are kept stable, including
legacy keys that omitted tenant; already delivered duplicate receipts or legacy
cross-tenant key collisions require an operator audit. New jobs use tenant-scoped
keys. No automatic rewrite of old receipts or settled outcomes is attempted.

Recovery design was informed by the locally assigned AMind Engineering skill's
`references/workflow-recipes.md`, `references/agent-lifecycle.md` and
`scripts/workflow_contract.py`. Application code is implemented in this repository
using Python's standard library; no skill files, absolute deployment paths,
external packages, model services or network access are needed at runtime.
