"""Local coordinator using AMind Engineering's staged recovery/coverage contract.

No runtime dependency on the skill; only Python standard library and intake.
"""
import json
from .store import operation_key, packed
from .receiver import perform

STAGES = ('inspect', 'review', 'summary')
UNSETTLED = ('pending', 'running')


def validate(spec):
    if not isinstance(spec, dict):
        raise ValueError('job specification must be an object')
    items = spec.get('items')
    limit = spec.get('max_attempts')
    if not isinstance(items, list) or not items:
        raise ValueError('nonempty item population required')
    ids = [i.get('id') for i in items if isinstance(i, dict)]
    if (len(ids) != len(items) or
            any(not isinstance(i, str) or not i or i == '__all__' for i in ids) or
            len(set(ids)) != len(ids)):
        raise ValueError('unique item IDs required')
    if any(i.get('payload') is not None and not isinstance(i['payload'], dict) for i in items):
        raise ValueError('item payload must be an object')
    if type(limit) is not int or limit < 1:
        raise ValueError('positive max_attempts required')
    packed(spec)
    return spec


def report(store, tenant, job):
    entry = store.job(tenant, job)
    rows = store.rows(tenant, job)
    population = [i['id'] for i in entry['spec']['items']]
    states = {(r['stage'], r['item']): r['state'] for r in rows}
    covered = [i for i in population if all(states.get((stage, i)) == 'succeeded'
                                          for stage in ('inspect', 'review'))]
    pending = any(r['state'] == 'pending' for r in rows)
    unknown = any(r['state'] == 'running' for r in rows)
    complete = len(covered) == len(population) and states.get(('summary', '__all__')) == 'succeeded'
    status = 'unknown' if unknown else ('pending' if pending else ('completed' if complete else 'incomplete'))
    if entry['cancelled']:
        status = 'cancelled'
    stages = []
    for stage in STAGES:
        selected = [r for r in rows if r['stage'] == stage]
        counts = {}
        for row in selected:
            counts[row['state']] = counts.get(row['state'], 0) + 1
        stages.append({'stage': stage, 'total': len(selected), 'counts': counts,
                       'uncovered_ids': [r['item'] for r in selected if r['state'] != 'succeeded']})
    return {'tenant': tenant, 'job': job, 'status': status, 'attempts': entry['attempts'],
            'remaining_attempts': max(0, entry['spec']['max_attempts'] - entry['attempts']),
            'coverage': len(covered) / len(population), 'covered_ids': covered,
            'uncovered_ids': [i for i in population if i not in covered],
            'cancelled': entry['cancelled'], 'rows': rows, 'stages': stages,
            'reconciliations': store.evidence(tenant, job)}


def submit(store, tenant, job, spec):
    spec = validate(spec)
    encoded = packed(spec)
    store.db.execute('BEGIN IMMEDIATE')
    try:
        old = store.db.execute('SELECT spec FROM jobs WHERE tenant=? AND job=?', (tenant, job)).fetchone()
        if old:
            # Canonical JSON distinguishes e.g. true from 1 in payloads.
            if packed(json.loads(old[0])) != encoded:
                raise ValueError('immutable job specification differs')
        else:
            store.db.execute('INSERT INTO jobs VALUES(?,?,?,0,0)', (tenant, job, encoded))
            for stage in STAGES:
                for item in (['__all__'] if stage == 'summary' else [i['id'] for i in spec['items']]):
                    store.db.execute('INSERT INTO work VALUES(?,?,?,?,?,?,?)',
                                     (tenant, job, stage, item, 'pending', None,
                                      operation_key(tenant, job, stage, item)))
        store.db.execute('COMMIT')
    except BaseException:
        store.db.execute('ROLLBACK')
        raise
    return report(store, tenant, job)


def claim(store, tenant, job, stage, item):
    """Commit both the attempt and unknown outcome BEFORE calling the receiver."""
    store.db.execute('BEGIN IMMEDIATE')
    try:
        entry = store.job(tenant, job)
        allowed = not entry['cancelled'] and entry['attempts'] < entry['spec']['max_attempts']
        changed = 0
        if allowed:
            changed = store.db.execute("UPDATE work SET state='running' WHERE tenant=? AND job=? AND stage=? AND item=? AND state='pending'",
                                       (tenant, job, stage, item)).rowcount
            if changed:
                store.db.execute('UPDATE jobs SET attempts=attempts+1 WHERE tenant=? AND job=?', (tenant, job))
        store.db.execute('COMMIT')
        return bool(changed)
    except BaseException:
        store.db.execute('ROLLBACK')
        raise


def work(store, tenant, job, receipts):
    if store.job(tenant, job)['cancelled']:
        return report(store, tenant, job)
    for stage in STAGES:
        for row in [r for r in store.rows(tenant, job) if r['stage'] == stage]:
            if row['state'] != 'pending':
                continue  # Running is UNKNOWN and must never replay.
            previous = [r for r in store.rows(tenant, job) if r['stage'] in ('inspect', 'review')]
            if stage == 'review':
                dependency = next(r for r in previous if r['stage'] == 'inspect' and r['item'] == row['item'])
                if dependency['state'] in UNSETTLED:
                    continue
                if dependency['state'] != 'succeeded':
                    store.update(tenant, job, stage, row['item'], 'not_covered',
                                 {'reason': 'inspection did not succeed'})
                    continue
            if stage == 'summary' and any(r['state'] in UNSETTLED for r in previous):
                continue
            entry = store.job(tenant, job)
            context = {'tenant': tenant, 'job': job, 'stage': stage, 'item': row['item'],
                       'operation_key': row['operation_key'],
                       'payload': next((i.get('payload', {}) for i in entry['spec']['items'] if i['id'] == row['item']), {}),
                       'coverage': report(store, tenant, job)}
            if not claim(store, tenant, job, stage, row['item']):
                return report(store, tenant, job)
            outcome = perform(context, receipts)
            # Exceptions or malformed results leave the committed attempt unknown.
            if (not isinstance(outcome, dict) or outcome.get('status') not in ('succeeded', 'failed')
                    or 'output' not in outcome):
                raise ValueError('receiver must return a terminal outcome and output; outcome remains unknown')
            store.update(tenant, job, stage, row['item'], outcome['status'], outcome['output'])
    return report(store, tenant, job)


def handle(store, request, receipts):
    if not isinstance(request, dict):
        raise ValueError('request must be an object')
    tenant = request.get('tenant')
    job = request.get('job')
    op = request.get('op')
    if any(not isinstance(v, str) or not v for v in (tenant, job)):
        raise ValueError('trusted tenant and job identity required')
    if op == 'submit':
        return submit(store, tenant, job, request['spec'])
    store.job(tenant, job)
    if op == 'report':
        return report(store, tenant, job)
    if op == 'work':
        return work(store, tenant, job, receipts)
    if op in ('cancel', 'resume'):
        store.db.execute('UPDATE jobs SET cancelled=? WHERE tenant=? AND job=?', (int(op == 'cancel'), tenant, job))
        return report(store, tenant, job)
    if op == 'reconcile':
        store.reconcile(tenant, job, request.get('stage'), request.get('item'), request.get('state'),
                        request.get('result'), request.get('evidence'))
        return report(store, tenant, job)
    raise ValueError('unknown operation')
