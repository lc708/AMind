"""Run a copied intake package with site packages disabled and relative paths."""
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

root = Path(__file__).resolve().parents[1]
run = Path(tempfile.mkdtemp(prefix='standalone-', dir=root/'output'))
shutil.copytree(root/'repo/intake', run/'intake', ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
outputs = []
for op in ('submit', 'work', 'report'):
    request = {'op':op, 'tenant':'local', 'job':'standalone'}
    if op == 'submit':
        request['spec'] = {'items':[{'id':'one'}], 'max_attempts':3}
    (run/'request.json').write_text(json.dumps(request))
    process = subprocess.run([sys.executable, '-S', '-B', '-m', 'intake', '--db','jobs.sqlite',
                              '--request','request.json','--receipts','receipts.jsonl'],
                             cwd=run, capture_output=True, text=True, timeout=10)
    assert process.returncode == 0, process.stderr + process.stdout
    outputs.append(json.loads(process.stdout))
assert outputs[-1]['status'] == 'completed' and outputs[-1]['attempts'] == 3
assert len((run/'receipts.jsonl').read_text().splitlines()) == 3
record = {'directory':run.name, 'site_packages':False, 'status':outputs[-1]['status'], 'reports':outputs}
(root/'output/standalone-results.json').write_text(json.dumps(record, indent=2))
print(json.dumps({'directory':run.name, 'status':outputs[-1]['status'], 'attempts':outputs[-1]['attempts']}))
