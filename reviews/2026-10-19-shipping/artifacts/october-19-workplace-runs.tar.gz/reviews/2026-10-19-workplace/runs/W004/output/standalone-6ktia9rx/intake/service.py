import json
from .store import operation_key, packed
from .receiver import perform

STAGES = ('inspect', 'review', 'summary')
UNKNOWN = ('running', 'unknown')
SETTLED = ('succeeded', 'failed', 'skipped')


def validate(spec):
    if not isinstance(spec, dict):
        raise ValueError('job specification must be an object')
    items = spec.get('items')
    limit = spec.get('max_attempts')
    if not isinstance(items, list) or not items:
        raise ValueError('nonempty item population required')
    ids = [i.get('id') for i in items if isinstance(i, dict)]
    if len(ids) != len(items) or any(not isinstance(i, str) or not i or i == '__all__' for i in ids) or len(set(ids)) != len(ids):
        raise ValueError('unique item IDs required')
    if any(i.get('payload') is not None and not isinstance(i['payload'], dict) for i in items):
        raise ValueError('item payload must be an object or null')
    if type(limit) is not int or limit < 1:
        raise ValueError('positive max_attempts required')
    packed(spec)
    return spec


def report(store, tenant, job):
    entry = store.job(tenant, job)
    rows = store.rows(tenant, job)
    population = [i['id'] for i in entry['spec']['items']]
    states = {(r['stage'], r['item']): r['state'] for r in rows}
    covered = [i for i in population if all(states.get((stage, i)) == 'succeeded' for stage in ('inspect', 'review'))]
    pending = any(r['state'] == 'pending' for r in rows)
    unknown = any(r['state'] in UNKNOWN for r in rows)
    complete = len(covered) == len(population) and states.get(('summary', '__all__')) == 'succeeded'
    status = 'unknown' if unknown else ('pending' if pending else ('completed' if complete else 'incomplete'))
    if entry['cancelled']:
        status = 'cancelled'
    return {'tenant': tenant, 'job': job, 'status': status, 'attempts': entry['attempts'],
            'remaining_attempts': max(0, entry['spec']['max_attempts'] - entry['attempts']),
            'coverage': len(covered) / len(population), 'covered_ids': covered,
            'uncovered_ids': [i for i in population if i not in covered],
            'cancelled': entry['cancelled'], 'rows': rows}


def submit(store, tenant, job, spec):
    spec = validate(spec)
    store.db.execute('BEGIN IMMEDIATE')
    try:
        old = store.db.execute('SELECT spec FROM jobs WHERE tenant=? AND job=?', (tenant, job)).fetchone()
        if old:
            if json.loads(old[0]) != spec:
                raise ValueError('immutable job specification differs')
        else:
            store.db.execute('INSERT INTO jobs VALUES(?,?,?,0,0)', (tenant, job, packed(spec)))
            for stage in STAGES:
                for item in (['__all__'] if stage == 'summary' else [i['id'] for i in spec['items']]):
                    store.db.execute('INSERT INTO work VALUES(?,?,?,?,?,?,?)',
                                     (tenant, job, stage, item, 'pending', None, operation_key(tenant, job, stage, item)))
        store.db.execute('COMMIT')
    except BaseException:
        store.db.execute('ROLLBACK')
        raise
    return report(store, tenant, job)


def work(store, tenant, job, receipts):
    for stage in STAGES:
        for row in [r for r in store.rows(tenant, job) if r['stage'] == stage]:
            if row['state'] != 'pending':
                continue
            entry = store.job(tenant, job)
            if entry['cancelled']:
                return report(store, tenant, job)
            item_rows = [r for r in store.rows(tenant, job) if r['stage'] in ('inspect', 'review')]
            if stage == 'review':
                dependency = next(r for r in item_rows if r['stage'] == 'inspect' and r['item'] == row['item'])
                if dependency['state'] in ('failed', 'skipped'):
                    # A known failed inspection is a retained gap, not a retry.
                    store.update(tenant, job, stage, row['item'], 'skipped', {'reason': 'inspection did not succeed'})
                    continue
                if dependency['state'] != 'succeeded':
                    continue
            if stage == 'summary' and any(r['state'] not in SETTLED for r in item_rows):
                continue
            if not store.claim(tenant, job, stage, row['item']):
                return report(store, tenant, job)
            context = {'tenant': tenant, 'job': job, 'stage': stage, 'item': row['item'],
                       'operation_key': row['operation_key'],
                       'payload': next((i.get('payload', {}) for i in entry['spec']['items'] if i['id'] == row['item']), {}),
                       'coverage': report(store, tenant, job)}
            # Exceptions/process exits leave the committed running row unknown.
            outcome = perform(context, receipts)
            store.update(tenant, job, stage, row['item'], outcome['status'], outcome['output'])
    return report(store, tenant, job)


def handle(store, request, receipts):
    if not isinstance(request, dict):
        raise ValueError('request must be an object')
    tenant = request.get('tenant')
    job = request.get('job')
    op = request.get('op')
    if any(not isinstance(v, str) or not v for v in (tenant, job)):
        raise ValueError('trusted tenant and job identity required')
    if op == 'submit':
        return submit(store, tenant, job, request['spec'])
    store.job(tenant, job)
    if op == 'report':
        return report(store, tenant, job)
    if op == 'work':
        return work(store, tenant, job, receipts)
    if op in ('cancel', 'resume'):
        store.db.execute('UPDATE jobs SET cancelled=? WHERE tenant=? AND job=?', (int(op == 'cancel'), tenant, job))
        return report(store, tenant, job)
    if op == 'reconcile':
        store.reconcile(tenant, job, request.get('stage'), request.get('item'), request.get('state'), request.get('result'), request.get('evidence'))
        return report(store, tenant, job)
    raise ValueError('unknown operation')
