"""Offline CLI regressions; every subprocess and receipt stays in this checkout."""
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
FIXTURES = ROOT / 'output' / 'tmp'
FIXTURES.mkdir(parents=True, exist_ok=True)


class Incident73(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(dir=FIXTURES)
        self.p = Path(self.tmp.name)
        self.db = self.p / 'jobs.sqlite'
        self.receipts = self.p / 'receipts.jsonl'

    def tearDown(self):
        self.tmp.cleanup()

    def call(self, op, tenant='acme', job='J1', expected=0, **fields):
        path = self.p / 'request.json'
        path.write_text(json.dumps(dict(op=op, tenant=tenant, job=job, **fields)))
        result = subprocess.run([sys.executable, '-m', 'intake', '--db', str(self.db),
                                 '--request', str(path), '--receipts', str(self.receipts)],
                                cwd=ROOT / 'repo', text=True, capture_output=True, timeout=10)
        self.assertEqual(result.returncode, expected, result.stderr + result.stdout)
        if expected == 17:
            self.assertEqual(result.stdout, '')
            return None
        answer = json.loads(result.stdout)
        if expected == 2:
            self.assertIn('error', answer)
        return answer

    def submit(self, items=None, max_attempts=8, **fields):
        return self.call('submit', spec={'items': items or [{'id': 'a'}], 'max_attempts': max_attempts}, **fields)

    def effects(self):
        return [json.loads(line) for line in self.receipts.read_text().splitlines()] if self.receipts.exists() else []

    def row(self, report, stage, item='a'):
        return next(r for r in report['rows'] if r['stage'] == stage and r['item'] == item)

    def crash(self, stage='inspect', max_attempts=8, **fields):
        self.submit([{'id': 'a', 'payload': {'crash_after_effect': stage}}], max_attempts, **fields)
        self.call('work', expected=17, **fields)

    def reconcile(self, stage='inspect', state='succeeded', **fields):
        return self.call('reconcile', stage=stage, item='a', state=state,
                         result={'verified': True}, evidence='local receipt observed', **fields)

    def test_healthy_idempotent_work_and_submission(self):
        initial = self.submit()
        done = self.call('work')
        self.assertEqual((done['status'], done['coverage'], done['attempts']), ('completed', 1, 3))
        self.assertEqual(initial['rows'][0]['operation_key'], done['rows'][0]['operation_key'])
        self.assertEqual(done, self.call('work'))
        self.assertEqual(done, self.submit())
        self.assertEqual(len(self.effects()), 3)

    def test_saved_partial_population(self):
        spec = json.loads((ROOT/'repo/traces/new-job.json').read_text())['spec']
        self.call('submit', spec=spec)
        result = self.call('work')
        self.assertEqual((result['status'], result['coverage'], result['attempts']), ('incomplete', .5, 4))
        self.assertEqual(result['uncovered_ids'], ['invoice-B'])
        self.assertEqual(self.row(result, 'review', 'invoice-B')['state'], 'skipped')
        summary = self.effects()[-1]
        self.assertEqual(summary['stage'], 'summary')
        self.assertEqual(summary['coverage']['uncovered_ids'], ['invoice-B'])
        self.assertEqual(len(summary['coverage']['rows']), 5)
        self.assertEqual(result, self.call('work'))

    def test_review_failure_remains_gap_in_summary(self):
        self.submit([{'id': 'a', 'payload': {'review': 'fail'}}, {'id': 'b'}])
        r = self.call('work')
        self.assertEqual((r['coverage'], r['covered_ids'], r['uncovered_ids']), (.5, ['b'], ['a']))
        self.assertEqual(r['status'], 'incomplete')
        self.assertEqual(self.effects()[-1]['coverage']['coverage'], .5)
        self.assertEqual(r, self.call('work'))

    def test_crash_is_committed_unknown_never_automatically_replayed(self):
        self.crash()
        r = self.call('report')
        self.assertEqual((r['status'], r['attempts']), ('unknown', 1))
        self.assertEqual(self.row(r, 'inspect')['state'], 'running')
        for _ in range(2):
            self.assertEqual(r, self.call('work'))
        self.assertEqual(len(self.effects()), 1)
        self.assertEqual(self.effects()[0]['operation_key'], self.row(r, 'inspect')['operation_key'])

    def test_unknown_review_blocks_summary(self):
        self.crash('review')
        r = self.call('work')
        self.assertEqual((r['status'], r['attempts'], r['coverage']), ('unknown', 2, 0))
        self.assertEqual([e['stage'] for e in self.effects()], ['inspect', 'review'])
        self.reconcile('review')
        self.assertEqual(self.call('work')['status'], 'completed')
        self.assertEqual(len(self.effects()), 3)

    def test_successful_reconciliation_unblocks_dependencies_without_replay(self):
        self.crash()
        original_key = self.call('report')['rows'][0]['operation_key']
        self.reconcile()
        r = self.call('work')
        self.assertEqual((r['status'], r['attempts']), ('completed', 3))
        self.assertEqual(len(self.effects()), 3)
        with sqlite3.connect(self.db) as db:
            record = db.execute('SELECT operation_key,evidence,result FROM reconciliations').fetchone()
        self.assertEqual(record[:2], (original_key, 'local receipt observed'))
        self.assertEqual(json.loads(record[2]), {'verified': True})

    def test_failed_reconciliation_retains_gap(self):
        self.crash()
        self.reconcile(state='failed')
        r = self.call('work')
        self.assertEqual((r['status'], r['coverage'], r['attempts']), ('incomplete', 0, 2))
        self.assertEqual([e['stage'] for e in self.effects()], ['inspect', 'summary'])

    def test_reconcile_requires_nonempty_external_evidence(self):
        self.crash()
        for evidence in (None, '', '  ', 3, {}):
            self.call('reconcile', stage='inspect', item='a', state='succeeded', evidence=evidence, expected=2)
        self.assertEqual(self.call('report')['status'], 'unknown')
        self.assertEqual(len(self.effects()), 1)

    def test_reconcile_cannot_rewrite_pending_or_settled(self):
        self.submit()
        self.reconcile(expected=2)
        self.call('work')
        before = self.call('report')
        self.reconcile(expected=2)
        self.assertEqual(before, self.call('report'))

    def test_second_reconciliation_rejected(self):
        self.crash()
        self.reconcile()
        before = self.call('report')
        self.reconcile(state='failed', expected=2)
        self.assertEqual(before, self.call('report'))

    def test_cancel_persists_until_explicit_resume(self):
        self.submit()
        cancelled = self.call('cancel')
        self.assertEqual(cancelled, self.call('work'))
        self.assertEqual(cancelled, self.submit())
        self.assertEqual(cancelled, self.call('report'))
        self.assertEqual(self.effects(), [])
        self.call('resume')
        self.assertEqual(self.call('work')['status'], 'completed')

    def test_budget_cumulative_across_restart_cancel_resume_submit(self):
        self.submit(max_attempts=1)
        r = self.call('work')
        self.assertEqual((r['attempts'], r['remaining_attempts'], r['coverage']), (1, 0, 0))
        self.call('cancel')
        self.submit(max_attempts=1)
        self.call('resume')
        self.assertEqual(r, self.call('work'))
        self.assertEqual(len(self.effects()), 1)

    def test_crashed_dispatch_consumes_budget_even_after_reconciliation(self):
        self.crash(max_attempts=1)
        self.reconcile()
        r = self.call('work')
        self.assertEqual((r['attempts'], r['remaining_attempts'], r['status']), (1, 0, 'pending'))
        self.assertEqual(len(self.effects()), 1)

    def test_tenant_population_budget_cancellation_and_keys_are_isolated(self):
        a = self.submit(max_attempts=1)
        b = self.submit([{'id': 'a'}, {'id': 'b'}], max_attempts=7, tenant='other')
        self.assertNotEqual(a['rows'][0]['operation_key'], b['rows'][0]['operation_key'])
        self.assertNotEqual(a['rows'][-1]['operation_key'], b['rows'][-1]['operation_key'])
        self.call('cancel')
        other = self.call('work', tenant='other')
        self.assertEqual((other['status'], other['attempts'], other['covered_ids']), ('completed', 5, ['a', 'b']))
        self.assertEqual(self.call('report')['status'], 'cancelled')
        self.call('report', tenant='missing', expected=2)
        self.call('work', tenant='missing', expected=2)

    def test_tenant_scoped_recovery(self):
        self.crash()
        self.submit(tenant='other')
        self.reconcile(tenant='other', expected=2)
        self.assertEqual(self.call('report')['status'], 'unknown')
        self.reconcile()
        self.assertEqual(self.call('work')['status'], 'completed')
        self.assertEqual(self.call('report', tenant='other')['attempts'], 0)

    def test_immutable_population_payload_and_budget(self):
        before = self.submit()
        for spec in ({'items':[{'id':'b'}], 'max_attempts':8},
                     {'items':[{'id':'a','payload':{'review':'fail'}}], 'max_attempts':8},
                     {'items':[{'id':'a'}], 'max_attempts':9}):
            self.call('submit', spec=spec, expected=2)
        self.assertEqual(before, self.call('report'))

    def test_immutable_spec_preserves_json_types_but_ignores_object_key_order(self):
        spec = {'items':[{'id':'a', 'payload':{'flag':True}}], 'max_attempts':8}
        before = self.call('submit', spec=spec)
        reordered = {'max_attempts':8, 'items':[{'payload':{'flag':True}, 'id':'a'}]}
        self.assertEqual(before, self.call('submit', spec=reordered))
        spec['items'][0]['payload']['flag'] = 1
        self.call('submit', spec=spec, expected=2)
        self.assertEqual(before, self.call('report'))

    def test_invalid_specs_do_not_create_jobs_or_effects(self):
        for spec in (None, [], {}, {'items':[], 'max_attempts':8},
                     {'items':[{'id':'a'},{'id':'a'}], 'max_attempts':8},
                     {'items':[{'id':'__all__'}], 'max_attempts':8},
                     {'items':[{'id':'a'}], 'max_attempts':True},
                     {'items':[{'id':'a', 'payload':'bad'}], 'max_attempts':8}):
            self.call('submit', spec=spec, expected=2)
        self.call('report', expected=2)
        self.assertEqual(self.effects(), [])

    def test_existing_database_preserves_original_unknown_remote_key(self):
        # Exact old schema: upgrade must not derive another key for in-flight work.
        with sqlite3.connect(self.db) as db:
            db.execute('CREATE TABLE jobs(tenant TEXT,job TEXT,spec TEXT,cancelled INTEGER,attempts INTEGER,PRIMARY KEY(tenant,job))')
            db.execute('CREATE TABLE work(tenant TEXT,job TEXT,stage TEXT,item TEXT,state TEXT,result TEXT,operation_key TEXT,PRIMARY KEY(tenant,job,stage,item))')
            db.execute('INSERT INTO jobs VALUES(?,?,?,?,?)', ('acme','J1',json.dumps({'items':[{'id':'a'}],'max_attempts':8}),0,1))
            for stage, item, state in [('inspect','a','running'),('review','a','pending'),('summary','__all__','pending')]:
                db.execute('INSERT INTO work VALUES(?,?,?,?,?,?,?)', ('acme','J1',stage,item,state,None,'legacy-'+stage))
        self.assertEqual(self.call('work')['rows'][0]['operation_key'], 'legacy-inspect')
        self.assertEqual(self.effects(), [])
        self.reconcile()
        self.assertEqual(self.call('work')['status'], 'completed')
        self.assertEqual([e['operation_key'] for e in self.effects()], ['legacy-review','legacy-summary'])

    def test_summary_unknown_is_not_completion_or_replayed(self):
        self.submit()
        self.call('work')
        # Restore a checkpoint whose aggregate receipt was delivered but not saved.
        with sqlite3.connect(self.db) as db:
            db.execute("UPDATE work SET state='running',result=NULL WHERE stage='summary'")
        r = self.call('work')
        self.assertEqual((r['status'], r['coverage'], r['attempts']), ('unknown', 1, 3))
        self.assertEqual(len(self.effects()), 3)
        self.call('reconcile', stage='summary', item='__all__', state='failed',
                  evidence='receiver confirms aggregate rejected', result={'reason':'rejected'})
        self.assertEqual(self.call('work')['status'], 'incomplete')
        self.assertEqual(len(self.effects()), 3)

    def test_receiver_io_error_preserves_unknown_and_json_error_contract(self):
        self.submit()
        # A directory cannot accept an appended receipt. No external service needed.
        self.receipts.mkdir()
        self.call('work', expected=2)
        self.assertEqual((self.call('report')['status'], self.call('report')['attempts']), ('unknown', 1))
        self.assertEqual(self.call('work')['attempts'], 1)

    def test_cancelled_unknown_reconcile_does_not_resume(self):
        self.crash()
        self.call('cancel')
        self.reconcile()
        r = self.call('work')
        self.assertEqual((r['status'], r['attempts']), ('cancelled', 1))
        self.assertEqual(len(self.effects()), 1)
        self.call('resume')
        self.assertEqual(self.call('work')['attempts'], 3)

    def test_reconciliation_malformed_identity_is_json_error(self):
        self.crash()
        for stage, item in (([], 'a'), ('inspect', []), ('invalid', 'a'), ('inspect', '')):
            self.call('reconcile', stage=stage, item=item, state='succeeded', evidence='observed', expected=2)
        self.assertEqual(self.call('report')['status'], 'unknown')


if __name__ == '__main__':
    unittest.main(verbosity=2)
