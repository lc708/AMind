"""Persist an inspectable replay using only the public CLI and local receiver."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
RUN = Path(tempfile.mkdtemp(prefix='verified-replay-', dir=ROOT/'output'))
DB = RUN/'jobs.sqlite'
RECEIPTS = RUN/'receipts.jsonl'
results = {}


def invoke(label, request, expected=0):
    path = RUN/(label + '.request.json')
    path.write_text(json.dumps(request, indent=2))
    proc = subprocess.run([sys.executable, '-m', 'intake', '--db', str(DB), '--request', str(path),
                           '--receipts', str(RECEIPTS)], cwd=ROOT/'repo', capture_output=True, text=True, timeout=10)
    assert proc.returncode == expected, (proc.returncode, proc.stdout, proc.stderr)
    answer = json.loads(proc.stdout) if proc.stdout else None
    results[label] = {'exit':proc.returncode, 'report':answer}
    return answer


def request(op, job='INC-74', tenant='acme', **fields):
    return dict(op=op, job=job, tenant=tenant, **fields)


for filename in ('new-job.json', 'crash-job.json'):
    data = json.loads((ROOT/'repo'/'traces'/filename).read_text())
    invoke('submit-'+data['job'], data)
partial = invoke('partial', request('work', job='INC-73'))
assert partial['coverage'] == .5 and partial['attempts'] == 4
invoke('crash', request('work'), expected=17)
unknown = invoke('restored', request('work'))
assert unknown['status'] == 'unknown' and unknown['attempts'] == 1
before = len(RECEIPTS.read_text().splitlines())
invoke('restored-again', request('work'))
assert len(RECEIPTS.read_text().splitlines()) == before
invoke('submit-other-tenant', request('submit', tenant='other', spec={'items':[{'id':'delivery-A'}], 'max_attempts':3}))
invoke('wrong-tenant-reconcile', request('reconcile', tenant='other', stage='inspect', item='delivery-A',
                                       state='succeeded', result={'verified':True}, evidence='receipt'), expected=2)
invoke('reconciled', request('reconcile', stage='inspect', item='delivery-A', state='succeeded',
                             result={'verified':True}, evidence='local receipt matched by persisted operation_key'))
done = invoke('recovered', request('work'))
other = invoke('other-tenant-work', request('work', tenant='other'))
assert done['status'] == other['status'] == 'completed'
assert done['attempts'] == other['attempts'] == 3
assert done['rows'][0]['operation_key'] != other['rows'][0]['operation_key']
effects = [json.loads(line) for line in RECEIPTS.read_text().splitlines()]
keys = [r['operation_key'] for r in effects]
assert len(keys) == len(set(keys)) == 10
results['verification'] = {'receipts':len(effects), 'unique_operation_keys':len(set(keys)),
                           'crash_restart_extra_receipts':0, 'partial_coverage':partial['coverage']}
(RUN/'results.json').write_text(json.dumps(results, indent=2))
(ROOT/'output'/'latest-replay.json').write_text(json.dumps({'directory':RUN.name, **results['verification']}, indent=2))
print(json.dumps({'directory':str(RUN.relative_to(ROOT)), **results['verification']}, indent=2))
