# Incident 73 repair

The public `python -m intake --db ... --request ... --receipts ...` interface remains
unchanged. Runtime dependencies remain Python's standard library. No model,
network service, installed skill, or absolute filesystem path is required.

## Cause and changes

- The receiver was called before dispatch intent and its attempt were committed.
  A process exit after receipt delivery left a pending operation, which restart
  delivered again. `Store.claim` now atomically commits `running` and increments
  the cumulative attempt count **before** the receiver call. Exceptions and exits
  retain that unknown outcome; work never automatically retries it.
- `work` reset attempts and cancellation on every invocation. These resets are
  removed. Only `resume` clears cancellation, without changing the original
  budget. Report and identical resubmission leave both facts intact.
- The job lookup omitted tenant, and remote operation keys omitted tenant.
  Lookups now use both identities; new keys include tenant, job, stage and item.
  Existing keys are read from their stored rows and never regenerated on upgrade.
- The review dependency checks used `pass`, so review ran after unsuccessful or
  unknown inspection. Review now requires successful inspection. A failed
  inspection settles its review as `skipped`, with a reason and no dispatch or
  attempt charge. Running/pending dependencies remain blocked. Summary dispatch
  requires every item stage to be settled; known failures may be summarized.
- Coverage counted only inspection. It now requires successful inspection **and**
  review for each item in the immutable submitted population. Aggregate success
  cannot cover a failed item. Completion also requires a successful summary;
  an unknown summary is still unknown, and a failed summary is incomplete.
- Reconciliation previously accepted missing evidence and rewrote any work row.
  It now validates stage/item/outcome and nonblank external evidence, resolves
  only the exact tenant's existing running/unknown operation, and atomically
  retains result, evidence and the original operation key in `reconciliations`.
  Pending, nonexistent and settled work are rejected without changing state.
- Malformed request/spec/payload validation and local filesystem/database errors
  preserve the JSON error/exit-2 contract. The fixture's intentional process exit
  after an effect still exits 17.
- Immutable specification checks compare canonical JSON, preserving JSON value
  types (for example, `true` cannot silently become `1`) while ignoring object
  key order.

## Reproduction and evidence

Before the fix, replaying `traces/crash-job.json`, then issuing `work` twice,
exited 17 twice and appended two inspection receipts. The saved
`../output/baseline/results.json` records this and the other tenant receiving the
first tenant's population and attempt count. The saved partial-job replay also
shows a review dispatched for a failed inspection.

From the workspace root, run the full retained CLI replay:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 output/replay_incident.py
```

It submits both saved requests, verifies the intentional exit 17, restores twice,
reconciles against local receipt evidence, and finishes two tenants with the same
job number. Each run saves its requests, SQLite ledger, receipts and JSON reports
under `output/verified-replay-*`; `output/latest-replay.json` points to the latest
run. Verified result: **0 extra receipts on restart, 10 receipts with 10 distinct
operation keys, and 0.5 coverage for the partial population**.

For a direct CLI reproduction, use a fresh local fixture directory, submit
`traces/crash-job.json`, and save a request containing:

```json
{"op":"work","tenant":"acme","job":"INC-74"}
```

The first work call exits 17. The next exits 0 with status `unknown`, attempts 1,
and no new receipt. After checking the receipt, a reconciliation request is:

```json
{"op":"reconcile","tenant":"acme","job":"INC-74","stage":"inspect","item":"delivery-A","state":"succeeded","result":{"verified":true},"evidence":"local receiver receipt matched using the stored operation_key"}
```

A following work call finishes review and summary with cumulative attempts 3.

## Verification

From the workspace root (all temporary side effects remain in this workspace):

```sh
mkdir -p output/tmp
(cd repo && TMPDIR="$PWD/../output/tmp" PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -v)
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s output -p 'test_incident73.py' -v
```

The 3 unchanged public tests and 23 added CLI regressions pass. Regressions cover
healthy replay, immutable specifications, saved requests, inspection/review gaps,
unknown inspection/review/summary, both reconciliation outcomes, invalid and
repeated reconciliation, durable evidence, tenant isolation, cumulative budgets,
cancellation/resume, receiver I/O failure and opening an old-schema ledger while
preserving its original remote keys. Logs are in `../output/regressions.log` and
`../output/public-tests.log`. A separate copied-package smoke run verifies the
application can run independently of the workspace's skills and diagnostics.

## Limits and provenance

There is one local coordinator. Distributed coordination and concurrent workers
are outside this repair. A committed intent followed by interruption is
conservatively unknown even if the receiver was never reached. Reconciliation
requires operator-supplied external evidence; this application cannot verify its
truth. The fixture appends on every call and provides no remote deduplication, so
this fix prevents blind replay rather than promising remote exactly-once delivery.
Cancellation prevents new dispatches and cannot undo a started effect.

Old ledgers keep their existing remote keys, including any legacy cross-tenant
key collisions; changing those keys could duplicate already delivered effects.
The old worker could also leave already delivered work marked pending or erase
attempt history. Such lost historical facts cannot be reconstructed from the
ledger alone; this patch does not claim to repair them retroactively.

The durable intent/unknown-outcome/reconciliation ordering follows the local
AMind Engineering skill's `scripts/tool_loop.py` reference (Apache-2.0). The
application implementation is self-contained and imports no skill code.
