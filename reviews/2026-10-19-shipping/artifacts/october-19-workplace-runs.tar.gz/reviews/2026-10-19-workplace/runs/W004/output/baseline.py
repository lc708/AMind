import json, os, subprocess, sys
from pathlib import Path
root = Path(__file__).resolve().parents[1]
p = root / 'output' / 'baseline'
p.mkdir(exist_ok=True)
def call(op, tenant='acme', job='INC-73', **fields):
    req = p / 'request.json'
    req.write_text(json.dumps(dict(op=op, tenant=tenant, job=job, **fields)))
    r = subprocess.run([sys.executable, '-m', 'intake', '--db', str(p/'jobs.db'), '--request', str(req), '--receipts', str(p/'receipts.jsonl')], cwd=root/'repo', text=True, capture_output=True)
    return {'exit':r.returncode, 'stdout':r.stdout.strip()}
results = {}
results['submit'] = call('submit', **{'spec':json.loads((root/'repo/traces/new-job.json').read_text())['spec']})
results['partial'] = call('work')
results['crash_submit'] = call('submit', job='INC-74', spec=json.loads((root/'repo/traces/crash-job.json').read_text())['spec'])
results['crash'] = call('work', job='INC-74')
results['restart'] = call('work', job='INC-74')
results['other_tenant_submit'] = call('submit', tenant='other', spec={'items':[{'id':'other'}], 'max_attempts':1})
results['other_tenant_report'] = call('report', tenant='other')
results['receipt_count'] = len((p/'receipts.jsonl').read_text().splitlines())
(p/'results.json').write_text(json.dumps(results, indent=2))
print(json.dumps(results, indent=2))
