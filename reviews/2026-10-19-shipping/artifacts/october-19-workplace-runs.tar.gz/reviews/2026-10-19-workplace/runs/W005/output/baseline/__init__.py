"""Local release evidence dashboard."""
