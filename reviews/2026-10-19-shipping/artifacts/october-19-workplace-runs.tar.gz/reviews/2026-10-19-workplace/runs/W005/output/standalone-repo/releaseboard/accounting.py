"""Account every unique finished call, including failed calls and retries."""
from .validation import SCOPE, number, integer, text, exact_scope


def price(event, rates):
    """Return known reported spend or a complete, exactly scoped estimate."""
    if 'cost_usd' in event:
        value = event['cost_usd']
        return value if number(value) else None
    scope = event.get('billing_identity')
    if not exact_scope(scope) or event.get('all_billable_usage_included') is not True:
        return None
    matches = [r for r in rates.get('rates', [])
               if exact_scope(r.get('identity')) and r['identity'] == scope]
    # Ambiguous rate entries cannot establish a trustworthy price.
    if len(matches) != 1:
        return None
    rate, usage = matches[0], event.get('usage')
    if not isinstance(usage, dict):
        return None
    if rate.get('mode') == 'input_only':
        if (set(usage) != {'input_tokens'} or not integer(usage['input_tokens'])
                or not number(rate.get('input_per_million'))):
            return None
        try:
            cost = usage['input_tokens'] * rate['input_per_million'] / 1e6
        except OverflowError:
            return None
    elif rate.get('mode') == 'text':
        required = {'input_tokens', 'cached_input_tokens', 'output_tokens'}
        if (not required <= set(usage) or set(usage) - required - {'reasoning_tokens'}
                or not all(integer(v) for v in usage.values())):
            return None
        incoming, cached, outgoing = (usage[k] for k in ('input_tokens', 'cached_input_tokens', 'output_tokens'))
        if cached > incoming or usage.get('reasoning_tokens', 0) > outgoing:
            return None
        if not all(number(rate.get(k)) for k in ('input_per_million', 'cached_per_million', 'output_per_million')):
            return None
        try:
            cost = ((incoming - cached) * rate['input_per_million']
                    + cached * rate['cached_per_million']
                    + outgoing * rate['output_per_million']) / 1e6
        except OverflowError:
            return None
    else:
        return None
    return cost if number(cost) else None


def account(events, rates):
    starts, finishes, issues, matched = {}, {}, [], set()
    for event in events:
        kind, key = event.get('event'), event.get('attempt_id')
        if (kind not in ('started', 'finished') or not text(key)
                or not text(event.get('case_id')) or not integer(event.get('rep'))
                or (kind == 'finished' and not text(event.get('status')))):
            issues.append('invalid_attempt_event')
            continue
        bucket = starts if kind == 'started' else finishes
        if key in bucket:
            issues.append('duplicate_' + kind)
            continue  # The first append-only event owns the attempt; never double count.
        if kind == 'finished':
            prior = starts.get(key)
            if prior is None or any(prior[k] != event[k] for k in ('case_id', 'rep')):
                issues.append('unmatched_finished')
            else:
                matched.add(key)
        bucket[key] = event
    interrupted = len(set(starts) - matched)
    known, unknown = 0.0, interrupted
    for event in finishes.values():
        cost = price(event, rates)
        if cost is None:
            unknown += 1
        else:
            subtotal = known + cost
            if number(subtotal):
                known = subtotal
            else:
                unknown += 1
    attempts = {'started': len(starts), 'finished': len(finishes),
                'interrupted': interrupted,
                'failed': sum(e['status'] != 'ok' for e in finishes.values())}
    costs = {'known_usd': known, 'total_usd': None if unknown else known, 'unknown_attempts': unknown}
    return attempts, costs, issues
