"""Offline regression cases; every check exercises python -m releaseboard."""
import copy
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

WORKSPACE = Path(__file__).resolve().parent.parent
REPO = WORKSPACE / 'repo'
OUT = WORKSPACE / 'output'
FIXTURES = OUT / 'fixtures'
FIXTURES.mkdir(exist_ok=True)


class CLIIntegration(unittest.TestCase):
    def setUp(self):
        self.manifest = json.loads((REPO / 'examples/saved-run/manifest.json').read_text())
        self.rates = json.loads((REPO / 'examples/rates.json').read_text())
        self.results = [json.loads(s) for s in (REPO / 'examples/saved-run/results.jsonl').read_text().splitlines()]
        last = copy.deepcopy(self.results[0])
        last['case_id'] = 'account-recovery'
        last['result_identity']['case_id'] = 'account-recovery'
        self.results.append(last)
        self.events = []
        for index, cid in enumerate(self.manifest['case_ids']):
            start = dict(event='started', attempt_id=f'call-{index}', case_id=cid, rep=0)
            self.events.extend([start, dict(start, event='finished', status='ok', cost_usd=0.2)])
        self.calls = 0

    def run_cli(self, *, variant='candidate', expected_code=0):
        self.calls += 1
        folder = FIXTURES / f'{self._testMethodName}-{self.calls}'
        folder.mkdir(exist_ok=True)
        (folder / 'manifest.json').write_text(json.dumps(self.manifest))
        (folder / 'rates.json').write_text(json.dumps(self.rates))
        for name, rows in [('results', self.results), ('attempts', self.events)]:
            (folder / f'{name}.jsonl').write_text(''.join(json.dumps(row) + '\n' for row in rows))
        proc = subprocess.run([sys.executable, '-m', 'releaseboard', '--bundle', str(folder),
                               '--rates', str(folder / 'rates.json'), '--variant', variant],
                              cwd=REPO, text=True, capture_output=True)
        (folder / 'stdout.json').write_text(proc.stdout)
        (folder / 'stderr.txt').write_text(proc.stderr)
        self.assertEqual(proc.returncode, expected_code, proc.stdout + proc.stderr)
        self.assertEqual(proc.stderr, '')
        return json.loads(proc.stdout)

    def assert_hold(self, issue=None):
        report = self.run_cli()
        self.assertEqual(report['decision'], 'hold')
        if issue:
            self.assertEqual(report['integrity']['status'], 'invalid')
            self.assertIn(issue, report['integrity']['issues'])
        return report

    def test_complete_evidence_ready(self):
        report = self.run_cli()
        self.assertEqual(report['decision'], 'ready')
        self.assertEqual(report['missing'], [])
        self.assertEqual(report['coverage']['status'], 'complete')
        self.assertAlmostEqual(report['cost']['total_usd'], .6)

    def test_repetitions_and_multiple_metrics(self):
        self.manifest['repetitions'] = 2
        self.manifest['metrics'].append(dict(id='safety', min=0, max=1, min_mean=.9))
        for row in list(self.results):
            row['grade']['safety'] = 1
            second = copy.deepcopy(row)
            second['rep'] = second['result_identity']['rep'] = 1
            self.results.append(second)
        report = self.run_cli()
        self.assertEqual(report['planned_observations'], 6)
        self.assertEqual(report['scored_observations'], 6)
        self.assertEqual(report['metrics']['safety'], {'mean': 1, 'scored': 6})
        self.assertEqual(report['decision'], 'ready')

    def test_failed_case_and_metric_gate(self):
        self.results[-1]['status'] = 'timeout'
        report = self.assert_hold()
        self.assertEqual(report['missing'], [{'case_id': 'account-recovery', 'rep': 0}])
        self.results[-1]['status'] = 'ok'
        self.results[-1]['grade']['quality'] = 0
        report = self.assert_hold()
        self.assertEqual(report['missing'], [])
        self.assertLess(report['metrics']['quality']['mean'], .75)

    def test_variant_and_identity(self):
        self.assertEqual(self.run_cli(variant='other')['decision'], 'hold')
        for field in ['treatment_hash', 'comparison_hash', 'case_id', 'rep']:
            original = self.results[0]['result_identity'][field]
            self.results[0]['result_identity'][field] = 'wrong'
            report = self.assert_hold('result_identity_mismatch')
            self.assertEqual(report['scored_observations'], 2)
            self.results[0]['result_identity'][field] = original
        self.results[0]['result_identity']['rep'] = False
        self.assert_hold('result_identity_mismatch')

    def test_serving_scope(self):
        for field in self.manifest['expected_billing_identity']:
            original = self.results[0]['billing_identity'][field]
            self.results[0]['billing_identity'][field] = 'other'
            self.assert_hold('serving_identity_mismatch')
            self.results[0]['billing_identity'][field] = original

    def test_duplicate_and_unexpected_results(self):
        self.results.append(copy.deepcopy(self.results[0]))
        report = self.assert_hold('duplicate_result')
        self.assertEqual(report['scored_observations'], 2)
        self.results[-1]['case_id'] = 'unplanned'
        report = self.assert_hold('unexpected_result')
        self.assertEqual(report['scored_observations'], 3)
        self.results[-1]['case_id'] = []
        self.assert_hold('unexpected_result')
        self.results.pop()
        self.results[0]['rep'] = False
        self.assert_hold('unexpected_result')

    def test_invalid_grades(self):
        for grade in [{}, [], {'quality': True}, {'quality': 2}, {'quality': None}, {'quality': '1'},
                      {'quality': 1, 'extra': 1}]:
            self.results[0]['grade'] = grade
            report = self.assert_hold('invalid_grade')
            self.assertEqual(report['scored_observations'], 2)

    def test_failed_retry_spend_and_explicit_zero(self):
        start = dict(event='started', attempt_id='retry', case_id='order-return', rep=0)
        self.events.extend([start, dict(start, event='finished', status='error', cost_usd=.35)])
        self.events[1]['cost_usd'] = 0
        report = self.run_cli()
        self.assertEqual(report['attempts']['failed'], 1)
        self.assertAlmostEqual(report['cost']['known_usd'], .75)
        self.assertEqual(report['decision'], 'ready')

    def test_bad_explicit_cost_never_falls_back(self):
        for value in [None, True, -1, '0.1', {}, []]:
            self.events[1]['cost_usd'] = value
            self.events[1].update(billing_identity=self.manifest['expected_billing_identity'],
                                  usage=dict(input_tokens=10, cached_input_tokens=0, output_tokens=1),
                                  all_billable_usage_included=True)
            report = self.assert_hold()
            self.assertIsNone(report['cost']['total_usd'])
            self.assertAlmostEqual(report['cost']['known_usd'], .4)
            self.assertEqual(report['cost']['unknown_attempts'], 1)

    def test_interruption_and_unmatched_finish(self):
        self.events.pop()
        report = self.assert_hold()
        self.assertEqual(report['attempts']['interrupted'], 1)
        self.assertEqual(report['cost']['unknown_attempts'], 1)
        self.events.append(dict(self.events[-1], event='finished', status='error', cost_usd=.1,
                                case_id='wrong-case'))
        report = self.assert_hold('unmatched_finished')
        self.assertEqual(report['attempts']['interrupted'], 1)
        self.assertIsNone(report['cost']['total_usd'])
        self.events = self.events[1:]
        self.assert_hold('unmatched_finished')

    def test_duplicate_ledger_counts_once(self):
        baseline = self.run_cli()
        self.events.extend([dict(self.events[0]), dict(self.events[1], cost_usd=100)])
        report = self.assert_hold('duplicate_started')
        self.assertIn('duplicate_finished', report['integrity']['issues'])
        self.assertEqual(report['attempts'], baseline['attempts'])
        self.assertEqual(report['cost'], baseline['cost'])

    def use_estimate(self, mode='text'):
        event = self.events[1]
        del event['cost_usd']
        event['billing_identity'] = copy.deepcopy(self.manifest['expected_billing_identity'])
        event['all_billable_usage_included'] = True
        if mode == 'text':
            event['usage'] = dict(input_tokens=1000000, cached_input_tokens=200000,
                                  output_tokens=100000, reasoning_tokens=50000)
        else:
            event['billing_identity']['interface'] = 'decisions'
            event['usage'] = dict(input_tokens=1000000)
        return event

    def test_text_pricing_subsets_once(self):
        event = self.use_estimate()
        report = self.run_cli()
        self.assertAlmostEqual(report['cost']['known_usd'], 10.6)
        self.assertEqual(report['decision'], 'ready')
        event['status'] = 'error'
        self.assertAlmostEqual(self.run_cli()['cost']['known_usd'], 10.6)

    def test_input_only_integer_usage(self):
        event = self.use_estimate('input_only')
        self.assertAlmostEqual(self.run_cli()['cost']['known_usd'], 2.4)
        for usage in [dict(input_tokens=True), dict(input_tokens=1.5),
                      dict(input_tokens=3, output_tokens=0), dict(input_tokens=-1)]:
            event['usage'] = usage
            self.assertIsNone(self.assert_hold()['cost']['total_usd'])

    def test_estimate_requires_exact_scope_and_complete_usage(self):
        event = self.use_estimate()
        good = copy.deepcopy(event)
        for field in self.manifest['expected_billing_identity']:
            event['billing_identity'][field] = 'wrong'
            self.assertIsNone(self.assert_hold()['cost']['total_usd'])
            event['billing_identity'] = copy.deepcopy(good['billing_identity'])
        event['billing_identity']['extra'] = 'x'
        self.assert_hold()
        self.events[1] = event = copy.deepcopy(good)
        for flag in [False, None, 1, 'true']:
            event['all_billable_usage_included'] = flag
            self.assertIsNone(self.assert_hold()['cost']['total_usd'])
        event['all_billable_usage_included'] = True
        for usage in [dict(input_tokens=1, cached_input_tokens=2, output_tokens=1),
                      dict(input_tokens=1, cached_input_tokens=0, output_tokens=1, reasoning_tokens=2),
                      dict(input_tokens=1.0, cached_input_tokens=0, output_tokens=1),
                      dict(input_tokens=1, cached_input_tokens=0, output_tokens=1, native_cost=4), {}]:
            event['usage'] = usage
            self.assertIsNone(self.assert_hold()['cost']['total_usd'])

    def test_stage_coverage_contract(self):
        original = copy.deepcopy(self.results[0]['coverage'])
        bad_stages = [None, {}, {'stages': {}}, {'stages': []}]
        for field, value in [('total', 2), ('total', True), ('coverage', .99), ('coverage', True),
                             ('counts', {'succeeded': 3, 'failed': 1}),
                             ('counts', {'succeeded': 3, 'failed': -1}),
                             ('counts', {'succeeded': 3.0}), ('uncovered', ['worker-1'])]:
            cov = copy.deepcopy(original)
            cov['stages'][0][field] = value
            bad_stages.append(cov)
        cov = copy.deepcopy(original)
        cov['stages'].append(copy.deepcopy(cov['stages'][0]))
        bad_stages.append(cov)
        cov = copy.deepcopy(original)
        cov['stages'].append(dict(id='extra', total=1, coverage=1, counts={'succeeded': 1}, uncovered=[]))
        bad_stages.append(cov)
        for coverage in bad_stages:
            self.results[0]['coverage'] = coverage
            report = self.assert_hold()
            self.assertEqual(report['coverage']['status'], 'incomplete')
        self.results[0]['coverage'] = original
        del self.manifest['required_stages']
        self.assertEqual(self.assert_hold()['coverage']['status'], 'unmeasured')

    def test_malformed_contract_is_json_error(self):
        for key, value in [('case_ids', ['a', 'a']), ('repetitions', True), ('metrics', {}),
                           ('required_stages', []), ('expected_billing_identity', {}), ('release_id', None)]:
            old = self.manifest[key]
            self.manifest[key] = value
            report = self.run_cli(expected_code=2)
            self.assertIn('error', report)
            self.manifest[key] = old

    def test_bad_attempt_fields_hold_without_crashing(self):
        for field, value in [('event', []), ('attempt_id', []), ('case_id', []), ('rep', True), ('status', {})]:
            event = dict(self.events[1])
            event[field] = value
            self.events.append(event)
            self.assert_hold('invalid_attempt_event')
            self.events.pop()

    def test_empty_population_and_no_scores(self):
        self.results = []
        report = self.assert_hold()
        self.assertEqual(report['scored_observations'], 0)
        self.assertEqual(len(report['missing']), 3)
        self.assertIsNone(report['metrics']['quality']['mean'])

    def test_large_finite_grades_mean_without_overflow(self):
        self.manifest['metrics'][0].update(min=-1e308, max=1e308, min_mean=0)
        for row in self.results:
            row['grade']['quality'] = 1e308
        report = self.run_cli()
        self.assertEqual(report['metrics']['quality']['mean'], 1e308)
        self.assertEqual(report['decision'], 'ready')

    def test_unknown_rates_and_usage_remain_unknown(self):
        self.use_estimate()
        for mode in ['native', 'unsupported']:
            self.rates['rates'][0]['mode'] = mode
            self.assertIsNone(self.assert_hold()['cost']['total_usd'])
        self.rates['rates'] = []
        self.assertIsNone(self.assert_hold()['cost']['total_usd'])
        self.rates = {}
        self.assertIsNone(self.assert_hold()['cost']['total_usd'])

    def test_non_object_rows_are_json_error(self):
        self.results.append([])
        self.assertIn('error', self.run_cli(expected_code=2))


if __name__ == '__main__':
    unittest.main(verbosity=2)
