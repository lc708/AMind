"""Small schema checks shared by the local evidence readers."""
import math

SCOPE = {'provider', 'interface', 'model', 'service_tier', 'region'}


def finite(value):
    if type(value) not in (int, float):
        return False
    try:
        return math.isfinite(value)
    except OverflowError:
        return False


def number(value):
    return finite(value) and value >= 0


def integer(value):
    return type(value) is int and value >= 0


def text(value):
    return isinstance(value, str) and bool(value.strip())


def exact_scope(value):
    return isinstance(value, dict) and set(value) == SCOPE and all(text(v) for v in value.values())


def validate_inputs(manifest, results, events, rates):
    """Reject malformed containers/contracts; evidence conflicts become holds."""
    if not isinstance(manifest, dict):
        raise ValueError('manifest must be an object')
    for key in ('release_id', 'variant', 'split', 'comparison_hash', 'treatment_hash'):
        if not text(manifest.get(key)):
            raise ValueError('invalid manifest ' + key)
    ids, reps = manifest.get('case_ids'), manifest.get('repetitions')
    if (not isinstance(ids, list) or not all(text(cid) for cid in ids)
            or len(set(ids)) != len(ids) or not integer(reps) or reps < 1):
        raise ValueError('invalid planned population')
    metrics = manifest.get('metrics')
    if not isinstance(metrics, list) or not metrics:
        raise ValueError('metrics must be a nonempty list')
    seen = set()
    for metric in metrics:
        if (not isinstance(metric, dict) or not text(metric.get('id'))
                or metric['id'] in seen
                or not all(finite(metric.get(k)) for k in ('min', 'max', 'min_mean'))
                or metric['min'] > metric['max']):
            raise ValueError('invalid metric contract')
        seen.add(metric['id'])
    if 'expected_billing_identity' in manifest and not exact_scope(manifest['expected_billing_identity']):
        raise ValueError('invalid expected billing identity')
    stages = manifest.get('required_stages', {})
    if not isinstance(stages, dict) or not all(text(k) and integer(v) for k, v in stages.items()):
        raise ValueError('invalid stage contract')
    if not isinstance(results, list) or not isinstance(events, list):
        raise ValueError('results and attempts must be lists')
    if any(not isinstance(row, dict) for row in results + events):
        raise ValueError('result and attempt rows must be objects')
    if (not isinstance(rates, dict) or not isinstance(rates.get('rates', []), list)
            or any(not isinstance(row, dict) for row in rates.get('rates', []))):
        raise ValueError('invalid rate card')
