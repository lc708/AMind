"""Join the full planned population to compatible scores and call evidence."""
from statistics import mean
from .accounting import account
from .validation import finite, integer, text, validate_inputs


def stage_ok(report, contract):
    if not contract:
        return None
    stages = report.get('stages') if isinstance(report, dict) else None
    if not isinstance(stages, list):
        return False
    by_id = {}
    for stage in stages:
        if not isinstance(stage, dict) or not text(stage.get('id')) or stage['id'] in by_id:
            return False
        by_id[stage['id']] = stage
    if set(by_id) != set(contract):
        return False
    for key, total in contract.items():
        row = by_id[key]
        counts = row.get('counts')
        if (not integer(row.get('total')) or row['total'] != total
                or not finite(row.get('coverage')) or row['coverage'] != 1
                or row.get('uncovered') != [] or not isinstance(counts, dict)
                or not all(integer(v) for v in counts.values())
                or counts.get('succeeded') != total
                or any(v != 0 for k, v in counts.items() if k != 'succeeded')):
            return False
    return True


def build(manifest, results, events, rates, requested_variant):
    validate_inputs(manifest, results, events, rates)
    issues = []
    if requested_variant != manifest['variant']:
        issues.append('variant_mismatch')
    planned = [(cid, rep) for cid in manifest['case_ids'] for rep in range(manifest['repetitions'])]
    planned_set = set(planned)
    seen, accepted = set(), {}
    metric_ids = {m['id'] for m in manifest['metrics']}
    for row in results:
        if not text(row.get('case_id')) or not integer(row.get('rep')):
            issues.append('unexpected_result')
            continue
        key = (row['case_id'], row['rep'])
        if key in seen:
            issues.append('duplicate_result')
            accepted.pop(key, None)
            continue
        seen.add(key)
        if key not in planned_set:
            issues.append('unexpected_result')
            continue
        identity = {'comparison_hash': manifest['comparison_hash'], 'treatment_hash': manifest['treatment_hash'],
                    'case_id': key[0], 'rep': key[1]}
        actual = row.get('result_identity')
        if not isinstance(actual, dict) or actual != identity or type(actual.get('rep')) is not int:
            issues.append('result_identity_mismatch')
            continue
        pin = manifest.get('expected_billing_identity')
        if pin is not None and row.get('billing_identity') != pin:
            issues.append('serving_identity_mismatch')
            continue
        if not text(row.get('status')):
            issues.append('invalid_result_status')
            continue
        if row['status'] != 'ok':
            continue
        grade = row.get('grade')
        valid = isinstance(grade, dict) and set(grade) == metric_ids
        if valid:
            valid = all(finite(grade[m['id']]) and m['min'] <= grade[m['id']] <= m['max']
                        for m in manifest['metrics'])
        if not valid:
            issues.append('invalid_grade')
            continue
        accepted[key] = row
    missing = [{'case_id': cid, 'rep': rep} for cid, rep in planned if (cid, rep) not in accepted]
    metrics = {}
    for metric in manifest['metrics']:
        values = [row['grade'][metric['id']] for row in accepted.values()]
        # statistics.mean preserves finite means even when the raw sum overflows.
        average = mean(values) if values else None
        metrics[metric['id']] = {'mean': average, 'scored': len(values)}
    attempts, cost, ledger_issues = account(events, rates)
    issues.extend(ledger_issues)
    contract = manifest.get('required_stages', {})
    stage_states = [stage_ok(row.get('coverage'), contract) for row in accepted.values()]
    coverage = ('unmeasured' if not contract else
                'complete' if not missing and stage_states and all(stage_states) else 'incomplete')
    quality = all(metrics[m['id']]['mean'] is not None and metrics[m['id']]['mean'] >= m['min_mean']
                  for m in manifest['metrics'])
    ready = not issues and not missing and quality and cost['total_usd'] is not None and coverage == 'complete'
    return {'release_id': manifest['release_id'], 'variant': requested_variant, 'split': manifest['split'],
            'planned_observations': len(planned), 'scored_observations': len(accepted), 'missing': missing,
            'metrics': metrics, 'attempts': attempts, 'cost': cost, 'coverage': {'status': coverage},
            'integrity': {'status': 'invalid' if issues else 'verified', 'issues': sorted(set(issues))},
            'decision': 'ready' if ready else 'hold'}
