"""Build one release dashboard JSON from saved local evidence."""
import argparse
import json
from pathlib import Path
from .report import build


def reject_constant(value):
    raise ValueError('invalid JSON constant: ' + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('duplicate JSON key: ' + key)
        result[key] = value
    return result


def loads(value):
    return json.loads(value, parse_constant=reject_constant, object_pairs_hook=unique_object)


def jsonl(path):
    return [loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line.strip()]


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--bundle', required=True, type=Path)
    p.add_argument('--rates', required=True, type=Path)
    p.add_argument('--variant', required=True)
    a = p.parse_args()
    try:
        manifest = loads((a.bundle / 'manifest.json').read_text(encoding='utf-8'))
        report = build(manifest, jsonl(a.bundle / 'results.jsonl'), jsonl(a.bundle / 'attempts.jsonl'),
                       loads(a.rates.read_text(encoding='utf-8')), a.variant)
        print(json.dumps(report, allow_nan=False))
        return 0
    except (OSError, UnicodeError, ValueError, KeyError, TypeError, OverflowError) as exc:
        print(json.dumps({'error': str(exc)}))
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
