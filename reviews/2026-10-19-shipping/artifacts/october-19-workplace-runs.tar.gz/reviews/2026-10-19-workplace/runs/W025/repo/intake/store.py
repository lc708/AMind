"""Durable local ledger (stdlib SQLite).

Dispatch-before-effect and evidence-based recovery follow the EffectLedger pattern
in amind-engineering/scripts/tool_loop.py (Apache-2.0); implemented locally so
this application has no runtime dependency on the skill installation.
"""
import hashlib
import json
import sqlite3


def packed(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def operation_key(tenant, job, stage, item):
    return hashlib.sha256(packed(['intake-v2', tenant, job, stage, item]).encode()).hexdigest()


class Store:
    def __init__(self, path):
        self.db = sqlite3.connect(str(path), isolation_level=None)
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('PRAGMA synchronous=FULL')
        self.db.execute('CREATE TABLE IF NOT EXISTS jobs(tenant TEXT,job TEXT,spec TEXT,cancelled INTEGER,attempts INTEGER,PRIMARY KEY(tenant,job))')
        self.db.execute('CREATE TABLE IF NOT EXISTS work(tenant TEXT,job TEXT,stage TEXT,item TEXT,state TEXT,result TEXT,operation_key TEXT,PRIMARY KEY(tenant,job,stage,item))')
        # Additive migration: never replace the remote keys of existing work.
        self.db.execute('CREATE TABLE IF NOT EXISTS reconciliations(tenant TEXT,job TEXT,stage TEXT,item TEXT,state TEXT,result TEXT,evidence TEXT,PRIMARY KEY(tenant,job,stage,item))')

    def close(self):
        self.db.close()

    def job(self, tenant, job):
        row = self.db.execute('SELECT spec,cancelled,attempts FROM jobs WHERE tenant=? AND job=?', (tenant, job)).fetchone()
        if row is None:
            raise ValueError('job not found for tenant')
        return {'spec': json.loads(row[0]), 'cancelled': bool(row[1]), 'attempts': row[2]}

    def rows(self, tenant, job):
        return [dict(zip(('stage', 'item', 'state', 'result', 'operation_key'), r))
                for r in self.db.execute('SELECT stage,item,state,result,operation_key FROM work WHERE tenant=? AND job=? ORDER BY rowid', (tenant, job))]

    def update(self, tenant, job, stage, item, state, result=None):
        self.db.execute('UPDATE work SET state=?,result=? WHERE tenant=? AND job=? AND stage=? AND item=?',
                        (state, packed(result), tenant, job, stage, item))

    def reconcile(self, tenant, job, stage, item, state, result, evidence):
        if state not in ('succeeded', 'failed') or not isinstance(evidence, str) or not evidence.strip():
            raise ValueError('external outcome and nonempty evidence required')
        if not isinstance(stage, str) or not isinstance(item, str):
            raise ValueError('stage and item identity required')
        encoded = packed(result)
        self.db.execute('BEGIN IMMEDIATE')
        try:
            changed = self.db.execute("UPDATE work SET state=?,result=? WHERE tenant=? AND job=? AND stage=? AND item=? AND state IN ('running','unknown')",
                                      (state, encoded, tenant, job, stage, item)).rowcount
            if changed != 1:
                raise ValueError('exactly one unknown operation required')
            self.db.execute('INSERT INTO reconciliations VALUES(?,?,?,?,?,?,?)',
                            (tenant, job, stage, item, state, encoded, evidence))
            self.db.execute('COMMIT')
        except BaseException:
            self.db.execute('ROLLBACK')
            raise
