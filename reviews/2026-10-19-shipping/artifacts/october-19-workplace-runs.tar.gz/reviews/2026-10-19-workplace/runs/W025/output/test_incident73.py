"""Offline regressions through the public CLI; all artifacts remain in output/."""
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT / 'repo'
ARTIFACTS = ROOT / 'output'


class Incident73(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(dir=ARTIFACTS / 'tmp')
        self.path = Path(self.tmp.name)
        self.receipts = self.path / 'receipts.jsonl'
        self.db = self.path / 'jobs.db'

    def tearDown(self):
        self.tmp.cleanup()

    def call(self, op, tenant='acme', job='J1', expect=0, **extra):
        request = self.path / 'request.json'
        request.write_text(json.dumps(dict(op=op, tenant=tenant, job=job, **extra)))
        run = subprocess.run([sys.executable, '-B', '-m', 'intake', '--db', str(self.db),
                              '--request', str(request), '--receipts', str(self.receipts)],
                             cwd=REPO, capture_output=True, text=True, timeout=10)
        self.assertEqual(run.returncode, expect, run.stdout + run.stderr)
        return json.loads(run.stdout) if run.stdout else None

    def submit(self, items=None, limit=8, **extra):
        return self.call('submit', spec={'items': items or [{'id': 'a'}], 'max_attempts': limit}, **extra)

    def effects(self):
        return [json.loads(s) for s in self.receipts.read_text().splitlines()] if self.receipts.exists() else []

    def test_success_restart_and_resubmit_are_noops(self):
        original = self.submit()
        result = self.call('work')
        self.assertEqual((result['status'], result['coverage'], result['attempts']), ('completed', 1, 3))
        self.assertEqual(self.call('work'), result)
        self.assertEqual(self.submit(), result)
        self.assertEqual(len(self.effects()), 3)
        self.assertEqual([r['operation_key'] for r in original['rows']], [r['operation_key'] for r in result['rows']])

    def test_failed_inspection_skips_review_and_preserves_summary_gap(self):
        saved = json.loads((REPO / 'traces/new-job.json').read_text())
        self.call('submit', job=saved['job'], spec=saved['spec'])
        result = self.call('work', job=saved['job'])
        self.assertEqual((result['status'], result['coverage'], result['attempts']), ('incomplete', .5, 4))
        self.assertEqual(result['covered_ids'], ['invoice-A'])
        self.assertEqual(result['uncovered_ids'], ['invoice-B'])
        self.assertFalse(any(r['stage'] == 'review' and r['item'] == 'invoice-B' for r in self.effects()))
        summary = self.effects()[-1]
        self.assertEqual(summary['stage'], 'summary')
        self.assertEqual(summary['coverage']['coverage'], .5)
        self.assertEqual(summary['coverage']['uncovered_ids'], ['invoice-B'])
        self.call('work', job=saved['job'])
        self.assertEqual(len(self.effects()), 4)

    def test_failed_review_is_a_gap(self):
        self.submit([{'id': 'a', 'payload': {'review': 'fail'}}])
        r = self.call('work')
        self.assertEqual((r['status'], r['coverage'], r['uncovered_ids']), ('incomplete', 0, ['a']))
        self.assertEqual(self.effects()[-1]['coverage']['coverage'], 0)
        self.call('work')
        self.assertEqual(len(self.effects()), 3)

    def crash(self, stage='inspect', **extra):
        self.submit([{'id': 'a', 'payload': {'crash_after_effect': stage}}], **extra)
        self.call('work', expect=17, **extra)
        r = self.call('report', **extra)
        self.assertEqual(r['status'], 'unknown')
        count = 1 if stage == 'inspect' else 2
        self.assertEqual((r['attempts'], len(self.effects())), (count, count))
        self.assertEqual(self.call('work', **extra), r)
        self.assertEqual(len(self.effects()), count)
        return r

    def test_saved_crash_request_no_replay(self):
        saved = json.loads((REPO / 'traces/crash-job.json').read_text())
        self.call('submit', job=saved['job'], spec=saved['spec'])
        self.call('work', job=saved['job'], expect=17)
        before = self.call('report', job=saved['job'])
        self.assertEqual((before['status'], before['attempts']), ('unknown', 1))
        self.assertEqual(self.call('work', job=saved['job']), before)
        self.assertEqual(len(self.effects()), 1)

    def test_reconcile_inspection_then_continue(self):
        r = self.crash()
        key = r['rows'][0]['operation_key']
        self.call('reconcile', stage='inspect', item='a', state='succeeded', result={'delivered': True}, evidence='receipt line 1')
        r = self.call('work')
        self.assertEqual((r['status'], r['attempts']), ('completed', 3))
        self.assertEqual(r['rows'][0]['operation_key'], key)
        self.assertEqual(len(self.effects()), 3)
        with sqlite3.connect(self.db) as db:
            self.assertEqual(db.execute('SELECT evidence FROM reconciliations').fetchone()[0], 'receipt line 1')

    def test_review_crash_blocks_summary(self):
        self.crash('review')
        self.assertFalse(any(r['stage'] == 'summary' for r in self.effects()))
        self.call('reconcile', stage='review', item='a', state='failed', result='receiver failure', evidence='receipt review')
        r = self.call('work')
        self.assertEqual((r['status'], r['coverage'], r['attempts']), ('incomplete', 0, 3))

    def test_reconciliation_rejects_missing_evidence_and_settled_work(self):
        self.crash()
        for evidence in (None, '', ' ', 123, {}):
            self.call('reconcile', stage='inspect', item='a', state='succeeded', evidence=evidence, expect=2)
        self.call('reconcile', stage='review', item='a', state='succeeded', evidence='not dispatched', expect=2)
        self.call('reconcile', stage='inspect', item='absent', state='succeeded', evidence='wrong item', expect=2)
        self.call('reconcile', stage='inspect', item='a', state='pending', evidence='bad state', expect=2)
        self.call('reconcile', stage='inspect', item='a', state='failed', evidence='confirmed failure')
        settled = self.call('report')
        self.call('reconcile', stage='inspect', item='a', state='succeeded', evidence='rewrite', expect=2)
        self.assertEqual(self.call('report'), settled)

    def test_budget_is_cumulative_across_work_report_and_resume(self):
        self.submit(limit=1)
        first = self.call('work')
        self.assertEqual((first['attempts'], first['remaining_attempts'], len(self.effects())), (1, 0, 1))
        self.assertEqual(self.call('work'), first)
        self.assertEqual(self.submit(limit=1), first)
        self.call('cancel')
        self.call('resume')
        self.assertEqual(self.call('work'), first)
        self.assertEqual(len(self.effects()), 1)

    def test_cancel_survives_restart_work_and_submit(self):
        self.submit()
        cancelled = self.call('cancel')
        self.assertEqual(self.call('work'), cancelled)
        self.assertEqual(self.submit(), cancelled)
        self.assertEqual(self.effects(), [])
        self.call('resume')
        self.assertEqual(self.call('work')['status'], 'completed')

    def test_same_job_different_tenants_are_isolated(self):
        a = self.submit([{'id': 'a', 'payload': {'crash_after_effect': 'inspect'}}])
        b = self.submit([{'id': 'b'}], limit=3, tenant='other')
        self.assertTrue(set(r['operation_key'] for r in a['rows']).isdisjoint(r['operation_key'] for r in b['rows']))
        self.call('work', expect=17)
        self.call('reconcile', tenant='other', stage='inspect', item='a', state='succeeded', evidence='foreign', expect=2)
        self.call('cancel', tenant='other')
        self.assertFalse(self.call('report')['cancelled'])
        self.assertEqual(self.call('report', tenant='other')['uncovered_ids'], ['b'])
        self.call('resume', tenant='other')
        r = self.call('work', tenant='other')
        self.assertEqual((r['status'], r['attempts']), ('completed', 3))
        self.assertEqual(self.call('report')['status'], 'unknown')
        self.call('report', tenant='missing', expect=2)

    def test_same_coordinates_have_distinct_remote_keys(self):
        a = self.submit()
        b = self.submit(tenant='other')
        self.assertTrue(all(x['operation_key'] != y['operation_key'] for x, y in zip(a['rows'], b['rows'])))

    def test_changed_population_payload_budget_are_rejected(self):
        self.submit()
        for spec in ({'items': [{'id': 'b'}], 'max_attempts': 8},
                     {'items': [{'id': 'a', 'payload': {'inspect': 'fail'}}], 'max_attempts': 8},
                     {'items': [{'id': 'a'}], 'max_attempts': 9}):
            self.call('submit', spec=spec, expect=2)
        self.assertEqual(self.call('report')['attempts'], 0)

    def test_legacy_keys_and_unknown_state_survive_upgrade(self):
        self.submit()
        old_key = hashlib.sha256(b'["J1","inspect","a"]').hexdigest()
        with sqlite3.connect(self.db) as db:
            db.execute('DROP TABLE reconciliations')
            db.execute("UPDATE work SET operation_key=?,state='running' WHERE stage='inspect'", (old_key,))
            db.execute('UPDATE jobs SET attempts=1')
        r = self.call('work')
        self.assertEqual((r['status'], r['attempts'], self.effects()), ('unknown', 1, []))
        self.assertEqual(r['rows'][0]['operation_key'], old_key)
        self.call('reconcile', stage='inspect', item='a', state='succeeded', evidence='legacy receipt')
        self.assertEqual(self.call('work')['status'], 'completed')
        self.assertEqual(self.call('report')['rows'][0]['operation_key'], old_key)

    def test_unknown_summary_never_replays_and_failure_is_not_completed(self):
        self.submit()
        self.call('work')
        with sqlite3.connect(self.db) as db:
            db.execute("UPDATE work SET state='running' WHERE stage='summary'")
        r = self.call('work')
        self.assertEqual((r['status'], r['coverage'], r['attempts']), ('unknown', 1, 3))
        self.assertEqual(len(self.effects()), 3)
        self.call('reconcile', stage='summary', item='__all__', state='failed', evidence='receiver confirms failure')
        self.assertEqual(self.call('work')['status'], 'incomplete')
        self.assertEqual(len(self.effects()), 3)

    def test_summary_crash_is_durable(self):
        self.submit([{'id': 'a', 'payload': {'crash_after_effect': 'summary'}}])
        self.call('work', expect=17)
        r = self.call('report')
        self.assertEqual((r['status'], r['attempts'], r['coverage']), ('unknown', 3, 1))
        self.assertEqual(self.call('work'), r)
        self.assertEqual(len(self.effects()), 3)
        self.call('reconcile', stage='summary', item='__all__', state='succeeded', evidence='summary receipt')
        self.assertEqual(self.call('work')['status'], 'completed')

    def test_null_payload_remains_healthy(self):
        self.submit([{'id': 'a', 'payload': None}])
        self.assertEqual(self.call('work')['status'], 'completed')

    def test_receiver_io_failure_leaves_unknown_not_retriable(self):
        self.submit()
        self.receipts.mkdir()
        self.call('work', expect=2)
        self.receipts.rmdir()
        r = self.call('work')
        self.assertEqual((r['status'], r['attempts'], self.effects()), ('unknown', 1, []))

    def test_invalid_specifications_are_cli_errors(self):
        for spec in (None, [], {'items': [], 'max_attempts': 8},
                     {'items': [{'id': 'a'}, {'id': 'a'}], 'max_attempts': 8},
                     {'items': [{'id': '__all__'}], 'max_attempts': 8},
                     {'items': [{'id': 'a', 'payload': []}], 'max_attempts': 8},
                     {'items': [{'id': 'a'}], 'max_attempts': True}):
            self.call('submit', spec=spec, expect=2)


if __name__ == '__main__':
    unittest.main(verbosity=2)
