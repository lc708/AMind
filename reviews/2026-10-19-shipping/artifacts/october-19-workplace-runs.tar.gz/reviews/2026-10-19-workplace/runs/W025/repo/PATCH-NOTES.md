# Incident 73 repair

The intake worker now commits its operation state and cumulative attempt charge
before calling the simulated receiver. A process exit leaves `running`, which the
report exposes as `unknown`; a restart does not dispatch that operation again.
Successful and failed outcomes are terminal. Receipt contexts retain the original
operation key and the complete population's inspection/review coverage.

## Causes and changes

- Previously the receipt was written before the dispatch record. A crash in that
  interval left pending work that was replayed. Dispatch and attempt accounting
  now commit together before the effect, using SQLite WAL and FULL synchronous
  durability. Receiver exceptions also leave an unknown outcome.
- Work previously reset attempts and cancellation on every invocation. Neither
  now resets; only explicit resume clears cancellation, under the same budget.
- Job reads previously selected by job number alone. Reads, writes, reconciliation
  and remote operation keys now include trusted tenant identity. New keys use a
  versioned, canonical identity hash; existing stored keys are never rewritten.
- Dependency checks previously fell through. Review requires a successful
  inspection. Failed inspections cause a terminal `skipped` review without a
  receiver call or budget charge. Summary waits until every submitted item's
  two stages have known terminal outcomes. Independent items can still progress
  while another item is unknown.
- Coverage previously counted inspection alone. Both item stages must succeed.
  Failed inspections/reviews remain uncovered even after successful summary
  delivery. Completed status also requires a successful summary.
- Reconciliation previously accepted any row without evidence. It now atomically
  settles only an existing running/unknown operation, requires nonblank external
  evidence and a succeeded/failed outcome, and persists evidence and result in
  an additive reconciliation table. Settled and pending work cannot be rewritten.
- Malformed requests/payloads produce the CLI error envelope; omitted/null item
  payloads remain supported. Local receiver I/O errors also return exit 2 while
  retaining the unknown dispatch. The summary crash fixture can be requested with
  an item's `crash_after_effect: "summary"`, as with inspect and review.

The CLI flags, JSON report fields, stage names, saved requests and stdlib-only
runtime remain available. No skill, provider service or absolute installation
path is needed to run the delivered `repo/`.

## Reproduction and verification

From the workspace root, run:

```sh
python3 -B output/verify.py
python3 -B skills/amind-engineering/scripts/lifecycle_audit.py output/lifecycle-events.jsonl
```

The first command executes the original public suite and the additional CLI
regressions, then replays both saved requests against a local JSONL receiver.
Its retained `output/replay/request-*.json` files can also be invoked individually
with `python3 -m intake --db ... --request ... --receipts ...` from `repo/`.
All verification effects and temporary files are confined to `output/`.

Expected evidence:

- Original public tests: 3 passing; additional regressions: 18 passing.
- Crash after an inspection receipt: exit 17, attempts 1, report unknown; repeated
  work sends no second receipt. Evidence-based reconciliation permits remaining
  dependent work without replaying the original effect.
- The saved incident 73 request ends incomplete with coverage 0.5 and
  `invoice-B` uncovered. It sends four receipts, without reviewing the failed
  inspection. Its summary receipt includes the same gap.
- The retained combined replay has nine receiver calls and nine unique keys,
  including two tenants sharing one job number. Tests additionally cover review
  and summary crashes, rejected reconciliation, budget exhaustion, durable cancel,
  immutable resubmission, receiver I/O failure and legacy database/key retention.

`output/verification.json`, test logs, replay reports, SQLite state and receipts
retain the concrete results. The lifecycle audit uses normalized observed fixture
facts; it is a secondary diagnostic, not a replacement for the CLI assertions.

## Limits

This is a single-coordinator local workflow, not distributed locking or remote
exactly-once delivery. A committed dispatch can be unknown even if a crash happened
before the receiver call. Resolving unknown work requires trusted external
evidence; the application validates and stores that evidence but cannot prove it.
Cancellation cannot undo an effect already dispatched. Failed/skipped work is not
automatically retried, and exhaustion does not reset a job's immutable budget.

The additive upgrade preserves recorded historical keys, attempts and states,
including unresolved legacy operations. It cannot reconstruct a pre-fix receipt
that was never recorded in SQLite, undo historical duplicates, or make historical
cross-tenant keys distinct. Operators must inspect old receiver records before
running legacy pending work when that pre-fix crash window may have occurred.

The transaction/evidence design was informed by the Apache-2.0 standard-library
EffectLedger reference in `amind-engineering/scripts/tool_loop.py`; this repository
contains its own implementation and has no runtime import from the skill.
