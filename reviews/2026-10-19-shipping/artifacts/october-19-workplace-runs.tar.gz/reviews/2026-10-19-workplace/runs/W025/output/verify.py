"""Repeatable offline verification; run: python3 -B output/verify.py."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT / 'repo'
OUT = ROOT / 'output'
TMP = OUT / 'tmp'
TMP.mkdir(exist_ok=True)
env = dict(os.environ, TMPDIR=str(TMP), PYTHONDONTWRITEBYTECODE='1')
results = {}
for name, args in [('public', ['-m', 'unittest', 'discover', '-s', 'tests', '-v']),
                   ('regressions', [str(OUT / 'test_incident73.py')])]:
    run = subprocess.run([sys.executable, '-B', *args], cwd=REPO, env=env, capture_output=True, text=True, timeout=60)
    (OUT / (name + '-tests.log')).write_text(run.stdout + run.stderr)
    results[name] = {'exit_code': run.returncode, 'log': name + '-tests.log'}
    assert run.returncode == 0, run.stdout + run.stderr

fixture = OUT / 'replay'
if fixture.exists():
    shutil.rmtree(fixture)
fixture.mkdir()
journal = []
commands = []


def invoke(op, tenant='acme', job='INC-74', expect=0, **extra):
    request = dict(op=op, tenant=tenant, job=job, **extra)
    request_path = fixture / ('request-%02d.json' % len(commands))
    request_path.write_text(json.dumps(request, indent=2))
    run = subprocess.run([sys.executable, '-B', '-m', 'intake', '--db', str(fixture / 'jobs.sqlite'),
                          '--request', str(request_path), '--receipts', str(fixture / 'receipts.jsonl')],
                         cwd=REPO, env=env, capture_output=True, text=True, timeout=10)
    answer = json.loads(run.stdout) if run.stdout else None
    commands.append({'request': request, 'exit_code': run.returncode, 'report': answer, 'stderr': run.stderr})
    assert run.returncode == expect, commands[-1]
    return answer


crash = json.loads((REPO / 'traces/crash-job.json').read_text())
invoke(**crash)
invoke('work', expect=17)
unknown = invoke('report')
assert unknown['status'] == 'unknown' and unknown['attempts'] == 1
assert invoke('work') == unknown
receipt = json.loads((fixture / 'receipts.jsonl').read_text().splitlines()[0])
invoke('reconcile', stage='inspect', item='delivery-A', state='succeeded', result=receipt['outcome']['output'],
       evidence='local receiver receipts.jsonl line 1; operation_key=' + receipt['operation_key'])
assert invoke('work')['status'] == 'completed'
assert invoke('work')['attempts'] == 3
# Same coordinates on another tenant must produce distinct remote identities.
invoke('submit', tenant='other', spec=crash['spec'])
invoke('work', tenant='other', expect=17)
other = invoke('report', tenant='other')
assert other['rows'][0]['operation_key'] != unknown['rows'][0]['operation_key']
other_receipt = json.loads((fixture / 'receipts.jsonl').read_text().splitlines()[-1])
invoke('reconcile', tenant='other', stage='inspect', item='delivery-A', state='failed', result=other_receipt['outcome']['output'],
       evidence='operator confirmed failed outcome; receipt line 4; key=' + other_receipt['operation_key'])
assert invoke('work', tenant='other')['status'] == 'incomplete'
gap = json.loads((REPO / 'traces/new-job.json').read_text())
invoke(**gap)
gap_report = invoke('work', job=gap['job'])
assert gap_report['coverage'] == .5 and gap_report['uncovered_ids'] == ['invoice-B']
assert invoke('work', job=gap['job']) == gap_report
receipts = [json.loads(line) for line in (fixture / 'receipts.jsonl').read_text().splitlines()]
assert len(receipts) == 9
assert len({r['operation_key'] for r in receipts}) == len(receipts)
# Normalize observed CLI/receiver facts for the engineering lifecycle audit.
for tenant, job in dict.fromkeys((r['tenant'], r['job']) for r in receipts):
    def event(kind, **fields):
        journal.append(dict(id='event-%d' % len(journal), tenant_id=tenant, task_id=job, kind=kind, **fields))
    event('task_started')
    for receipt in (r for r in receipts if r['tenant'] == tenant and r['job'] == job):
        key = receipt['operation_key']
        event('effect_started', idempotency_key=key)
        crash_effect = receipt['payload'].get('crash_after_effect') == receipt['stage']
        event('effect_reconciled' if crash_effect else 'effect_' + receipt['outcome']['status'], idempotency_key=key)
    final = next(c['report'] for c in reversed(commands) if c['report'] and c['request']['tenant'] == tenant and c['request']['job'] == job)
    event('task_completed' if final['status'] == 'completed' else 'task_failed')
(OUT / 'lifecycle-events.jsonl').write_text(''.join(json.dumps(e) + '\n' for e in journal))
(fixture / 'commands.json').write_text(json.dumps(commands, indent=2))
results['replay'] = {'exit_code': 0, 'receiver_calls': len(receipts), 'unique_operation_keys': len({r['operation_key'] for r in receipts}),
                     'restored_crash_attempts': unknown['attempts'], 'gap_coverage': gap_report['coverage'],
                     'commands': 'replay/commands.json', 'receipts': 'replay/receipts.jsonl'}
(OUT / 'verification.json').write_text(json.dumps(results, indent=2))
print(json.dumps(results, indent=2))
