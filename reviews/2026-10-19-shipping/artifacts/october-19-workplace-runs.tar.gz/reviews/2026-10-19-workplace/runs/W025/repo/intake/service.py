import json
from .store import operation_key, packed
from .receiver import perform

STAGES = ('inspect', 'review', 'summary')
UNKNOWN = ('running', 'unknown')
SETTLED = ('succeeded', 'failed', 'skipped')


def validate(spec):
    if not isinstance(spec, dict):
        raise ValueError('job specification must be an object')
    items = spec.get('items')
    limit = spec.get('max_attempts')
    if not isinstance(items, list) or not items:
        raise ValueError('nonempty item population required')
    ids = [i.get('id') for i in items if isinstance(i, dict)]
    if len(ids) != len(items) or any(not isinstance(i, str) or not i or i == '__all__' for i in ids) or len(set(ids)) != len(ids):
        raise ValueError('unique item IDs required')
    if any(i.get('payload') is not None and not isinstance(i.get('payload'), dict) for i in items):
        raise ValueError('item payload must be an object')
    if type(limit) is not int or limit < 1:
        raise ValueError('positive max_attempts required')
    packed(spec)
    return spec


def report(store, tenant, job):
    entry = store.job(tenant, job)
    rows = store.rows(tenant, job)
    population = [i['id'] for i in entry['spec']['items']]
    states = {(r['stage'], r['item']): r['state'] for r in rows}
    covered = [i for i in population if all(states.get((stage, i)) == 'succeeded' for stage in ('inspect', 'review'))]
    expected = [(stage, i) for stage in ('inspect', 'review') for i in population] + [('summary', '__all__')]
    unknown = any(r['state'] in UNKNOWN for r in rows)
    pending = any(states.get(key, 'pending') == 'pending' for key in expected)
    completed = len(covered) == len(population) and states.get(('summary', '__all__')) == 'succeeded'
    status = 'unknown' if unknown else ('pending' if pending else ('completed' if completed else 'incomplete'))
    if entry['cancelled']:
        status = 'cancelled'
    return {'tenant': tenant, 'job': job, 'status': status, 'attempts': entry['attempts'],
            'remaining_attempts': max(0, entry['spec']['max_attempts'] - entry['attempts']),
            'coverage': len(covered) / len(population), 'covered_ids': covered,
            'uncovered_ids': [i for i in population if i not in covered],
            'cancelled': entry['cancelled'], 'rows': rows}


def submit(store, tenant, job, spec):
    spec = validate(spec)
    store.db.execute('BEGIN IMMEDIATE')
    try:
        old = store.db.execute('SELECT spec FROM jobs WHERE tenant=? AND job=?', (tenant, job)).fetchone()
        if old:
            if packed(json.loads(old[0])) != packed(spec):
                raise ValueError('immutable job specification differs')
        else:
            store.db.execute('INSERT INTO jobs VALUES(?,?,?,0,0)', (tenant, job, packed(spec)))
            for stage in STAGES:
                for item in (['__all__'] if stage == 'summary' else [i['id'] for i in spec['items']]):
                    store.db.execute('INSERT INTO work VALUES(?,?,?,?,?,?,?)',
                                     (tenant, job, stage, item, 'pending', None, operation_key(tenant, job, stage, item)))
        store.db.execute('COMMIT')
    except BaseException:
        store.db.execute('ROLLBACK')
        raise
    return report(store, tenant, job)


def claim(store, tenant, job, stage, item):
    """Commit the dispatch and its budget before crossing the receiver boundary."""
    store.db.execute('BEGIN IMMEDIATE')
    try:
        entry = store.job(tenant, job)
        rows = store.rows(tenant, job)
        states = {(r['stage'], r['item']): r['state'] for r in rows}
        ready = states.get((stage, item)) == 'pending' and not entry['cancelled']
        if ready and stage == 'review':
            dependency = states.get(('inspect', item))
            if dependency in ('failed', 'skipped'):
                store.update(tenant, job, stage, item, 'skipped', {'reason': 'inspection did not succeed'})
            ready = dependency == 'succeeded'
        if ready and stage == 'summary':
            ready = all(states.get((s, i['id'])) in SETTLED
                        for i in entry['spec']['items'] for s in ('inspect', 'review'))
        ready = ready and entry['attempts'] < entry['spec']['max_attempts']
        if ready:
            store.update(tenant, job, stage, item, 'running')
            store.db.execute('UPDATE jobs SET attempts=attempts+1 WHERE tenant=? AND job=?', (tenant, job))
        store.db.execute('COMMIT')
        return ready
    except BaseException:
        store.db.execute('ROLLBACK')
        raise


def work(store, tenant, job, receipts):
    for stage in STAGES:
        for row in [r for r in store.rows(tenant, job) if r['stage'] == stage]:
            if not claim(store, tenant, job, stage, row['item']):
                continue
            entry = store.job(tenant, job)
            payload = next((i.get('payload', {}) for i in entry['spec']['items'] if i['id'] == row['item']), {})
            if stage == 'summary' and any((i.get('payload') or {}).get('crash_after_effect') == 'summary' for i in entry['spec']['items']):
                payload = {'crash_after_effect': 'summary'}
            context = {'tenant': tenant, 'job': job, 'stage': stage, 'item': row['item'],
                       'operation_key': row['operation_key'],
                       'payload': payload,
                       'coverage': report(store, tenant, job)}
            # Exceptions/process exits leave running (unknown), never safe to replay.
            outcome = perform(context, receipts)
            store.update(tenant, job, stage, row['item'], outcome['status'], outcome['output'])
    return report(store, tenant, job)


def handle(store, request, receipts):
    if not isinstance(request, dict):
        raise ValueError('request must be an object')
    tenant = request.get('tenant')
    job = request.get('job')
    op = request.get('op')
    if any(not isinstance(v, str) or not v for v in (tenant, job)):
        raise ValueError('trusted tenant and job identity required')
    if op == 'submit':
        return submit(store, tenant, job, request['spec'])
    store.job(tenant, job)
    if op == 'report':
        return report(store, tenant, job)
    if op == 'work':
        return work(store, tenant, job, receipts)
    if op in ('cancel', 'resume'):
        store.db.execute('UPDATE jobs SET cancelled=? WHERE tenant=? AND job=?', (int(op == 'cancel'), tenant, job))
        return report(store, tenant, job)
    if op == 'reconcile':
        store.reconcile(tenant, job, request.get('stage'), request.get('item'), request.get('state'),
                        request.get('result'), request.get('evidence'))
        return report(store, tenant, job)
    raise ValueError('unknown operation')
