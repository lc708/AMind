"""Join the full planned population to identity-bound scores and call evidence."""
import math
from .accounting import account, exact_scope


def finite(value):
    return type(value) in (int, float) and math.isfinite(value)


def text(value):
    return isinstance(value, str) and bool(value)


def validate_manifest(manifest):
    if not isinstance(manifest, dict):
        raise ValueError('manifest must be an object')
    for key in ('release_id', 'variant', 'split', 'comparison_hash', 'treatment_hash'):
        if not text(manifest.get(key)):
            raise ValueError('invalid manifest ' + key)
    ids, reps = manifest.get('case_ids'), manifest.get('repetitions')
    if (not isinstance(ids, list) or not all(text(cid) for cid in ids)
            or len(set(ids)) != len(ids) or type(reps) is not int or reps < 1):
        raise ValueError('invalid planned population')
    metrics = manifest.get('metrics')
    if not isinstance(metrics, list) or not metrics:
        raise ValueError('metrics must be a nonempty list')
    metric_ids = set()
    for metric in metrics:
        if (not isinstance(metric, dict) or not text(metric.get('id'))
                or metric['id'] in metric_ids
                or not all(finite(metric.get(k)) for k in ('min', 'max', 'min_mean'))
                or not metric['min'] <= metric['min_mean'] <= metric['max']):
            raise ValueError('invalid metric contract')
        metric_ids.add(metric['id'])
    if 'expected_billing_identity' in manifest and not exact_scope(manifest['expected_billing_identity']):
        raise ValueError('invalid expected billing identity')
    stages = manifest.get('required_stages', {})
    if (not isinstance(stages, dict) or any(not text(k) or type(v) is not int or v < 0
                                          for k, v in stages.items())):
        raise ValueError('invalid required stages')


def stage_ok(report, contract):
    if not contract:
        return None
    if not isinstance(report, dict) or not isinstance(report.get('stages'), list):
        return False
    by_id = {}
    for stage in report['stages']:
        if not isinstance(stage, dict) or not text(stage.get('id')) or stage['id'] in by_id:
            return False
        by_id[stage['id']] = stage
    for key, total in contract.items():
        row = by_id.get(key, {})
        counts = row.get('counts', {})
        if (type(row.get('total')) is not int or row['total'] != total
                or not finite(row.get('coverage')) or row['coverage'] != 1
                or row.get('uncovered') != [] or not isinstance(counts, dict)
                or type(counts.get('succeeded')) is not int or counts['succeeded'] != total
                or any(not text(k) or type(v) is not int or v < 0 for k, v in counts.items())
                or any(v != 0 for k, v in counts.items() if k != 'succeeded')):
            return False
    return True


def build(manifest, results, events, rates, requested_variant):
    validate_manifest(manifest)
    if not isinstance(results, list) or not isinstance(events, list):
        raise ValueError('results and attempts must be lists')
    if (not isinstance(rates, dict) or not isinstance(rates.get('rates'), list)
            or any(not isinstance(row, dict) for row in rates['rates'])):
        raise ValueError('invalid rate card')
    issues = []
    if requested_variant != manifest['variant']:
        issues.append('variant_mismatch')
    ordered = [(cid, rep) for cid in manifest['case_ids'] for rep in range(manifest['repetitions'])]
    planned = set(ordered)
    seen, accepted = set(), {}
    metric_ids = {m['id'] for m in manifest['metrics']}
    for row in results:
        if not isinstance(row, dict):
            raise ValueError('results must be objects')
        cid, rep = row.get('case_id'), row.get('rep')
        if not text(cid) or type(rep) is not int or (cid, rep) not in planned:
            issues.append('unexpected_result')
            continue
        key = (cid, rep)
        if key in seen:
            issues.append('duplicate_result')
            accepted.pop(key, None)
            continue
        seen.add(key)
        identity = {'comparison_hash': manifest['comparison_hash'],
                    'treatment_hash': manifest['treatment_hash'], 'case_id': cid, 'rep': rep}
        actual = row.get('result_identity')
        if (not isinstance(actual, dict) or actual != identity or type(actual.get('rep')) is not int):
            issues.append('result_identity_mismatch')
            continue
        pin = manifest.get('expected_billing_identity')
        if pin is not None and row.get('billing_identity') != pin:
            issues.append('serving_identity_mismatch')
            continue
        if row.get('status') != 'ok':
            continue
        grade = row.get('grade')
        if (not isinstance(grade, dict) or set(grade) != metric_ids
                or any(not finite(grade[m['id']]) or not m['min'] <= grade[m['id']] <= m['max']
                       for m in manifest['metrics'])):
            issues.append('invalid_grade')
            continue
        accepted[key] = row
    missing = [{'case_id': cid, 'rep': rep} for cid, rep in ordered if (cid, rep) not in accepted]
    metrics = {}
    for metric in manifest['metrics']:
        values = [row['grade'][metric['id']] for row in accepted.values()]
        # Scale before summing to avoid overflow for finite large-valued metrics.
        mean = math.fsum(v / len(values) for v in values) if values else None
        metrics[metric['id']] = {'mean': mean, 'scored': len(values)}
    attempts, cost, ledger_issues = account(events, rates)
    issues.extend(ledger_issues)
    contract = manifest.get('required_stages', {})
    if not contract:
        coverage = 'unmeasured'
    else:
        complete = bool(accepted) and not missing and all(
            stage_ok(row.get('coverage'), contract) for row in accepted.values())
        coverage = 'complete' if complete else 'incomplete'
    quality = all(metrics[m['id']]['mean'] is not None and metrics[m['id']]['mean'] >= m['min_mean']
                  for m in manifest['metrics'])
    ready = (not issues and not missing and quality and cost['total_usd'] is not None
             and coverage == 'complete')
    return {'release_id': manifest['release_id'], 'variant': requested_variant, 'split': manifest['split'],
            'planned_observations': len(planned), 'scored_observations': len(accepted), 'missing': missing,
            'metrics': metrics, 'attempts': attempts, 'cost': cost, 'coverage': {'status': coverage},
            'integrity': {'status': 'invalid' if issues else 'verified', 'issues': sorted(set(issues))},
            'decision': 'ready' if ready else 'hold'}
