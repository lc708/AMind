"""Reconcile the append-only call ledger without losing unknown spend."""
from datetime import date
import math

SCOPE = {'provider', 'interface', 'model', 'service_tier', 'region'}


def number(value):
    return type(value) in (int, float) and math.isfinite(value) and value >= 0


def exact_scope(value):
    return (isinstance(value, dict) and set(value) == SCOPE
            and all(isinstance(v, str) and v for v in value.values()))


def price(event, rates):
    """Return a reported cost or a supported usage subtotal, otherwise None.

    Completeness is separate from the subtotal: an incomplete estimate still
    contributes its known portion, but cannot establish a total task cost.
    """
    if 'cost_usd' in event:
        value = event['cost_usd']
        return value if number(value) else None
    scope = event.get('billing_identity')
    if not exact_scope(scope):
        return None
    try:
        date.fromisoformat(rates.get('effective_date', ''))
    except (TypeError, ValueError):
        return None
    matches = [r for r in rates.get('rates', [])
               if exact_scope(r.get('identity')) and r['identity'] == scope]
    if len(matches) != 1:
        return None
    rate, usage = matches[0], event.get('usage')
    if not isinstance(usage, dict):
        return None
    if rate.get('mode') == 'input_only':
        if (set(usage) != {'input_tokens'} or type(usage['input_tokens']) is not int
                or usage['input_tokens'] < 0 or not number(rate.get('input_per_million'))):
            return None
        value = usage['input_tokens'] / 1e6 * rate['input_per_million']
    elif rate.get('mode') == 'text':
        required = {'input_tokens', 'cached_input_tokens', 'output_tokens'}
        if not required <= set(usage) <= required | {'reasoning_tokens'}:
            return None
        if any(type(v) is not int or v < 0 for v in usage.values()):
            return None
        incoming, cached, outgoing = (usage[k] for k in
                                      ('input_tokens', 'cached_input_tokens', 'output_tokens'))
        if cached > incoming or usage.get('reasoning_tokens', 0) > outgoing:
            return None
        if not all(number(rate.get(k)) for k in
                   ('input_per_million', 'cached_per_million', 'output_per_million')):
            return None
        # Input already includes cache; output already includes reasoning.
        value = ((incoming - cached) / 1e6 * rate['input_per_million']
                 + cached / 1e6 * rate['cached_per_million']
                 + outgoing / 1e6 * rate['output_per_million'])
    else:
        return None
    return value if number(value) else None


def account(events, rates):
    starts, finishes, matched, issues = {}, {}, set(), []
    for event in events:
        if not isinstance(event, dict):
            raise ValueError('attempt events must be objects')
        kind, key = event.get('event'), event.get('attempt_id')
        if (kind not in ('started', 'finished') or not isinstance(key, str) or not key
                or not isinstance(event.get('case_id'), str) or not event['case_id']
                or type(event.get('rep')) is not int or event['rep'] < 0
                or (kind == 'finished' and
                    (not isinstance(event.get('status'), str) or not event['status']))):
            issues.append('invalid_attempt_event')
            continue
        bucket = starts if kind == 'started' else finishes
        if key in bucket:
            issues.append('duplicate_' + kind)
            continue  # First event wins; duplicate writes cannot inflate totals.
        if kind == 'finished':
            prior = starts.get(key)
            if prior is None or any(prior[k] != event[k] for k in ('case_id', 'rep')):
                issues.append('unmatched_finished')
            else:
                matched.add(key)
        bucket[key] = event
    interrupted = len(set(starts) - matched)
    known, unknown = 0.0, interrupted
    for event in finishes.values():
        value = price(event, rates)
        if value is not None:
            known += value
        complete = ('cost_usd' in event or event.get('all_billable_usage_included') is True)
        if value is None or not complete:
            unknown += 1
    if not number(known):
        raise ValueError('cost subtotal exceeds supported numeric range')
    attempts = {'started': len(starts), 'finished': len(finishes),
                'interrupted': interrupted,
                'failed': sum(e['status'] != 'ok' for e in finishes.values())}
    costs = {'known_usd': known, 'total_usd': None if unknown else known,
             'unknown_attempts': unknown}
    return attempts, costs, issues
