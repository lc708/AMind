# Releaseboard incident repair

The unchanged saved example previously returned `ready`, reported only two planned observations, and omitted `account-recovery`. Its original CLI output is preserved in `baseline-saved-example.json`. The public baseline had one passing test and two failures (planned population and interrupted spend).

The repaired CLI reports three planned observations, two scored observations, the missing `account-recovery` pair, incomplete coverage and `hold`. The known spend remains 0.4. See `repaired-saved-example.json`.

Changes in the delivered `repo/`:

- `releaseboard/report.py`: validate the manifest; enumerate the full case/repetition population; enforce variant, result and optional serving identities; exclude duplicate results; preserve missing observations and empty metric means; evaluate declared stage populations and all release gates.
- `releaseboard/accounting.py`: reconcile unique starts/finishes without overwriting; include failed calls; retain interrupted and unknown spend; price only exact dated scopes and supported integer usage; price cached/reasoning subsets once; retain partial estimated subtotals without claiming a complete total.
- `releaseboard/__main__.py`: preserve CLI arguments and packet fields; report malformed JSONL with line context; emit JSON errors and exit 2 for malformed/unreadable input. Semantic holds still exit 0.

Verification completed without network or model calls:

1. `TMPDIR="$PWD/../output/tmp" PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -v`: all 3 public tests passed. Output: `public-tests.txt`. Existing tests were not modified.
2. `python3 -B ../output/integration_checks.py`: all 10 integration groups passed, exercising the actual `python3 -m releaseboard` entry point 71 times. Cases cover a complete ready packet, the saved outage, repetitions, failed/interrupted/duplicate/unmatched calls, invalid costs and grades, exact identities/rate scopes, complete/partial usage estimates, coverage failures and malformed files. Full CLI packets: `integration-results.json`.
3. Copied the package, saved examples and README into `output/standalone/`, removed `PYTHONPATH` from the subprocess environment and ran the documented command there. It exited 0 with the identical repaired packet and had no `skills/` directory. Record: `standalone-check.json`.

All temporary integration bundles were created under `output/tmp/`. The package uses only the Python standard library and relative package imports. No model configuration was changed and no helper implementation was imported or copied from skills.
