"""Offline CLI checks. All temporary bundles and evidence stay in output/."""
import copy
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

OUTPUT = Path(__file__).resolve().parent
ROOT = OUTPUT.parent / 'repo'
BASE_MANIFEST = json.loads((ROOT / 'examples/saved-run/manifest.json').read_text())
BASE_RESULTS = [json.loads(line) for line in (ROOT / 'examples/saved-run/results.jsonl').read_text().splitlines()]
BASE_EVENTS = [json.loads(line) for line in (ROOT / 'examples/saved-run/attempts.jsonl').read_text().splitlines()]
RATES = json.loads((ROOT / 'examples/rates.json').read_text())
RECORDS = []


def healthy():
    manifest = copy.deepcopy(BASE_MANIFEST)
    results = copy.deepcopy(BASE_RESULTS)
    row = copy.deepcopy(results[0])
    row['case_id'] = row['result_identity']['case_id'] = 'account-recovery'
    results.append(row)
    return manifest, results, copy.deepcopy(BASE_EVENTS)


def call_events(**fields):
    start = {'event': 'started', 'attempt_id': 'extra', 'case_id': 'order-return', 'rep': 0}
    finish = dict(start, event='finished', status='ok', **fields)
    return [start, finish]


class CLIIntegration(unittest.TestCase):
    def run_cli(self, manifest=None, results=None, events=None, rates=None, variant='candidate', broken=None):
        m, r, e = healthy()
        manifest = m if manifest is None else manifest
        results = r if results is None else results
        events = e if events is None else events
        rates = RATES if rates is None else rates
        with tempfile.TemporaryDirectory(dir=OUTPUT / 'tmp') as tmp:
            folder = Path(tmp)
            for name, value in [('manifest.json', manifest), ('rates.json', rates)]:
                (folder / name).write_text(json.dumps(value))
            for name, value in [('results.jsonl', results), ('attempts.jsonl', events)]:
                (folder / name).write_text(''.join(json.dumps(row) + '\n' for row in value))
            if broken:
                (folder / broken[0]).write_text(broken[1])
            env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
            proc = subprocess.run([sys.executable, '-B', '-m', 'releaseboard', '--bundle', str(folder),
                                   '--rates', str(folder / 'rates.json'), '--variant', variant],
                                  cwd=ROOT, capture_output=True, text=True, env=env)
            self.assertEqual(proc.stderr, '')
            packet = json.loads(proc.stdout)
            RECORDS.append({'check': self.id(), 'exit_code': proc.returncode, 'packet': packet})
            if broken or not isinstance(manifest, dict):
                self.assertEqual(proc.returncode, 2)
                self.assertIn('error', packet)
            else:
                self.assertEqual(proc.returncode, 0, packet)
            return packet

    def test_healthy_and_original_outage(self):
        packet = self.run_cli()
        self.assertEqual(packet['decision'], 'ready')
        self.assertEqual(packet['planned_observations'], 3)
        self.assertEqual(packet['coverage']['status'], 'complete')
        packet = self.run_cli(results=BASE_RESULTS)
        self.assertEqual(packet['decision'], 'hold')
        self.assertEqual(packet['missing'], [{'case_id': 'account-recovery', 'rep': 0}])

    def test_variant_and_exact_identities(self):
        self.assertEqual(self.run_cli(variant='other')['integrity']['status'], 'invalid')
        for key in ('comparison_hash', 'treatment_hash', 'case_id', 'rep', 'extra'):
            with self.subTest(key=key):
                _, results, _ = healthy()
                results[0]['result_identity'][key] = 'foreign'
                p = self.run_cli(results=results)
                self.assertEqual(p['scored_observations'], 2)
                self.assertEqual(p['integrity']['status'], 'invalid')
                self.assertEqual(p['decision'], 'hold')
        for key in BASE_MANIFEST['expected_billing_identity']:
            with self.subTest(scope=key):
                _, results, _ = healthy()
                results[0]['billing_identity'][key] = 'foreign'
                self.assertEqual(self.run_cli(results=results)['integrity']['status'], 'invalid')

    def test_duplicate_and_unexpected_results(self):
        _, results, _ = healthy()
        results += [copy.deepcopy(results[0])]
        packet = self.run_cli(results=results)
        self.assertEqual(packet['scored_observations'], 2)
        self.assertIn({'case_id': 'order-return', 'rep': 0}, packet['missing'])
        for case, rep in [('foreign', 0), ('order-return', True), ('order-return', 8), ([], 0)]:
            _, results, _ = healthy()
            results[0].update(case_id=case, rep=rep)
            self.assertEqual(self.run_cli(results=results)['integrity']['status'], 'invalid')

    def test_grades_and_quality_gate(self):
        for grade in [{}, {'quality': True}, {'quality': float('nan')}, {'quality': float('inf')},
                      {'quality': -1}, {'quality': 2}, [], None]:
            with self.subTest(grade=grade):
                _, results, _ = healthy()
                results[0]['grade'] = grade
                p = self.run_cli(results=results)
                self.assertEqual(p['scored_observations'], 2)
                self.assertEqual(p['decision'], 'hold')
        _, results, _ = healthy()
        for row in results:
            row['grade']['quality'] = .5
        self.assertEqual(self.run_cli(results=results)['decision'], 'hold')
        for row in results:
            row['status'] = 'error'
        p = self.run_cli(results=results)
        self.assertIsNone(p['metrics']['quality']['mean'])
        self.assertEqual(len(p['missing']), 3)

    def test_failed_interrupted_and_duplicate_calls(self):
        e = copy.deepcopy(BASE_EVENTS) + call_events(cost_usd=.3)
        e[-1]['status'] = 'error'
        p = self.run_cli(events=e)
        self.assertAlmostEqual(p['cost']['known_usd'], .7)
        self.assertEqual(p['attempts']['failed'], 1)
        e += [{'event': 'started', 'attempt_id': 'pending', 'case_id': 'order-return', 'rep': 0}]
        p = self.run_cli(events=e)
        self.assertIsNone(p['cost']['total_usd'])
        self.assertEqual(p['cost']['unknown_attempts'], 1)
        for duplicate in (BASE_EVENTS[0], BASE_EVENTS[1]):
            p = self.run_cli(events=BASE_EVENTS + [duplicate])
            self.assertEqual(p['attempts']['started'], 2)
            self.assertEqual(p['attempts']['finished'], 2)
            self.assertAlmostEqual(p['cost']['known_usd'], .4)
            self.assertEqual(p['integrity']['status'], 'invalid')
        p = self.run_cli(events=[BASE_EVENTS[1]])
        self.assertEqual(p['integrity']['status'], 'invalid')
        self.assertAlmostEqual(p['cost']['known_usd'], .2)

    def test_explicit_costs(self):
        for value in [None, True, False, -1, '0', float('nan'), float('inf')]:
            with self.subTest(cost=value):
                p = self.run_cli(events=BASE_EVENTS + call_events(cost_usd=value))
                self.assertIsNone(p['cost']['total_usd'])
                self.assertEqual(p['cost']['unknown_attempts'], 1)
                self.assertAlmostEqual(p['cost']['known_usd'], .4)
        p = self.run_cli(events=BASE_EVENTS + call_events(cost_usd=0))
        self.assertAlmostEqual(p['cost']['total_usd'], .4)

    def test_scoped_estimates_and_partial_subtotal(self):
        fields = {'billing_identity': copy.deepcopy(BASE_MANIFEST['expected_billing_identity']),
                  'usage': {'input_tokens': 1000, 'cached_input_tokens': 200,
                            'output_tokens': 500, 'reasoning_tokens': 100},
                  'all_billable_usage_included': True}
        p = self.run_cli(events=call_events(**fields))
        self.assertAlmostEqual(p['cost']['total_usd'], .0182)
        fields['all_billable_usage_included'] = False
        p = self.run_cli(events=call_events(**fields))
        self.assertAlmostEqual(p['cost']['known_usd'], .0182)
        self.assertIsNone(p['cost']['total_usd'])
        self.assertEqual(p['cost']['unknown_attempts'], 1)
        fields['all_billable_usage_included'] = True
        for key in fields['billing_identity']:
            changed = copy.deepcopy(fields)
            changed['billing_identity'][key] = 'foreign'
            self.assertIsNone(self.run_cli(events=call_events(**changed))['cost']['total_usd'])
        for usage in [{'input_tokens': 1}, {'input_tokens': 1.5, 'cached_input_tokens': 0, 'output_tokens': 0},
                      {'input_tokens': 1, 'cached_input_tokens': 2, 'output_tokens': 0},
                      {'input_tokens': 1, 'cached_input_tokens': 0, 'output_tokens': 1, 'reasoning_tokens': 2},
                      {'input_tokens': 1, 'cached_input_tokens': 0, 'output_tokens': 1, 'native': 2}]:
            changed = dict(fields, usage=usage)
            self.assertIsNone(self.run_cli(events=call_events(**changed))['cost']['total_usd'])
        fields['billing_identity']['interface'] = 'decisions'
        fields['usage'] = {'input_tokens': 1000}
        self.assertAlmostEqual(self.run_cli(events=call_events(**fields))['cost']['total_usd'], .002)
        fields['usage']['output_tokens'] = 0
        self.assertIsNone(self.run_cli(events=call_events(**fields))['cost']['total_usd'])

    def test_coverage_contract(self):
        m, _, _ = healthy()
        del m['required_stages']
        p = self.run_cli(manifest=m)
        self.assertEqual(p['coverage']['status'], 'unmeasured')
        self.assertEqual(p['decision'], 'hold')
        mutations = [lambda r: r['coverage']['stages'].pop(),
                     lambda r: r['coverage']['stages'].append(copy.deepcopy(r['coverage']['stages'][0])),
                     lambda r: r['coverage']['stages'][0].update(total=2),
                     lambda r: r['coverage']['stages'][0].update(coverage=True),
                     lambda r: r['coverage']['stages'][0].update(uncovered=['missing']),
                     lambda r: r['coverage']['stages'][0]['counts'].update(failed=1),
                     lambda r: r['coverage']['stages'][0]['counts'].update(succeeded=True),
                     lambda r: r.update(coverage={'stages': None})]
        for change in mutations:
            _, results, _ = healthy()
            change(results[0])
            p = self.run_cli(results=results)
            self.assertEqual(p['coverage']['status'], 'incomplete')
            self.assertEqual(p['decision'], 'hold')

    def test_repetitions_use_full_population(self):
        m, results, _ = healthy()
        m['repetitions'] = 2
        p = self.run_cli(manifest=m, results=results)
        self.assertEqual(p['planned_observations'], 6)
        self.assertEqual(p['scored_observations'], 3)
        self.assertEqual(p['missing'], [{'case_id': cid, 'rep': 1} for cid in m['case_ids']])

    def test_malformed_input_is_json_error(self):
        for name, content in [('manifest.json', '{}'), ('manifest.json', '[]'),
                              ('results.jsonl', '[]\n'), ('results.jsonl', '{bad'),
                              ('attempts.jsonl', 'null\n'), ('rates.json', '[]')]:
            self.run_cli(broken=(name, content))


if __name__ == '__main__':
    (OUTPUT / 'tmp').mkdir(exist_ok=True)
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(CLIIntegration)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    (OUTPUT / 'integration-results.json').write_text(json.dumps({
        'tests_run': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors),
        'cli_invocations': len(RECORDS), 'runs': RECORDS}, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
    raise SystemExit(not result.wasSuccessful())
