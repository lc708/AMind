"""Keep adjudication, abstention, family and class denominators visible."""
from .validation import cohort_records, finite_number


def ratio(a, b):
    return a / b if b else None


def valid_identity(identity):
    keys = {'dataset_version', 'judge', 'grader_version', 'rubric'}
    return (isinstance(identity, dict) and set(identity) == keys
            and all(isinstance(x, str) and x.strip() for x in identity.values()))


def binary(value):
    return type(value) is int and value in (0, 1)


def audit(cohort):
    records = cohort_records(cohort)
    issues, seen, family_splits, labeled_families = [], set(), {}, set()
    if not valid_identity(cohort.get('identity')):
        issues.append('invalid_evaluation_identity')
    counts = dict(tp=0, tn=0, fp=0, fn=0)
    adjudicated, evaluated, abstained, unknown_human = 0, 0, 0, 0
    human_pos, human_neg = 0, 0
    for row in records:
        key = (row['id'], row.get('rep', 0))
        if (not isinstance(key[0], str) or not key[0].strip()
                or type(key[1]) is not int or key[1] < 0 or key in seen):
            issues.append('duplicate_or_invalid_example')
            continue
        seen.add(key)
        family, split = row['family'], row['split']
        if not isinstance(family, str) or not family.strip() or split not in ('train', 'validation', 'holdout'):
            issues.append('invalid_family_or_split')
            continue
        family_splits.setdefault(family, set()).add(split)
        human, decision = row['human'], row['decision']
        invalid = False
        if human is not None and not binary(human):
            issues.append('invalid_human_label')
            invalid = True
        if decision is not None and not binary(decision):
            issues.append('invalid_judge_decision')
            invalid = True
        if invalid:
            continue
        # These are independent missingness counts: both may apply to a row.
        abstained += decision is None
        unknown_human += human is None
        if human is None:
            continue
        adjudicated += 1
        human_pos += human == 1
        human_neg += human == 0
        labeled_families.add(family)
        if decision is None:
            continue
        evaluated += 1
        cell = 'tp' if human and decision else 'fn' if human else 'fp' if decision else 'tn'
        counts[cell] += 1
    if any(len(splits) > 1 for splits in family_splits.values()):
        issues.append('family_crosses_split')
    pos, neg = counts['tp'] + counts['fn'], counts['tn'] + counts['fp']
    rates = {'fpr': ratio(counts['fp'], neg), 'fnr': ratio(counts['fn'], pos),
             'precision': ratio(counts['tp'], counts['tp'] + counts['fp']),
             'recall': ratio(counts['tp'], pos)}
    result = {'confusion': counts, **rates,
              'denominators': {'adjudicated': adjudicated, 'human_positive': human_pos, 'human_negative': human_neg,
                               'evaluated': evaluated, 'evaluated_positive': pos, 'evaluated_negative': neg,
                               'abstained': abstained, 'unknown_human': unknown_human},
              'judgment_coverage': ratio(evaluated, len(records)),
              'unmeasured': [name for name, value in rates.items() if value is None]}
    return result, len(labeled_families), issues


def workers(required, reports):
    by_id, duplicates, issues = {}, set(), []
    required_ids = []
    for key in required:
        if not isinstance(key, str) or not key.strip():
            issues.append('invalid_required_worker')
        elif key in required_ids:
            issues.append('duplicate_required_worker')
        else:
            required_ids.append(key)
    for row in reports:
        key = row.get('id')
        if not isinstance(key, str) or not key.strip():
            issues.append('invalid_worker')
            continue
        if key in by_id:
            issues.append('duplicate_worker')
            duplicates.add(key)
        else:
            by_id[key] = row
    if set(by_id) - set(required_ids):
        issues.append('unexpected_worker')
    uncovered = [key for key in required_ids
                 if key in duplicates or by_id.get(key, {}).get('status') != 'succeeded']
    return {'expected': len(required_ids), 'completed': len(required_ids) - len(uncovered), 'uncovered': uncovered,
            'status': 'unmeasured' if not required_ids else 'incomplete' if uncovered else 'complete'}, issues


def scenario(calibration, prevalence):
    if not finite_number(prevalence) or not 0 <= prevalence <= 1:
        return {'status': 'unmeasured', 'value': None}
    tpr, fpr = calibration['recall'], calibration['fpr']
    if any(not finite_number(rate) or not 0 <= rate <= 1 for rate in (tpr, fpr)):
        return {'status': 'unmeasured', 'value': None}
    value = ratio(tpr * prevalence, tpr * prevalence + fpr * (1 - prevalence))
    return {'status': 'scenario' if value is not None else 'unmeasured', 'value': value}
