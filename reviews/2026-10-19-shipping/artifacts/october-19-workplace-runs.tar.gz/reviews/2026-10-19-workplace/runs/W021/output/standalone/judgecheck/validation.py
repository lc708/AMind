"""Validate input structure; semantic evidence defects belong in integrity issues."""
import math


def cohort_records(cohort):
    if not isinstance(cohort, dict):
        raise ValueError('cohort must be an object')
    records = cohort.get('records')
    if not isinstance(records, list):
        raise ValueError('cohort records must be an array')
    for row in records:
        if not isinstance(row, dict):
            raise ValueError('each record must be an object')
        if not {'id', 'family', 'split', 'human', 'decision'} <= row.keys():
            raise ValueError('each record requires id, family, split, human and decision')
    return records


def finite_number(value):
    return type(value) in (int, float) and (type(value) is int or math.isfinite(value))


def validate_job(job):
    if not isinstance(job, dict):
        raise ValueError('input must be an object')
    if not isinstance(job.get('positive_event'), str) or not job['positive_event'].strip():
        raise ValueError('positive_event must declare the event represented by label 1')
    cohort_records(job.get('current'))
    for key in ('baseline', 'drift_reference'):
        if job.get(key) is not None:
            cohort_records(job[key])
    if not isinstance(job.get('required_workers'), list):
        raise ValueError('required_workers must be an array')
    reports = job.get('worker_reports', [])
    if not isinstance(reports, list) or any(not isinstance(r, dict) for r in reports):
        raise ValueError('worker_reports must be an array of objects')
    limits = job.get('limits')
    if not isinstance(limits, dict):
        raise ValueError('limits must be an object')
    margin = limits.get('max_fpr_increase')
    if not finite_number(margin) or not 0 <= margin <= 1:
        raise ValueError('max_fpr_increase must be a finite number between 0 and 1')
    minimum = limits.get('min_labeled_families')
    if type(minimum) is not int or minimum < 0:
        raise ValueError('min_labeled_families must be a nonnegative integer')
