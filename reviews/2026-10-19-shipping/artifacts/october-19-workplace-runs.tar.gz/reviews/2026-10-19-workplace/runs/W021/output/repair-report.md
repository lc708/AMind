# Support judge incident repair

The product is the standalone, standard-library `repo/judgecheck` package.
No services, models, installed AMind helpers or skill imports were used at runtime.

## Reproduced incident

The unchanged public suite failed 2 of 3 tests. The saved example incorrectly
returned `ready_for_review`, fabricated a true negative from an abstention,
counted the unknown security worker as completed, and reported a deployment
scenario precision of 0.6666667. Original results are in `baseline-review.json`
and `baseline-public-tests.txt`.

## Repairs

- Calibration preserves unknown adjudications and abstentions independently,
  uses evaluated class denominators, reports undefined rates as null and lists
  them in `unmeasured`, and counts distinct labeled families.
- Input auditing detects duplicate case/rep pairs, invalid identities and labels,
  and family split leakage. Structural input errors produce JSON and exit 2;
  semantic integrity failures produce a held packet and exit 0.
- Required workers need explicit, unambiguous success. Missing, failed, unknown,
  duplicate and unexpected identities cannot silently satisfy coverage.
- Judge comparison requires the entire matching case/rep/adjudication/family/split
  population and matching dataset/rubric identities. Unknown or abstaining pairs
  remain visible as a partial comparison; improvements/regressions use only
  comparable pairs.
- Drift fixes judge/grader/rubric across cohorts, requires negative controls, and
  checks a strictly greater FPR increase. Exact count ratios avoid false alerts
  at decimal margin boundaries.
- Scenario precision uses sensitivity * prevalence divided by sensitivity *
  prevalence + FPR * (1 - prevalence), independently of sample precision.
- Readiness applies the documented evidence gates, including measured classes,
  complete judgments, family count, workers, pairing and drift when supplied.
  No judge model identity was substituted.

## Executed verification

From `repo/`:

```
python3 -m unittest discover -s tests -v
python3 -m judgecheck --input examples/review.json
python3 ../output/integration_checks.py
```

All 3 unchanged public tests passed. All 18 local integration
tests passed, exercising the actual CLI in 78 subprocess invocations.
Fixtures and raw CLI packets are retained in `fixtures/` and `cli-results/`;
`integration-summary.json`, `integration-results.txt`, and `public-tests.txt`
record the checks. One check copies the repository alone into `standalone/`,
clears PYTHONPATH, disables user site packages, and executes the same CLI there.

The repaired saved example returns `hold`: TP=2, TN=1, FP=1, FN=1;
evaluated=5/6, abstained=1, security uncovered, FPR=0.5, and scenario precision
approximately 0.001332889 at supplied prevalence 0.001. See
`repaired-review.json`. These are offline descriptive evidence checks; they
establish the repaired review behavior, not improved judge accuracy or rollout
approval.
