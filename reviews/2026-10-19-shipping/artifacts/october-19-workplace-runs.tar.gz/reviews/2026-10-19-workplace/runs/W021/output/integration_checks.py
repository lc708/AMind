"""Offline regression checks against the documented CLI, with saved local fixtures."""
import copy
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import unittest

WORKSPACE = Path(__file__).resolve().parent.parent
REPO = WORKSPACE / 'repo'
OUT = WORKSPACE / 'output'
FIXTURES = OUT / 'fixtures'
RESULTS = OUT / 'cli-results'
FIXTURES.mkdir(exist_ok=True)
RESULTS.mkdir(exist_ok=True)
ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1', PYTHONPATH='')


def job():
    return {
        'positive_event': 'genuine_support_policy_issue',
        'current': {
            'identity': dict(dataset_version='set-1', judge='current', grader_version='v2', rubric='rubric-1'),
            'records': [
                dict(id='p1', family='A', split='holdout', human=1, decision=1),
                dict(id='p2', family='B', split='holdout', human=1, decision=0),
                dict(id='n1', family='C', split='holdout', human=0, decision=0),
                dict(id='n2', family='D', split='holdout', human=0, decision=1),
            ],
        },
        'required_workers': ['policy', 'security'],
        'worker_reports': [dict(id='policy', status='succeeded'), dict(id='security', status='succeeded')],
        'limits': dict(max_fpr_increase=0.25, min_labeled_families=2),
        'deployment_prevalence': 0.01,
    }


class CLIIntegration(unittest.TestCase):
    counter = 0

    def run_packet(self, data, code=0, cwd=REPO, raw=False):
        CLIIntegration.counter += 1
        name = f'{self._testMethodName}-{CLIIntegration.counter}'
        path = FIXTURES / f'{name}.json'
        path.write_text(data if raw else json.dumps(data), encoding='utf-8')
        proc = subprocess.run([sys.executable, '-m', 'judgecheck', '--input', str(path)],
                              cwd=cwd, env=ENV, text=True, capture_output=True, timeout=5)
        (RESULTS / f'{name}.json').write_text(proc.stdout, encoding='utf-8')
        self.assertEqual(proc.returncode, code, proc.stderr + proc.stdout)
        self.assertEqual(proc.stderr, '')
        value = json.loads(proc.stdout)
        if code == 2:
            self.assertIn('error', value)
        else:
            self.assertEqual(set(value), {'status', 'calibration', 'family_count', 'workers', 'paired',
                                         'drift', 'deployment_precision', 'integrity', 'limits'})
        return value

    def test_full_confusion_and_scenario(self):
        packet = self.run_packet(job())
        self.assertEqual(packet['status'], 'ready_for_review')
        self.assertEqual(packet['calibration']['confusion'], dict(tp=1, tn=1, fp=1, fn=1))
        for metric in ('fpr', 'fnr', 'precision', 'recall'):
            self.assertEqual(packet['calibration'][metric], 0.5)
        self.assertEqual(packet['calibration']['judgment_coverage'], 1)
        self.assertAlmostEqual(packet['deployment_precision']['value'], 0.01)

    def test_unknown_and_abstention_are_independent(self):
        j = job()
        j['current']['records'] += [
            dict(id='unknown', family='unlabeled', split='holdout', human=None, decision=1),
            dict(id='both-null', family='unlabeled', split='holdout', human=None, decision=None),
            dict(id='abstain', family='E', split='holdout', human=0, decision=None),
        ]
        p = self.run_packet(j)
        self.assertEqual(p['calibration']['confusion'], dict(tp=1, tn=1, fp=1, fn=1))
        self.assertEqual(p['calibration']['denominators'], dict(adjudicated=5, human_positive=2,
                         human_negative=3, evaluated=4, evaluated_positive=2, evaluated_negative=2,
                         abstained=2, unknown_human=2))
        self.assertEqual(p['family_count'], 5)
        self.assertAlmostEqual(p['calibration']['judgment_coverage'], 4 / 7)
        self.assertEqual(p['status'], 'hold')

    def test_absent_classes_and_empty_population(self):
        for records, missing in [([], ('fpr', 'fnr', 'precision', 'recall')),
                                 ([dict(id='p', family='A', split='holdout', human=1, decision=1)], ('fpr',)),
                                 ([dict(id='n', family='A', split='holdout', human=0, decision=0)], ('fnr', 'recall', 'precision'))]:
            with self.subTest(records=records):
                j = job()
                j['current']['records'] = records
                p = self.run_packet(j)
                self.assertEqual(p['status'], 'hold')
                for metric in missing:
                    self.assertIsNone(p['calibration'][metric])
                    self.assertIn(metric, p['calibration']['unmeasured'])
                self.assertEqual(p['deployment_precision'], dict(status='unmeasured', value=None))

    def test_abstained_negative_is_not_a_negative_control(self):
        j = job()
        for row in j['current']['records']:
            if row['human'] == 0:
                row['decision'] = None
        p = self.run_packet(j)
        self.assertIsNone(p['calibration']['fpr'])
        self.assertEqual(p['calibration']['denominators']['human_negative'], 2)
        self.assertEqual(p['calibration']['denominators']['evaluated_negative'], 0)
        self.assertEqual(p['status'], 'hold')

    def test_repetitions_do_not_multiply_families(self):
        j = job()
        for rep in range(1, 4):
            j['current']['records'] += [dict(row, rep=rep) for row in j['current']['records'][:4]]
        j['limits']['min_labeled_families'] = 5
        p = self.run_packet(j)
        self.assertEqual(p['family_count'], 4)
        self.assertEqual(p['calibration']['denominators']['evaluated'], 16)
        self.assertEqual(p['integrity']['status'], 'verified')
        self.assertEqual(p['status'], 'hold')

    def test_duplicate_and_split_leakage(self):
        j = job()
        j['current']['records'].append(copy.deepcopy(j['current']['records'][0]))
        p = self.run_packet(j)
        self.assertIn('duplicate_or_invalid_example', p['integrity']['issues'])
        j = job()
        j['current']['records'][1].update(family='A', split='validation')
        p = self.run_packet(j)
        self.assertIn('family_crosses_split', p['integrity']['issues'])
        self.assertEqual(p['status'], 'hold')

    def test_worker_coverage(self):
        for status in ('unknown', 'failed', None, 'success', True):
            j = job()
            j['worker_reports'][1]['status'] = status
            p = self.run_packet(j)
            self.assertEqual(p['workers']['uncovered'], ['security'])
            self.assertEqual(p['workers']['completed'], 1)
            self.assertEqual(p['status'], 'hold')
        j = job()
        j['worker_reports'].pop()
        self.assertEqual(self.run_packet(j)['workers']['uncovered'], ['security'])
        j['required_workers'] = []
        j['worker_reports'] = []
        self.assertEqual(self.run_packet(j)['workers']['status'], 'unmeasured')

    def test_worker_identity_cannot_be_substituted(self):
        j = job()
        j['worker_reports'][1]['id'] = 'extra'
        p = self.run_packet(j)
        self.assertIn('unexpected_worker', p['integrity']['issues'])
        self.assertEqual(p['workers']['uncovered'], ['security'])
        j = job()
        j['worker_reports'].append(copy.deepcopy(j['worker_reports'][0]))
        p = self.run_packet(j)
        self.assertIn('duplicate_worker', p['integrity']['issues'])
        self.assertEqual(p['status'], 'hold')
        j = job()
        j['required_workers'].append('policy')
        self.assertIn('duplicate_required_worker', self.run_packet(j)['integrity']['issues'])

    def with_baseline(self):
        j = job()
        j['baseline'] = copy.deepcopy(j['current'])
        j['baseline']['identity'].update(judge='previous', grader_version='v1')
        for row, decision in zip(j['baseline']['records'], (0, 1, 1, 1)):
            row['decision'] = decision
            row['rep'] = 0
        j['baseline']['records'].reverse()
        return j

    def test_paired_changes_and_order_invariance(self):
        p = self.run_packet(self.with_baseline())
        self.assertEqual(p['paired'], dict(status='complete', pairs=4, evaluated_pairs=4,
                                         improved=2, regressed=1, agreement_delta=0.25))
        self.assertEqual(p['status'], 'ready_for_review')

    def test_pairing_refuses_intersections_and_metadata_changes(self):
        for field in ('missing', 'extra', 'human', 'family', 'split', 'rep', 'dataset_version', 'rubric'):
            j = self.with_baseline()
            old = j['baseline']
            if field == 'missing':
                old['records'].pop()
            elif field == 'extra':
                old['records'].append(dict(old['records'][0], id='extra', family='extra'))
            elif field in ('dataset_version', 'rubric'):
                old['identity'][field] = 'changed'
            else:
                old['records'][0][field] = dict(human=1, family='changed', split='train', rep=1)[field]
            with self.subTest(field=field):
                p = self.run_packet(j)
                self.assertEqual(p['paired']['status'], 'invalid')
                self.assertEqual(p['integrity']['status'], 'invalid')
                self.assertEqual(p['status'], 'hold')

    def test_paired_abstention_is_partial(self):
        j = self.with_baseline()
        j['baseline']['records'][-1]['decision'] = None
        p = self.run_packet(j)
        self.assertEqual(p['paired'], dict(status='partial', pairs=4, evaluated_pairs=3,
                                         improved=1, regressed=1, agreement_delta=0.0))
        self.assertEqual(p['status'], 'hold')

    def with_drift(self):
        j = job()
        j['drift_reference'] = copy.deepcopy(j['current'])
        j['drift_reference']['identity']['dataset_version'] = 'prior-cohort'
        j['drift_reference']['records'][-1]['decision'] = 0
        return j

    def test_drift_margin_and_fixed_judge(self):
        j = self.with_drift()
        p = self.run_packet(j)
        self.assertEqual(p['drift']['fpr_delta'], 0.5)
        self.assertEqual(p['drift']['status'], 'alert')
        self.assertEqual(p['status'], 'hold')
        j['limits']['max_fpr_increase'] = 0.5
        p = self.run_packet(j)
        self.assertEqual(p['drift']['status'], 'within_margin')
        self.assertEqual(p['status'], 'ready_for_review')
        for field in ('judge', 'grader_version', 'rubric'):
            j = self.with_drift()
            j['drift_reference']['identity'][field] = 'changed'
            p = self.run_packet(j)
            self.assertEqual(p['drift']['status'], 'invalid')
            self.assertEqual(p['integrity']['status'], 'invalid')

    def test_drift_requires_negative_controls(self):
        j = self.with_drift()
        j['drift_reference']['records'] = j['drift_reference']['records'][:2]
        p = self.run_packet(j)
        self.assertEqual(p['drift']['status'], 'unmeasured')
        self.assertIsNone(p['drift']['fpr_delta'])
        self.assertEqual(p['status'], 'hold')

    def test_decimal_drift_boundary_is_not_an_alert(self):
        j = job()
        negatives = [dict(id=f'n{i}', family=f'N{i}', split='holdout', human=0,
                          decision=int(i < 4)) for i in range(10)]
        j['current']['records'] = j['current']['records'][:2] + negatives
        j['drift_reference'] = copy.deepcopy(j['current'])
        j['drift_reference']['identity']['dataset_version'] = 'previous'
        for row in j['drift_reference']['records'][2:]:
            row['decision'] = int(row['id'] == 'n0')
        j['limits']['max_fpr_increase'] = 0.3
        p = self.run_packet(j)
        self.assertEqual(p['drift']['status'], 'within_margin')
        self.assertEqual(p['drift']['fpr_delta'], 0.3)
        j['limits']['max_fpr_increase'] = 0.299999999999
        self.assertEqual(self.run_packet(j)['drift']['status'], 'alert')

    def test_prevalence_boundaries_invalid_and_undefined(self):
        for prevalence, expected in [(0, 0), (1, 1), (0.001, 0.001), (-0.1, None), (1.1, None),
                                     (True, None), ('0.01', None), (None, None), ({}, None),
                                     (math.nan, None), (math.inf, None)]:
            j = job()
            j['deployment_prevalence'] = prevalence
            p = self.run_packet(j)
            self.assertEqual(p['deployment_precision']['value'], expected)
        j = job()
        for row in j['current']['records']:
            row['decision'] = 0
        p = self.run_packet(j)
        self.assertIsNone(p['deployment_precision']['value'])
        self.assertIsNone(p['calibration']['precision'])
        # Readiness has no undocumented accuracy threshold or predicted-positive requirement.
        self.assertEqual(p['status'], 'ready_for_review')

    def test_semantic_identity_and_label_errors_hold(self):
        for field, value in [('identity', None), ('identity', {}), ('human', True),
                             ('decision', []), ('rep', False), ('id', []), ('family', {})]:
            j = job()
            if field == 'identity':
                j['current']['identity'] = value
            else:
                j['current']['records'][0][field] = value
            p = self.run_packet(j)
            self.assertEqual(p['status'], 'hold')
            self.assertEqual(p['integrity']['status'], 'invalid')

    def test_malformed_structures_return_json_errors(self):
        for data in (None, [], 1, {}, dict(job(), current=[]),
                     dict(job(), required_workers={}), dict(job(), worker_reports=[None]),
                     dict(job(), limits={}), dict(job(), positive_event='')):
            self.run_packet(data, code=2)
        for records in (None, {}, [None], [{}]):
            j = job()
            j['current']['records'] = records
            self.run_packet(j, code=2)
        for margin in (None, True, -1, 2, math.nan, math.inf):
            j = job()
            j['limits']['max_fpr_increase'] = margin
            self.run_packet(j, code=2)
        self.run_packet('{broken', code=2, raw=True)

    def test_saved_example_and_standalone_checkout(self):
        saved = json.loads((REPO / 'examples/review.json').read_text())
        p = self.run_packet(saved)
        self.assertEqual(p['calibration']['denominators']['evaluated'], 5)
        self.assertEqual(p['workers']['uncovered'], ['security'])
        self.assertEqual(p['status'], 'hold')
        standalone = OUT / 'standalone'
        if standalone.exists():
            shutil.rmtree(standalone)
        shutil.copytree(REPO, standalone, ignore=shutil.ignore_patterns('__pycache__'))
        self.assertEqual(self.run_packet(saved, cwd=standalone), p)


if __name__ == '__main__':
    run = unittest.main(verbosity=2, exit=False)
    summary = {'tests_run': run.result.testsRun, 'cli_invocations': CLIIntegration.counter,
               'successful': run.result.wasSuccessful(),
               'failures': len(run.result.failures), 'errors': len(run.result.errors)}
    (OUT / 'integration-summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
    raise SystemExit(0 if run.result.wasSuccessful() else 1)
