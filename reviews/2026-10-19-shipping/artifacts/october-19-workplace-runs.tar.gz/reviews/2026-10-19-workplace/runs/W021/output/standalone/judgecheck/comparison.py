"""Pair judge versions on fixed examples; monitor a fixed judge across cohorts."""
from fractions import Fraction

from .calibration import audit


def paired(previous, current):
    if previous is None:
        return {'status': 'unmeasured'}, []
    _, _, old_issues = audit(previous)
    _, _, new_issues = audit(current)
    issues = old_issues + new_issues
    if issues:
        return {'status': 'invalid', 'pairs': len(current['records']), 'evaluated_pairs': 0}, issues
    for field in ('dataset_version', 'rubric'):
        if previous['identity'][field] != current['identity'][field]:
            issues.append('paired_identity_mismatch')
    def key(row):
        return row['id'], row.get('rep', 0)
    a, b = ({key(r): r for r in c['records']} for c in (previous, current))
    if set(a) != set(b) or any(a[k][f] != b[k][f] for k in set(a) & set(b)
                               for f in ('human', 'family', 'split')):
        issues.append('paired_population_mismatch')
    if issues:
        return {'status': 'invalid', 'pairs': len(b), 'evaluated_pairs': 0}, issues
    comparable = [k for k in b if b[k]['human'] is not None
                  and a[k]['decision'] is not None and b[k]['decision'] is not None]
    improved = sum(a[k]['decision'] != a[k]['human'] and b[k]['decision'] == b[k]['human'] for k in comparable)
    regressed = sum(a[k]['decision'] == a[k]['human'] and b[k]['decision'] != b[k]['human'] for k in comparable)
    status = 'unmeasured' if not b else 'complete' if len(comparable) == len(b) else 'partial'
    return {'status': status, 'pairs': len(b), 'evaluated_pairs': len(comparable),
            'improved': improved, 'regressed': regressed,
            'agreement_delta': (improved - regressed) / len(comparable) if comparable else None}, []


def drift(previous, current, margin):
    if previous is None:
        return {'status': 'unmeasured', 'fpr_delta': None}, []
    old, _, old_issues = audit(previous)
    new, _, new_issues = audit(current)
    issues = old_issues + new_issues
    if not issues:
        for field in ('judge', 'grader_version', 'rubric'):
            if previous['identity'][field] != current['identity'][field]:
                issues.append('drift_judge_mismatch')
    if issues:
        return {'status': 'invalid', 'fpr_delta': None}, issues
    if old['fpr'] is None or new['fpr'] is None:
        return {'status': 'unmeasured', 'fpr_delta': None, 'margin': margin}, []
    # Compare exact count ratios to the declared decimal margin. Binary float
    # subtraction can otherwise turn an equal boundary (0.4 - 0.1) into an alert.
    delta = (Fraction(new['confusion']['fp'], new['denominators']['evaluated_negative'])
             - Fraction(old['confusion']['fp'], old['denominators']['evaluated_negative']))
    return {'status': 'alert' if delta > Fraction(str(margin)) else 'within_margin',
            'fpr_delta': float(delta), 'margin': margin}, []
