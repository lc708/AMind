"""Offline regressions through the public CLI; fixtures stay inside output/."""
import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT / 'repo'


class Incident73(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=ROOT / 'output')
        self.path = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def call(self, op, expected=0, tenant='acme', job='shared', **extra):
        request = {'op': op, 'tenant': tenant, 'job': job, **extra}
        path = self.path / 'request.json'
        path.write_text(json.dumps(request))
        process = subprocess.run(
            [sys.executable, '-m', 'intake', '--db', str(self.path / 'jobs.db'),
             '--request', str(path), '--receipts', str(self.path / 'receipts.jsonl')],
            cwd=REPO, capture_output=True, text=True, timeout=10)
        self.assertEqual(process.returncode, expected, process.stdout + process.stderr)
        return json.loads(process.stdout) if process.stdout else None

    def submit(self, items=None, limit=8, **kw):
        return self.call('submit', spec={'items': items or [{'id': 'a'}],
                                       'max_attempts': limit}, **kw)

    def receipts(self):
        path = self.path / 'receipts.jsonl'
        return [json.loads(line) for line in path.read_text().splitlines()] if path.exists() else []

    def test_saved_gap_population(self):
        request = json.loads((REPO / 'traces/new-job.json').read_text())
        self.call('submit', job=request['job'], spec=request['spec'])
        report = self.call('work', job=request['job'])
        self.assertEqual(report['status'], 'incomplete')
        self.assertEqual(report['coverage'], 0.5)
        self.assertEqual(report['uncovered_ids'], ['invoice-B'])
        rows = {(r['stage'], r['item']): r for r in report['rows']}
        self.assertEqual(rows['review', 'invoice-B']['state'], 'not_covered')
        receipts = self.receipts()
        self.assertEqual(len(receipts), 4)
        self.assertEqual(receipts[-1]['stage'], 'summary')
        self.assertEqual(receipts[-1]['coverage']['coverage'], 0.5)
        self.call('work', job=request['job'])
        self.assertEqual(self.receipts(), receipts)

    def test_review_failure_is_gap(self):
        self.submit([{'id': 'a', 'payload': {'review': 'fail'}}])
        report = self.call('work')
        self.assertEqual(report['coverage'], 0)
        self.assertEqual(report['status'], 'incomplete')
        self.assertEqual(self.receipts()[-1]['coverage']['uncovered_ids'], ['a'])

    def test_crash_reconcile_and_no_replay(self):
        request = json.loads((REPO / 'traces/crash-job.json').read_text())
        self.call('submit', spec=request['spec'])
        self.call('work', expected=17)
        first = self.receipts()
        report = self.call('work')
        self.assertEqual(report['status'], 'unknown')
        self.assertEqual(report['attempts'], 1)
        self.assertEqual(self.receipts(), first)
        self.assertEqual(report['rows'][0]['operation_key'], first[0]['operation_key'])
        args = dict(stage='inspect', item='delivery-A', state='succeeded', result=first[0]['outcome']['output'])
        for evidence in (None, '', '   ', 42):
            self.call('reconcile', expected=2, evidence=evidence, **args)
        self.call('reconcile', evidence='local receipt line 1', **args)
        with sqlite3.connect(self.path / 'jobs.db') as db:
            audit = db.execute('SELECT tenant,job,evidence,operation_key FROM reconciliation').fetchall()
        self.assertEqual(audit, [('acme', 'shared', 'local receipt line 1', first[0]['operation_key'])])
        self.call('reconcile', expected=2, evidence='cannot rewrite', **args)
        report = self.call('work')
        self.assertEqual(report['status'], 'completed')
        self.assertEqual(report['attempts'], 3)
        self.assertEqual(len(self.receipts()), 3)

    def test_crash_review_blocks_summary(self):
        self.submit([{'id': 'a', 'payload': {'crash_after_effect': 'review'}}])
        self.call('work', expected=17)
        report = self.call('work')
        self.assertEqual(report['status'], 'unknown')
        self.assertEqual(report['coverage'], 0)
        self.assertEqual(len(self.receipts()), 2)
        self.call('reconcile', stage='review', item='a', state='failed', result={'failure': 'confirmed'}, evidence='receiver review receipt')
        report = self.call('work')
        self.assertEqual(report['status'], 'incomplete')
        self.assertEqual(report['attempts'], 3)
        self.assertEqual(self.receipts()[-1]['coverage']['coverage'], 0)

    def test_cancel_resume_and_cumulative_budget(self):
        spec = {'items': [{'id': 'a'}], 'max_attempts': 1}
        self.call('submit', spec=spec)
        self.call('cancel')
        self.call('submit', spec=spec)
        report = self.call('work')
        self.assertEqual(report['status'], 'cancelled')
        self.assertEqual(report['attempts'], 0)
        self.assertEqual(self.receipts(), [])
        self.call('resume')
        report = self.call('work')
        self.assertEqual(report['attempts'], 1)
        for op in ('work', 'report', 'resume', 'work'):
            report = self.call(op)
            self.assertEqual(report['attempts'], 1)
            self.assertEqual(report['remaining_attempts'], 0)
        self.assertEqual(len(self.receipts()), 1)

    def test_tenant_identity_spec_and_effects(self):
        first = self.submit()
        second = self.submit(tenant='other', items=[{'id': 'b'}], limit=4)
        self.assertNotEqual(first['rows'][-1]['operation_key'], second['rows'][-1]['operation_key'])
        self.call('cancel')
        report = self.call('work', tenant='other')
        self.assertEqual(report['status'], 'completed')
        self.assertEqual(report['covered_ids'], ['b'])
        self.assertTrue(all(r['tenant'] == 'other' for r in self.receipts()))
        self.call('report', tenant='missing', expected=2)
        self.call('reconcile', tenant='missing', expected=2, stage='inspect', item='a', state='succeeded', evidence='wrong tenant')
        self.call('submit', expected=2, spec={'items': [{'id': 'a'}], 'max_attempts': 9})
        self.call('submit', expected=2, spec={'items': [{'id': 'a', 'payload': {'inspect': 'fail'}}], 'max_attempts': 8})
        self.assertTrue(self.call('report')['cancelled'])

    def test_unknown_is_tenant_scoped(self):
        self.submit([{'id': 'a', 'payload': {'crash_after_effect': 'inspect'}}])
        self.call('work', expected=17)
        self.submit(tenant='other')
        self.call('reconcile', expected=2, tenant='other', stage='inspect', item='a', state='succeeded', evidence='acme receipt')
        self.assertEqual(self.call('report')['status'], 'unknown')
        self.assertEqual(self.call('work', tenant='other')['status'], 'completed')
        self.assertEqual(len(self.receipts()), 4)

    def test_crash_debits_entire_budget(self):
        self.submit([{'id': 'a', 'payload': {'crash_after_effect': 'inspect'}}], limit=1)
        self.call('work', expected=17)
        self.call('cancel')
        self.call('resume')
        self.call('reconcile', stage='inspect', item='a', state='succeeded', result={}, evidence='local receipt')
        report = self.call('work')
        self.assertEqual(report['attempts'], 1)
        self.assertEqual(report['remaining_attempts'], 0)
        self.assertEqual(report['stop_reason'], 'attempt_budget')
        self.assertEqual(len(self.receipts()), 1)

    def test_receiver_io_failure_is_unknown(self):
        self.submit()
        (self.path / 'receipts.jsonl').mkdir()
        self.call('work', expected=2)
        report = self.call('report')
        self.assertEqual(report['status'], 'unknown')
        self.assertEqual(report['attempts'], 1)
        self.assertEqual(self.call('work')['attempts'], 1)

    def test_failure_propagates_without_extra_attempt(self):
        self.submit([{'id': 'a', 'payload': {'inspect': 'fail'}}], limit=1)
        report = self.call('work')
        self.assertEqual(report['attempts'], 1)
        self.assertEqual(report['rows'][1]['state'], 'not_covered')
        self.assertEqual(report['rows'][2]['state'], 'pending')
        self.assertEqual(report['stages'][1]['total'], 1)
        self.assertEqual(len(self.receipts()), 1)

    def test_legacy_unknown_key_is_preserved(self):
        self.submit()
        # A pre-fix journal already contains a remote key. Never mint a new one
        # for that dispatched effect; the receiver knows only the stored key.
        with sqlite3.connect(self.path / 'jobs.db') as db:
            db.execute("UPDATE work SET state='running',operation_key='legacy-remote-key' WHERE stage='inspect'")
            db.execute('UPDATE jobs SET attempts=1')
        report = self.call('work')
        self.assertEqual(report['rows'][0]['operation_key'], 'legacy-remote-key')
        self.assertEqual(report['attempts'], 1)
        self.assertEqual(self.receipts(), [])
        self.call('reconcile', stage='inspect', item='a', state='succeeded', result={}, evidence='legacy receiver lookup')
        self.assertEqual(self.call('work')['status'], 'completed')
        with sqlite3.connect(self.path / 'jobs.db') as db:
            self.assertEqual(db.execute('SELECT operation_key FROM reconciliation').fetchone()[0], 'legacy-remote-key')

    def test_reconcile_only_unknown(self):
        self.submit()
        args = dict(stage='inspect', item='a', state='failed', result={}, evidence='external evidence')
        self.call('reconcile', expected=2, **args)
        self.call('work')
        self.call('reconcile', expected=2, **args)
        self.call('reconcile', expected=2, stage='missing', item='a', state='succeeded', evidence='x')

    def test_summary_failure_not_completed(self):
        self.submit()
        self.call('work')
        # Simulate an unresolved aggregate restored from a delivery crash.
        with sqlite3.connect(self.path / 'jobs.db') as db:
            db.execute("UPDATE work SET state='running',result=NULL WHERE stage='summary'")
        self.call('reconcile', stage='summary', item='__all__', state='failed', result={'error': 'confirmed'}, evidence='receiver delivery failure')
        report = self.call('work')
        self.assertEqual(report['coverage'], 1)
        self.assertEqual(report['status'], 'incomplete')
        self.assertEqual(len(self.receipts()), 3)


if __name__ == '__main__':
    unittest.main()
