"""Intake journal; recovery design informed by AMind Engineering's workflow
reference (Apache-2.0). Uses only this application's store and standard library.
"""
import json
from .store import operation_key, packed
from .receiver import perform

STAGES = ('inspect', 'review', 'summary')
SETTLED = ('succeeded', 'failed', 'not_covered')


def validate(spec):
    if not isinstance(spec, dict):
        raise ValueError('job specification must be an object')
    items = spec.get('items')
    limit = spec.get('max_attempts')
    if not isinstance(items, list) or not items:
        raise ValueError('nonempty item population required')
    ids = [i.get('id') for i in items if isinstance(i, dict)]
    if (len(ids) != len(items) or
            any(not isinstance(i, str) or not i or i == '__all__' for i in ids) or
            len(set(ids)) != len(ids)):
        raise ValueError('unique item IDs required')
    if any(i.get('payload') is not None and not isinstance(i['payload'], dict) for i in items):
        raise ValueError('item payload must be an object')
    if type(limit) is not int or limit < 1:
        raise ValueError('positive max_attempts required')
    packed(spec)
    return spec


def report(store, tenant, job):
    entry = store.job(tenant, job)
    rows = store.rows(tenant, job)
    population = [i['id'] for i in entry['spec']['items']]
    indexed = {(r['stage'], r['item']): r for r in rows}
    covered = [i for i in population if all(
        indexed.get((stage, i), {}).get('state') == 'succeeded'
        for stage in ('inspect', 'review'))]
    pending = any(r['state'] == 'pending' for r in rows)
    unknown = any(r['state'] == 'running' for r in rows)
    summary_ok = indexed.get(('summary', '__all__'), {}).get('state') == 'succeeded'
    status = ('unknown' if unknown else 'pending' if pending else
              'completed' if len(covered) == len(population) and summary_ok else 'incomplete')
    if entry['cancelled']:
        status = 'cancelled'
    stages = []
    for stage in STAGES:
        ids = ['__all__'] if stage == 'summary' else population
        counts = {}
        uncovered = []
        for item in ids:
            state = indexed.get((stage, item), {}).get('state', 'missing')
            counts[state] = counts.get(state, 0) + 1
            if state != 'succeeded':
                uncovered.append(item)
        stages.append({'stage': stage, 'total': len(ids), 'counts': counts,
                       'coverage': counts.get('succeeded', 0) / len(ids),
                       'uncovered_ids': uncovered})
    remaining = max(0, entry['spec']['max_attempts'] - entry['attempts'])
    return {'tenant': tenant, 'job': job, 'status': status,
            'attempts': entry['attempts'], 'remaining_attempts': remaining,
            'coverage': len(covered) / len(population), 'covered_ids': covered,
            'uncovered_ids': [i for i in population if i not in covered],
            'cancelled': entry['cancelled'], 'rows': rows, 'stages': stages,
            'stop_reason': ('cancelled' if entry['cancelled'] else
                            'unknown_outcome' if unknown else
                            'attempt_budget' if pending and remaining == 0 else None)}


def submit(store, tenant, job, spec):
    spec = validate(spec)
    store.db.execute('BEGIN IMMEDIATE')
    try:
        old = store.db.execute('SELECT spec FROM jobs WHERE tenant=? AND job=?', (tenant, job)).fetchone()
        if old:
            if packed(json.loads(old[0])) != packed(spec):
                raise ValueError('immutable job specification differs')
        else:
            store.db.execute('INSERT INTO jobs VALUES(?,?,?,0,0)', (tenant, job, packed(spec)))
            for stage in STAGES:
                for item in (['__all__'] if stage == 'summary' else [i['id'] for i in spec['items']]):
                    store.db.execute('INSERT INTO work VALUES(?,?,?,?,?,?,?)',
                                     (tenant, job, stage, item, 'pending', None,
                                      operation_key(tenant, job, stage, item)))
        store.db.execute('COMMIT')
    except BaseException:
        store.db.execute('ROLLBACK')
        raise
    return report(store, tenant, job)


def start(store, tenant, job, stage, item):
    """Commit both the budget debit and unknown effect before receiver I/O."""
    store.db.execute('BEGIN IMMEDIATE')
    try:
        entry = store.job(tenant, job)
        if entry['cancelled'] or entry['attempts'] >= entry['spec']['max_attempts']:
            store.db.execute('COMMIT')
            return False
        changed = store.db.execute(
            "UPDATE work SET state='running',result=NULL WHERE tenant=? AND job=? AND stage=? AND item=? AND state='pending'",
            (tenant, job, stage, item)).rowcount
        if changed:
            store.db.execute('UPDATE jobs SET attempts=attempts+1 WHERE tenant=? AND job=?', (tenant, job))
        store.db.execute('COMMIT')
        return bool(changed)
    except BaseException:
        store.db.execute('ROLLBACK')
        raise


def work(store, tenant, job, receipts):
    # One local coordinator. Running rows survive crashes and never auto-replay.
    for stage in STAGES:
        for row in [r for r in store.rows(tenant, job) if r['stage'] == stage]:
            if row['state'] != 'pending':
                continue
            entry = store.job(tenant, job)
            if entry['cancelled']:
                return report(store, tenant, job)
            previous = [r for r in store.rows(tenant, job) if r['stage'] in ('inspect', 'review')]
            if stage == 'review':
                dependency = next((r for r in previous if r['stage'] == 'inspect' and r['item'] == row['item']), None)
                if dependency is None or dependency['state'] not in SETTLED:
                    continue
                if dependency['state'] != 'succeeded':
                    store.update(tenant, job, stage, row['item'], 'not_covered',
                                 {'reason': 'inspection did not succeed'})
                    continue
            if stage == 'summary' and any(r['state'] not in SETTLED for r in previous):
                continue
            context = {'tenant': tenant, 'job': job, 'stage': stage, 'item': row['item'],
                       'operation_key': row['operation_key'],
                       'payload': next((i.get('payload', {}) for i in entry['spec']['items']
                                        if i['id'] == row['item']), {}),
                       'coverage': report(store, tenant, job)}
            if not start(store, tenant, job, stage, row['item']):
                return report(store, tenant, job)
            outcome = perform(context, receipts)
            # Exceptions and invalid replies remain running: delivery may exist.
            if (not isinstance(outcome, dict) or outcome.get('status') not in ('succeeded', 'failed')
                    or 'output' not in outcome):
                raise ValueError('invalid receiver outcome; reconciliation required')
            packed(outcome['output'])
            store.update(tenant, job, stage, row['item'], outcome['status'], outcome['output'])
    return report(store, tenant, job)


def reconcile(store, tenant, job, request):
    evidence = request.get('evidence')
    state = request.get('state')
    if (state not in ('succeeded', 'failed') or not isinstance(evidence, str)
            or not evidence.strip() or 'result' not in request):
        raise ValueError('external outcome and evidence required')
    result = packed(request.get('result'))
    stage, item = request.get('stage'), request.get('item')
    if stage not in STAGES or not isinstance(item, str) or not item:
        raise ValueError('valid stage and item required')
    store.db.execute('BEGIN IMMEDIATE')
    try:
        target = store.db.execute(
            "SELECT operation_key FROM work WHERE tenant=? AND job=? AND stage=? AND item=? AND state='running'",
            (tenant, job, stage, item)).fetchone()
        if target is None:
            raise ValueError('exactly one unknown operation required')
        store.update(tenant, job, stage, item, state, request.get('result'))
        store.db.execute(
            'INSERT INTO reconciliation(tenant,job,stage,item,state,result,evidence,operation_key) VALUES(?,?,?,?,?,?,?,?)',
            (tenant, job, stage, item, state, result, evidence, target[0]))
        store.db.execute('COMMIT')
    except BaseException:
        store.db.execute('ROLLBACK')
        raise
    return report(store, tenant, job)


def handle(store, request, receipts):
    if not isinstance(request, dict):
        raise ValueError('request must be an object')
    tenant, job, op = request.get('tenant'), request.get('job'), request.get('op')
    if any(not isinstance(v, str) or not v for v in (tenant, job)):
        raise ValueError('trusted tenant and job identity required')
    if op == 'submit':
        return submit(store, tenant, job, request['spec'])
    store.job(tenant, job)
    if op == 'report':
        return report(store, tenant, job)
    if op == 'work':
        return work(store, tenant, job, receipts)
    if op in ('cancel', 'resume'):
        store.db.execute('UPDATE jobs SET cancelled=? WHERE tenant=? AND job=?',
                         (int(op == 'cancel'), tenant, job))
        return report(store, tenant, job)
    if op == 'reconcile':
        return reconcile(store, tenant, job, request)
    raise ValueError('unknown operation')
