# Incident 73 repair

The CLI and simulated receiver remain standard-library-only. No model,
network service, skill installation, or machine-specific path is needed to run
`python3 -m intake` from this directory. The original CLI flags and report fields
remain; reports additionally expose per-stage population counts and stop reasons.

## Cause and changes

* Delivery preceded the durable `running` marker and attempt debit. A process
  exit after the receiver append left work pending, so the next worker delivered
  it again. The marker and debit now commit together **before** receiver I/O.
  Exceptions or invalid outcomes leave the operation unknown; restarting skips
  it and preserves its stored operation key.
* Every worker invocation reset attempts and cancellation. Those resets are
  removed. Only a new dispatch consumes the original cumulative budget, and
  only explicit `resume` clears cancellation. Reports and identical submissions
  preserve both controls. A blocked review can become `not_covered` without
  consuming a dispatch, even when the delivery budget is exhausted.
* Review's dependency branches did nothing. Review now waits for pending or
  unknown inspection and records `not_covered` for a known inspection failure.
  Summary waits for every item dependency to settle. It can describe known
  failures without treating them as successes or retrying them.
* Coverage used only inspection. It now requires both inspection and review
  over the entire frozen population. A successful summary cannot change this
  denominator; a failed summary also prevents `completed` with full item coverage.
* Job lookup omitted tenant and remote keys omitted tenant. Lookups now use
  `(tenant, job)` and newly planned keys hash tenant/job/stage/item. Existing
  stored keys are preserved for recovery. Submission compares the full immutable
  JSON specification and cannot replace the population, payloads, or budget.
* Reconciliation accepted empty evidence and could overwrite any state. It now
  requires an explicit result and nonblank string evidence, targets one unknown
  operation within the trusted tenant/job, and atomically records the outcome
  and evidence in an additive reconciliation table. Settled and pending rows
  cannot be rewritten. Receiver/storage I/O errors use the CLI's JSON error exit.

## Reproduction and verification

The saved `traces/new-job.json` reproduces the failed invoice inspection:
inspection A succeeds, inspection B fails, only A is reviewed, and the summary
receives coverage `0.5` with B explicitly uncovered. There are four receiver
appends and repeated work adds none.

The saved `traces/crash-job.json` reproduces exit 17 immediately after delivery:
the receiver has one inspection receipt, the journal retains one attempt and
`running`, and repeated work returns `unknown` without another receipt. Reconcile
against that receipt's operation key and output, then work resumes review and
summary, ending with three cumulative attempts and three receipts.

From `repo/`, all side effects stay within this delivery directory:

```sh
mkdir -p ../output/tmp
TMPDIR="$PWD/../output/tmp" python3 -m unittest discover -s tests -v
python3 -m unittest discover -s ../output -p test_incident73.py -v
python3 ../output/replay_incident73.py
```

The replay creates `output/replay/` once and refuses to overwrite existing
evidence. Its saved requests can also be passed directly to the public CLI:

```sh
python3 -m intake --db ../output/replay/jobs.sqlite \
  --request ../output/replay/05-restart.request.json \
  --receipts ../output/replay/receipts.jsonl
```

The initial eight incident regressions all failed on the original application
(`output/baseline.txt`). All 13 current incident regressions pass, including
tenant-scoped recovery, exhausted crash budgets, receiver I/O failure, failure
propagation without extra dispatch, and preservation of legacy remote keys.
The original three public tests pass. An isolated copy of only the application
package also completes submit/work with an empty PYTHONPATH and no skills tree
(`output/standalone/verification.json`). Logs, JSON reports, real SQLite state,
and the simulated receiver's ten receipt lines are retained under `output/`.
The replay covers the known gap, crash/restart without duplicate delivery,
evidenced reconciliation, and another tenant using the same job number.

## Limits and recovery policy

This is a single-coordinator local journal, as specified in README. Stop active
work before manual reconciliation; distributed leases and concurrent workers
remain outside scope. A running marker is deliberately conservative: a crash
before receiver I/O also needs external reconciliation. Evidence is supplied by
the trusted operator; the application records it but cannot independently prove
an external outcome. No exactly-once remote delivery guarantee is claimed.

Existing databases are opened in place with an additive audit table. Stored
operation keys, outcomes, attempts, and cancellation flags are not rewritten.
Legacy keys that omitted tenant may already collide; preserve them to query the
original receiver, and use newly submitted jobs for tenant-scoped keys. The old
worker could also deliver while still marked pending or erase attempt history.
Those historical facts cannot be reconstructed from SQLite alone: inspect the
old receiver receipts and restore a trustworthy journal before resuming such
legacy jobs. This patch prevents new instances of those losses; it does not
invent missing evidence or undo receipts already delivered.

Implementation was informed by the local AMind Engineering staged workflow and
lifecycle references (`workflow_contract.py`, Apache-2.0). No skill code is
imported at runtime and no downstream model was used. Verification measures
local application behavior with the simulated receiver, not provider quality.
