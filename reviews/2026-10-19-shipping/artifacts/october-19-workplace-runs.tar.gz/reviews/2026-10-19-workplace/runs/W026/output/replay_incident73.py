"""Persist CLI requests, reports and receiver receipts using only local fixtures."""
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
folder = root / 'output' / 'replay'
folder.mkdir(exist_ok=True)
if (folder / 'jobs.sqlite').exists():
    raise SystemExit('Replay already exists; choose a fresh local fixture directory.')
observed = []


def call(name, request, expected=0):
    path = folder / (name + '.request.json')
    path.write_text(json.dumps(request, indent=2) + '\n')
    process = subprocess.run([sys.executable, '-m', 'intake', '--db', str(folder / 'jobs.sqlite'),
                              '--request', str(path), '--receipts', str(folder / 'receipts.jsonl')],
                             cwd=root / 'repo', capture_output=True, text=True, timeout=10)
    assert process.returncode == expected, process.stdout + process.stderr
    result = json.loads(process.stdout) if process.stdout else None
    (folder / (name + '.result.json')).write_text(json.dumps({'exit': process.returncode, 'report': result}, indent=2) + '\n')
    observed.append({'step': name, 'exit': process.returncode, 'status': result and result.get('status')})
    return result


gap = json.loads((root / 'repo/traces/new-job.json').read_text())
call('01-gap-submit', gap)
result = call('02-gap-work', {**gap, 'op': 'work'})
assert result['coverage'] == 0.5 and result['status'] == 'incomplete'
crash = json.loads((root / 'repo/traces/crash-job.json').read_text())
call('03-crash-submit', crash)
call('04-crash-delivery', {**crash, 'op': 'work'}, 17)
before = (folder / 'receipts.jsonl').read_text()
unknown = call('05-restart', {**crash, 'op': 'work'})
assert unknown['attempts'] == 1 and unknown['status'] == 'unknown'
assert (folder / 'receipts.jsonl').read_text() == before
receipt = json.loads(before.splitlines()[-1])
call('06-reconcile', {**crash, 'op': 'reconcile', 'stage': 'inspect', 'item': 'delivery-A',
                      'state': 'succeeded', 'result': receipt['outcome']['output'],
                      'evidence': 'local simulated receiver receipts.jsonl line 5; matching operation_key'})
finished = call('07-finish', {**crash, 'op': 'work'})
assert finished['status'] == 'completed' and finished['attempts'] == 3
other = {**crash, 'tenant': 'other', 'spec': {'items': [{'id': 'delivery-A'}], 'max_attempts': 8}}
other_plan = call('08-other-submit', other)
assert other_plan['rows'][0]['operation_key'] != unknown['rows'][0]['operation_key']
assert call('09-other-work', {**other, 'op': 'work'})['status'] == 'completed'
(folder / 'verification.json').write_text(json.dumps({'checks_passed': True, 'steps': observed,
    'receipt_count': len((folder / 'receipts.jsonl').read_text().splitlines())}, indent=2) + '\n')
print(json.dumps({'checks_passed': True, 'receipt_count': 10}))
