# Incident 418 response gateway repair

The replay now exposes only customer-owned messages, keeps incomplete answers
incomplete, and preserves every terminal output item in the operations archive.
The CLI arguments and the `{client, archive}` result envelope remain compatible.
The application is still Python standard library only and runs independently of
this workspace's skills. No model, SDK, network client or tool executor was added.

## Cause and reproduction

`gateway/projection.py` concatenated every text delta and treated any phase-less
or `final_answer` message as a customer answer, regardless of its owner. It also
trusted the terminal event name without validating `response.status`, and ignored
pending function calls. `gateway/replay.py` discarded hosted item types through a
legacy allowlist. `gateway/render.py` interpolated unescaped text into HTML.

From `repo/`, the original public entry point reproduced the incident:

```sh
python3 -m gateway --capture traces/incident.json --out ../output/baseline-incident.json
```

The saved baseline has `display_text="Internal draftChecking your request."`,
`final_text="Internal draft"`, `answer_complete=true`, and only two archived
items. This let the worker's draft become the customer's completed answer.

## Changes

- Track item ownership, phase and identity by output index, with item-ID checks.
  Multi-agent text without a known message owner stays in operations. Only an
  explicit `/root` message with `phase="final_answer"` supplies a multi-agent
  final answer. Root commentary remains progress. Legacy single-agent messages
  without a phase and legacy unindexed deltas continue to work.
- Validate terminal event/status agreement, completed responses containing error
  or incomplete details, events after an outcome, and conflicting attribution.
  Sparse item snapshots cannot erase previously observed identity facts. Capture
  errors use the existing JSON-error/exit-2 path before storage publishes anything.
- Keep transport status separate from `answer_complete`. Missing terminals stay
  `disconnected`, error-only streams become `stream_error`, and failed, incomplete
  or cancelled responses never complete an answer. Unresolved function calls
  prevent completion; matching captured function outputs can resolve them.
- Preserve terminal output items without an allowlist or normalization, and deep
  copy both archive collections. Without a terminal, archive the latest observed
  item snapshots; the original snapshots and deltas remain in `archive.events`.
  Hosted/unknown items remain opaque data and never invoke local tools.
- Escape visible HTML text using Python's `html.escape`. The browser's client
  object contains only status, visible text, completion and rendered HTML.

## Verification

All application calls use local captures and write only inside this workspace.
Original `repo/tests/` files were left unchanged. Run from `repo/`:

```sh
mkdir -p ../output/tmp
TMPDIR="$PWD/../output/tmp" python3 -m unittest discover -s tests
TMPDIR="$PWD/../output/tmp" python3 -m unittest discover -s ../output -p 'test_gateway_regression.py' -v
python3 -m gateway --capture traces/incident.json --out ../output/repaired-incident.json
python3 -m gateway --capture traces/legacy.json --out ../output/repaired-legacy.json
```

The three existing public checks and twelve focused regression methods pass.
The latter invoke the real CLI for interleaved root/worker traffic, missing
attribution and phase, legacy callers, every terminal status, disconnect/error,
HTML escaping, pending/resolved calls, unknown hosted items, malformed payloads,
and inconsistent attribution. Invalid captures are checked twice: an existing
output must remain unchanged, and an absent output must not be created.

The repaired incident result has `display_text="Checking your request."`,
`final_text=""`, `answer_complete=false`, and all three archived items, including
`agent_message`. Its transport status remains `completed`; that field describes
the captured transport, while the customer badge must use `answer_complete`.
The legacy trace still returns `final_text="Order received."` and completes.
Artifacts and runnable regression coverage are in `output/` at the workspace root.

## Limits and reference

Verification is offline protocol/CLI regression coverage, not a live provider or
model-quality evaluation. No tool results are generated or trusted as locally
executed work. Terminal snapshots are authoritative; partial text is provisional.
The gateway rejects events following a terminal/error outcome; it does not merge
multiple response streams into one capture. The existing 8 MiB/50,000-event bounds
remain in place; performance at those bounds was not benchmarked.

The supplied AMind Engineering skill's response recipes and response-contract
helper informed the transport-versus-answer and lossless-archive checks. The
implementation is local application code; no runtime import or absolute path to
that skill is required. No implementation was vendored from another package.
