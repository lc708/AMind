"""Offline CLI regression checks; all fixtures and effects stay under output/."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT / 'repo'
TMP = ROOT / 'output' / 'tmp'
TMP.mkdir(exist_ok=True)


def message(text, owner='/root', phase='final_answer', **extra):
    item = {'type': 'message', 'content': [{'type': 'output_text', 'text': text}], **extra}
    if owner is not None:
        item['agent'] = {'agent_name': owner}
    if phase is not None:
        item['phase'] = phase
    return item


def terminal(items, status='completed', **extra):
    return {'type': 'response.' + status,
            'response': {'status': status, 'output': items, **extra}}


def added(index, item):
    return {'type': 'response.output_item.added', 'output_index': index, 'item': item}


def delta(index, text, **extra):
    return {'type': 'response.output_text.delta', 'output_index': index, 'delta': text, **extra}


class GatewayRegression(unittest.TestCase):
    def call(self, events, mode='multi_agent', bad=False):
        capture = {'mode': mode, 'events': events}
        with tempfile.TemporaryDirectory(dir=TMP) as directory:
            source = Path(directory) / 'capture.json'
            target = Path(directory) / 'view.json'
            source.write_text(json.dumps(capture))
            if bad:
                target.write_text('previous artifact')
            result = subprocess.run([sys.executable, '-m', 'gateway', '--capture', str(source),
                                     '--out', str(target)], cwd=REPO, capture_output=True, text=True)
            if bad:
                self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
                self.assertIsInstance(json.loads(result.stdout)['error'], str)
                self.assertEqual(target.read_text(), 'previous artifact')
                target.unlink()
                retry = subprocess.run([sys.executable, '-m', 'gateway', '--capture', str(source),
                                        '--out', str(target)], cwd=REPO, capture_output=True, text=True)
                self.assertEqual(retry.returncode, 2)
                self.assertFalse(target.exists())
                return
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            bundle = json.loads(target.read_text())
            self.assertEqual(bundle['archive']['events'], events)
            self.assertEqual(set(bundle['client']), {'status', 'display_text', 'final_text',
                                                    'answer_complete', 'html'})
            return bundle

    def test_saved_incident(self):
        capture = json.loads((REPO / 'traces/incident.json').read_text())
        result = self.call(capture['events'])
        self.assertEqual(result['client']['display_text'], 'Checking your request.')
        self.assertEqual(result['client']['final_text'], '')
        self.assertFalse(result['client']['answer_complete'])
        self.assertNotIn('Internal draft', json.dumps(result['client']))
        self.assertEqual(result['archive']['output_items'], capture['events'][-1]['response']['output'])

    def test_root_final_with_interleaved_workers(self):
        items = [message('secret', '/root/search'), message('progress', phase='commentary'),
                 message('<b>answer</b> & "yes"')]
        events = []
        for i, item in enumerate(items):
            events.extend([added(i, item), delta(i, item['content'][0]['text'])])
        result = self.call(events + [terminal(items)])
        client = result['client']
        self.assertEqual(client['display_text'], 'progress<b>answer</b> & "yes"')
        self.assertEqual(client['final_text'], '<b>answer</b> & "yes"')
        self.assertTrue(client['answer_complete'])
        self.assertEqual(client['html'], '<article>&lt;b&gt;answer&lt;/b&gt; &amp; &quot;yes&quot;</article>')

    def test_no_guessed_multi_agent_owner_or_final_phase(self):
        items = [message('unattributed', None), message('root progress', phase=None),
                 message('unknown phase', phase='analysis')]
        result = self.call([delta(99, 'unattributed delta'), terminal(items)])
        self.assertEqual(result['client']['final_text'], '')
        self.assertFalse(result['client']['answer_complete'])
        self.assertEqual(result['client']['display_text'], 'root progress')

    def test_legacy_single_agent(self):
        item = message('Order received.', None, None)
        result = self.call([terminal([item])], mode='single')
        self.assertEqual(result['client']['final_text'], 'Order received.')
        self.assertTrue(result['client']['answer_complete'])
        self.assertFalse(self.call([terminal([])], mode='single')['client']['answer_complete'])

    def test_disconnect_error_and_terminal_outcomes(self):
        item = message('partial')
        prefix = [added(0, item), delta(0, 'partial')]
        for ending, status in [([], 'disconnected'), ([{'type': 'error', 'message': 'lost'}], 'stream_error')]:
            with self.subTest(status=status):
                result = self.call(prefix + ending)
                self.assertEqual(result['client']['status'], status)
                self.assertEqual(result['client']['display_text'], 'partial')
                self.assertEqual(result['client']['final_text'], '')
                self.assertFalse(result['client']['answer_complete'])
                self.assertEqual(result['archive']['output_items'], [item])
        for status in ('failed', 'incomplete', 'cancelled'):
            with self.subTest(status=status):
                result = self.call(prefix + [terminal([item], status)])
                self.assertEqual(result['client']['status'], status)
                self.assertFalse(result['client']['answer_complete'])

    def test_commentary_and_pending_function_are_not_completed_answers(self):
        result = self.call([terminal([message('working', phase='commentary')])])
        self.assertEqual(result['client']['final_text'], '')
        self.assertEqual(result['client']['display_text'], 'working')
        self.assertFalse(result['client']['answer_complete'])
        call = {'type': 'function_call', 'call_id': 'lookup', 'name': 'delete_file', 'arguments': '{}'}
        result = self.call([terminal([message('draft'), call])])
        self.assertFalse(result['client']['answer_complete'])
        resolved = {'type': 'function_call_output', 'call_id': 'lookup', 'output': 'fixture'}
        self.assertTrue(self.call([terminal([message('done'), call, resolved])])['client']['answer_complete'])

    def test_unknown_hosted_items_are_lossless_and_inert(self):
        unknown = {'type': 'future_hosted_worker', 'opaque': {'command': 'never execute',
                   'phase': 'internal', 'receipt': [None, {'x': 7}]}}
        items = [unknown, {'type': 'agent_message', 'secret': '<script>ops</script>'}, message('safe')]
        result = self.call([terminal(items)])
        self.assertEqual(result['archive']['output_items'], items)
        self.assertEqual(result['archive']['summary']['item_count'], 3)
        self.assertNotIn('opaque', json.dumps(result['client']))

    def test_html_escapes_provisional_text(self):
        text = '<img src=x onerror="alert(1)"> & <script>bad</script>'
        result = self.call([{'type': 'response.output_text.delta', 'delta': text}], mode='single')
        self.assertNotIn('<img', result['client']['html'])
        self.assertNotIn('<script>', result['client']['html'])
        self.assertEqual(result['client']['display_text'], text)

    def test_terminal_contradictions_do_not_publish(self):
        cases = [
            [{'type': 'response.completed', 'response': {'status': 'incomplete', 'output': []}}],
            [{'type': 'response.failed', 'response': {'status': 'completed', 'output': []}}],
            [{'type': 'response.completed'}],
            [terminal([], error={})], [terminal([], incomplete_details={})],
            [terminal([]), terminal([])],
            [terminal([]), delta(0, 'late')],
            [{'type': 'error'}, terminal([])],
            [{'type': 'response.completed', 'response': {'status': 'completed', 'output': {}}}],
        ]
        for events in cases:
            with self.subTest(events=events):
                self.call(events, bad=True)

    def test_inconsistent_attribution_does_not_publish(self):
        worker = message('secret', '/root/worker', id='worker')
        root = message('secret', id='worker')
        cases = [
            [added(0, worker), added(0, root)],
            [added(0, worker), terminal([root])],
            [added(0, worker), delta(0, 'secret', agent={'agent_name': '/root'})],
            [added(0, root), terminal([message('secret', phase='commentary', id='worker')])],
            [added(0, worker), added(1, message('answer', id='root')),
             delta(1, 'secret', item_id='worker')],
            [added(0, root), added(1, root)],
            [added(0, worker),
             {'type': 'response.output_item.done', 'output_index': 0,
              'item': message('secret', None, None, id='worker')}, terminal([root])],
        ]
        for events in cases:
            with self.subTest(events=events):
                self.call(events, bad=True)

    def test_item_id_routes_only_known_owner(self):
        root = message('answer', id='r')
        events = [added(0, root), {'type': 'response.output_text.delta', 'item_id': 'r', 'delta': 'answer'},
                  terminal([root])]
        self.assertEqual(self.call(events)['client']['display_text'], 'answer')

    def test_malformed_known_payloads_are_json_errors(self):
        for events in [[terminal([None])], [terminal([{'type': 'message', 'content': 'bad'}])],
                       [terminal([message(42)])], [delta([], 'bad')], [delta(0, [])],
                       [added(0, {'type': 'message', 'agent': 'bad'})]]:
            with self.subTest(events=events):
                self.call(events, bad=True)


if __name__ == '__main__':
    unittest.main()
