"""Customer projection: validate identity and transport before exposing text."""
from .render import render

TERMINALS = {'response.completed': 'completed', 'response.failed': 'failed',
             'response.incomplete': 'incomplete', 'response.cancelled': 'cancelled'}


def _owner(value):
    agent = value.get('agent')
    if agent is None:
        return None
    if not isinstance(agent, dict):
        raise ValueError('agent must be an object')
    owner = agent.get('agent_name')
    if owner is not None and (not isinstance(owner, str) or not owner):
        raise ValueError('agent_name must be a nonempty string')
    return owner


def _item(item):
    if not isinstance(item, dict):
        raise ValueError('output item must be an object')
    _owner(item)
    phase = item.get('phase')
    if phase is not None and not isinstance(phase, str):
        raise ValueError('message phase must be a string')
    if item.get('type') == 'message':
        content = item.get('content', [])
        if not isinstance(content, list):
            raise ValueError('message content must be an array')
        for part in content:
            if not isinstance(part, dict):
                raise ValueError('message content item must be an object')
            if part.get('type') == 'output_text' and not isinstance(part.get('text', ''), str):
                raise ValueError('output text must be a string')
    return item


def _consistent(previous, current):
    # Missing attribution never acquires root privileges through this check.
    for label, old, new in (
        ('owner', _owner(previous), _owner(current)),
        ('phase', previous.get('phase'), current.get('phase')),
        ('item id', previous.get('id'), current.get('id')),
        ('item type', previous.get('type'), current.get('type')),
    ):
        if old is not None and new is not None and old != new:
            raise ValueError('inconsistent output attribution: ' + label)


def _visible(item, multi):
    owner = _owner(item)
    return (item.get('type') == 'message'
            and (owner == '/root' if multi else owner in (None, '/root'))
            and item.get('phase') in (None, 'commentary', 'final_answer'))


def _text(item):
    return ''.join(part.get('text', '') for part in item.get('content', [])
                   if part.get('type') == 'output_text')


def _index(event):
    index = event.get('output_index')
    if index is not None and (type(index) is not int or index < 0):
        raise ValueError('output_index must be a nonnegative integer')
    return index


def project(capture):
    multi = capture.get('mode', 'single') == 'multi_agent'
    display = []
    tracked = {}
    attribution = {}
    identities = {}
    terminal = None
    stream_error = False

    def register(index, item):
        known = attribution.setdefault(index, {})
        _consistent(known, item)
        # Keep identity facts across sparse snapshots, without enriching the
        # raw item or granting missing owners customer visibility.
        for key in ('type', 'phase', 'id'):
            if item.get(key) is not None:
                known[key] = item[key]
        if _owner(item) is not None:
            known['agent'] = item['agent']
        identity = item.get('id')
        if identity is not None:
            if not isinstance(identity, str):
                raise ValueError('output item id must be a string')
            if identity in identities and identities[identity] != index:
                raise ValueError('item id assigned to multiple output indices')
            identities[identity] = index
        tracked[index] = item

    for event in capture['events']:
        kind = event['type']
        if terminal is not None or stream_error:
            raise ValueError('event after terminal outcome')
        if kind in ('response.output_item.added', 'response.output_item.done'):
            index = _index(event)
            if index is None:
                raise ValueError('output item requires output_index')
            item = _item(event.get('item'))
            _consistent(event, {'agent': item.get('agent'), 'phase': item.get('phase')})
            register(index, item)
        elif kind == 'response.output_text.delta':
            delta = event.get('delta', '')
            if not isinstance(delta, str):
                raise ValueError('text delta must be a string')
            index = _index(event)
            identity = event.get('item_id')
            if identity is not None:
                if not isinstance(identity, str):
                    raise ValueError('delta item_id must be a string')
                known_index = identities.get(identity)
                if index is None:
                    index = known_index
                elif known_index is not None and known_index != index:
                    raise ValueError('delta item_id/output_index mismatch')
            item = tracked.get(index)
            if item is not None:
                _consistent(attribution[index], {'agent': event.get('agent'),
                                                'phase': event.get('phase'), 'id': identity})
                if _visible(item, multi):
                    display.append(delta)
            elif not multi:
                # Legacy single-agent streams may omit item-added events.
                provisional = {'type': 'message', 'agent': event.get('agent'),
                               'phase': event.get('phase')}
                if _visible(provisional, False):
                    display.append(delta)
            else:
                _owner(event)  # Unattributed multi-agent text is archive-only.
        elif kind in TERMINALS:
            terminal = event.get('response')
            if not isinstance(terminal, dict) or terminal.get('status') != TERMINALS[kind]:
                raise ValueError('terminal event/status mismatch')
            if terminal['status'] == 'completed' and (
                    terminal.get('error') is not None
                    or terminal.get('incomplete_details') is not None):
                raise ValueError('completed response contains error or incomplete details')
            items = terminal.get('output', [])
            if not isinstance(items, list):
                raise ValueError('response output must be an array')
            for index, item in enumerate(items):
                register(index, _item(item))
        elif kind == 'error':
            stream_error = True

    status = terminal['status'] if terminal is not None else (
        'stream_error' if stream_error else 'disconnected')
    # Terminal snapshots own the result. Partial items are operations evidence.
    items = terminal.get('output', []) if terminal is not None else [
        tracked[index] for index in sorted(tracked)]
    final = []
    visible = []
    for item in items:
        if not _visible(item, multi):
            continue
        text = _text(item)
        visible.append(text)
        phase = item.get('phase')
        if terminal is not None and (phase == 'final_answer' or (not multi and phase is None)):
            final.append(text)
    final_text = ''.join(final)
    display_text = ''.join(display) if display else ''.join(visible)
    resolved = {item.get('call_id') for item in items
                if item.get('type') == 'function_call_output' and isinstance(item.get('call_id'), str)}
    pending = any(item.get('type') == 'function_call' and
                  (not isinstance(item.get('call_id'), str) or item['call_id'] not in resolved)
                  for item in items)
    return {'status': status, 'display_text': display_text, 'final_text': final_text,
            'answer_complete': status == 'completed' and bool(final_text) and not pending,
            'html': render(final_text or display_text)}, items
