import copy
from .projection import project


def replay(capture):
    client, items = project(capture)
    # Hosted and future item types are opaque data, never executable instructions.
    return {'client': client, 'archive': {
        'events': copy.deepcopy(capture['events']),
        'output_items': copy.deepcopy(items)}}
